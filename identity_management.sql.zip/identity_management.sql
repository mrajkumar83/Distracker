-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 05, 2016 at 01:02 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `identity_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_userdetails`
--

CREATE TABLE IF NOT EXISTS `tb_userdetails` (
  `user_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_first_name` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'First Name',
  `user_last_name` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'Last Name',
  `user_email` varchar(150) COLLATE utf8_bin NOT NULL COMMENT 'Email',
  `user_date_birth` date NOT NULL DEFAULT '1970-01-01' COMMENT 'User Date of Birth',
  `user_access` enum('U','I') COLLATE utf8_bin NOT NULL DEFAULT 'I' COMMENT 'Privileges of the user: U->User, I->Identity[no access]',
  PRIMARY KEY (`user_id`),
  KEY `user_email` (`user_email`),
  KEY `user_email_2` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=56 ;

--
-- Dumping data for table `tb_userdetails`
--

INSERT INTO `tb_userdetails` (`user_id`, `user_first_name`, `user_last_name`, `user_email`, `user_date_birth`, `user_access`) VALUES
(1, 'Epita', 'Masters', 'internalmasters@epita.fr', '1970-01-01', 'U'),
(27, 'some', 'change', 'Something@change.com', '1967-02-16', 'I'),
(28, 'jam', 'kal', 'kjlj@kjlj.com', '1989-03-01', 'I'),
(29, 'testing', 'testing', 'teseting@testing.com', '1973-02-01', 'I'),
(30, 'thomas', 'broussard', 'tbr@tbr.com', '2015-05-15', 'I'),
(33, 'thomas', 'broussard', 'tbr@tbr1.com', '2015-05-05', 'I'),
(45, 'something', 'recoved', 'something@happend.com', '2015-11-27', 'I'),
(47, 'lkjlj', 'uoi', 'jk@dfsa.com', '1876-03-02', 'I'),
(48, 'jklj', 'jkjkl', 'ewrq@kljkl.com', '1977-04-03', 'I'),
(53, 'first', 'lasts', 'some@some.com', '2015-11-04', 'I'),
(54, 'kjk', 'jkjkj', 'jkhj@kjljhlkjl.com', '2015-11-30', 'I'),
(55, 'gjhjjkhj', 'kuhkh', 'iuiouo@jlk.vopm', '2015-12-15', 'I');

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE IF NOT EXISTS `tb_users` (
  `user_id` int(20) NOT NULL COMMENT 'ID used for sessions and FK for tb_users',
  `user_name` varchar(20) COLLATE utf8_bin NOT NULL COMMENT 'User Name',
  `user_password` varchar(20) COLLATE utf8_bin NOT NULL COMMENT 'Password',
  `user_status` enum('A','D') COLLATE utf8_bin NOT NULL DEFAULT 'A' COMMENT 'Status: A->Active, D->De-active',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `user_name_2` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Used for authentication of the users for the application';

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`user_id`, `user_name`, `user_password`, `user_status`) VALUES
(1, 'epita', 'password', 'A');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD CONSTRAINT `tb_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tb_userdetails` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
