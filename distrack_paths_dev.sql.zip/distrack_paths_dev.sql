-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Aug 17, 2016 at 07:25 PM
-- Server version: 5.6.30
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `distrack_paths_dev`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`distrack`@`localhost` PROCEDURE `dissertationflow`(IN `Std_Id` INT(255), IN `did` INT(255), IN `rid` INT(20), IN `sid` INT(20), IN `rel` INT(20), IN `msg` TEXT CHARSET utf8, IN `Staff` INT(255), IN `Sts` CHAR, IN `Nid` INT(255), IN `Dstamp` DATETIME, OUT `hid` INT(255))
    DETERMINISTIC
BEGIN
DECLARE RelSts CHAR;
IF(Staff < 1) THEN
	SELECT staff_id INTO Nid FROM tb_student_staff_rel WHERE dissertation_id=did AND std_id=Std_Id AND role_id=rid LIMIT 0,1;	
UPDATE tb_student_staff_rel SET rel_status='S' WHERE dissertation_id=did AND std_id=Std_Id AND role_id=rid AND staff_id=Nid;
ELSE
    IF (Sts = 'M') THEN
    	SET @RelSts:='P';
    ELSE
    	SET @RelSts:='C';
    END IF;
	UPDATE tb_student_staff_rel SET rel_status=@RelSts WHERE dissertation_id=did AND std_id=Std_Id AND role_id=rid AND staff_id=Staff;
END IF;
  INSERT INTO tb_dissertation_history
SET
        std_id=Std_Id, dissertation_id=did, role_id=rid, staff_id=Staff, stage_id=sid, comments=msg, status=Sts, next_id=Nid, next_order=rel, doc=Dstamp;
	SELECT LAST_INSERT_ID() INTO hid ;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_cohort`
--

CREATE TABLE IF NOT EXISTS `tb_cohort` (
  `cohort_id` int(255) NOT NULL AUTO_INCREMENT,
  `cohort_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `cohort_ref` varchar(255) CHARACTER SET latin1 NOT NULL,
  `cohort_edate` date NOT NULL,
  `cohort_languages` varchar(20) CHARACTER SET latin1 NOT NULL,
  `cohort_description` text CHARACTER SET latin1 NOT NULL,
  `cohort_status` enum('A','D') CHARACTER SET latin1 NOT NULL DEFAULT 'A',
  `cohort_created` int(255) NOT NULL,
  `cohort_modified` int(255) NOT NULL DEFAULT '0',
  `cohort_doc` datetime NOT NULL,
  `cohort_dom` datetime NOT NULL,
  PRIMARY KEY (`cohort_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tb_cohort`
--

INSERT INTO `tb_cohort` (`cohort_id`, `cohort_name`, `cohort_ref`, `cohort_edate`, `cohort_languages`, `cohort_description`, `cohort_status`, `cohort_created`, `cohort_modified`, `cohort_doc`, `cohort_dom`) VALUES
(3, '2003', '1234', '2013-09-16', '5', 'Cohort Description', 'A', 27, 1, '2013-10-03 17:41:19', '2014-12-17 12:22:19'),
(4, '2004', '12345', '2013-10-02', '4,5,6', 'Cohort Description', 'A', 27, 0, '2013-10-03 17:42:00', '0000-00-00 00:00:00'),
(5, '2005', '123458', '2013-10-01', '', 'Cohort Description', 'A', 27, 2, '2013-10-03 17:42:42', '2013-12-18 05:52:48'),
(6, '2011 WA', '2011 WA', '2014-04-15', '', '', 'A', 7, 0, '2014-04-11 21:25:05', '0000-00-00 00:00:00'),
(8, '2015 WA', '7', '2015-03-18', '1,2', '2015 cohort in West Africa', 'D', 7, 2, '2014-12-12 10:27:30', '2015-09-09 11:22:17');

-- --------------------------------------------------------

--
-- Table structure for table `tb_concentration`
--

CREATE TABLE IF NOT EXISTS `tb_concentration` (
  `concentration_id` int(255) NOT NULL AUTO_INCREMENT,
  `concentration_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `concentration_ref` varchar(255) CHARACTER SET latin1 NOT NULL,
  `concentration_edate` date NOT NULL,
  `concentration_languages` varchar(20) CHARACTER SET latin1 NOT NULL,
  `concentration_description` text CHARACTER SET latin1 NOT NULL,
  `concentration_status` enum('A','D') CHARACTER SET latin1 NOT NULL DEFAULT 'A',
  `concentration_created` int(11) NOT NULL,
  `concentration_modified` int(11) NOT NULL,
  `concentration_doc` datetime NOT NULL,
  `concentration_dom` datetime NOT NULL,
  PRIMARY KEY (`concentration_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tb_concentration`
--

INSERT INTO `tb_concentration` (`concentration_id`, `concentration_name`, `concentration_ref`, `concentration_edate`, `concentration_languages`, `concentration_description`, `concentration_status`, `concentration_created`, `concentration_modified`, `concentration_doc`, `concentration_dom`) VALUES
(1, 'Biblical Theology', '1234', '2013-10-01', '4,5,6', 'Concentration Description', 'A', 27, 0, '2013-10-03 17:43:46', '0000-00-00 00:00:00'),
(2, 'Technology', '12345', '2013-10-01', '', 'Technology in churches', 'D', 27, 7, '2013-10-03 17:44:33', '2014-12-12 10:49:29'),
(3, 'Mission', '123456', '2013-10-01', '5', 'Concentration Description', 'A', 27, 1, '2013-10-03 17:45:16', '2014-12-17 12:22:23'),
(4, 'Education Test', '1234567', '2013-10-01', '1,2', 'Concentration Description', 'A', 27, 7, '2013-10-03 17:45:52', '2014-12-12 12:02:24'),
(5, 'Leadership', '12345678', '2013-12-18', '', 'Concentration Description', 'A', 2, 7, '2013-12-18 05:55:49', '2014-12-12 10:48:47'),
(7, 'Multimedia', '9', '2016-07-12', '', 'Using multimedia in churches', 'A', 2, 0, '2015-09-09 11:34:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_country`
--

CREATE TABLE IF NOT EXISTS `tb_country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `iso_code_2` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '',
  `iso_code_3` varchar(3) COLLATE utf8_bin NOT NULL DEFAULT '',
  `address_format` text COLLATE utf8_bin NOT NULL,
  `country_disp_ord` smallint(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=240 ;

--
-- Dumping data for table `tb_country`
--

INSERT INTO `tb_country` (`country_id`, `country_name`, `iso_code_2`, `iso_code_3`, `address_format`, `country_disp_ord`, `status`) VALUES
(1, 'Afghanistan', 'AF', 'AFG', '', 1, 1),
(2, 'Albania', 'AL', 'ALB', '', 3, 1),
(3, 'Algeria', 'DZ', 'DZA', '', 4, 1),
(4, 'American Samoa', 'AS', 'ASM', '', 5, 1),
(5, 'Andorra', 'AD', 'AND', '', 6, 1),
(6, 'Angola', 'AO', 'AGO', '', 7, 1),
(7, 'Anguilla', 'AI', 'AIA', '', 8, 1),
(8, 'Antarctica', 'AQ', 'ATA', '', 9, 1),
(9, 'Antigua and Barbuda', 'AG', 'ATG', '', 10, 1),
(10, 'Argentina', 'AR', 'ARG', '', 11, 1),
(11, 'Armenia', 'AM', 'ARM', '', 12, 1),
(12, 'Aruba', 'AW', 'ABW', '', 13, 1),
(13, 'Australia', 'AU', 'AUS', '', 14, 1),
(14, 'Austria', 'AT', 'AUT', '', 15, 1),
(15, 'Azerbaijan', 'AZ', 'AZE', '', 16, 1),
(16, 'Bahamas', 'BS', 'BHS', '', 17, 1),
(17, 'Bahrain', 'BH', 'BHR', '', 18, 1),
(18, 'Bangladesh', 'BD', 'BGD', '', 19, 1),
(19, 'Barbados', 'BB', 'BRB', '', 20, 1),
(20, 'Belarus', 'BY', 'BLR', '', 21, 1),
(21, 'Belgium', 'BE', 'BEL', '', 22, 1),
(22, 'Belize', 'BZ', 'BLZ', '', 23, 1),
(23, 'Benin', 'BJ', 'BEN', '', 24, 1),
(24, 'Bermuda', 'BM', 'BMU', '', 25, 1),
(25, 'Bhutan', 'BT', 'BTN', '', 26, 1),
(26, 'Bolivia', 'BO', 'BOL', '', 27, 1),
(27, 'Bosnia and Herzegowina', 'BA', 'BIH', '', 28, 1),
(28, 'Botswana', 'BW', 'BWA', '', 29, 1),
(29, 'Bouvet Island', 'BV', 'BVT', '', 30, 1),
(30, 'Brazil', 'BR', 'BRA', '', 31, 1),
(31, 'British Indian Ocean Territory', 'IO', 'IOT', '', 32, 1),
(32, 'Brunei Darussalam', 'BN', 'BRN', '', 33, 1),
(33, 'Bulgaria', 'BG', 'BGR', '', 34, 33),
(34, 'Burkina Faso', 'BF', 'BFA', '', 35, 1),
(35, 'Burundi', 'BI', 'BDI', '', 36, 1),
(36, 'Cambodia', 'KH', 'KHM', '', 37, 1),
(37, 'Cameroon', 'CM', 'CMR', '', 38, 1),
(38, 'Canada', 'CA', 'CAN', '', 39, 1),
(39, 'Cape Verde', 'CV', 'CPV', '', 40, 1),
(40, 'Cayman Islands', 'KY', 'CYM', '', 41, 1),
(41, 'Central African Republic', 'CF', 'CAF', '', 42, 1),
(42, 'Chad', 'TD', 'TCD', '', 43, 1),
(43, 'Chile', 'CL', 'CHL', '', 44, 1),
(44, 'China', 'CN', 'CHN', '', 45, 1),
(45, 'Christmas Island', 'CX', 'CXR', '', 46, 1),
(46, 'Cocos (Keeling) Islands', 'CC', 'CCK', '', 47, 1),
(47, 'Colombia', 'CO', 'COL', '', 48, 1),
(48, 'Comoros', 'KM', 'COM', '', 49, 1),
(49, 'Congo', 'CG', 'COG', '', 50, 1),
(50, 'Cook Islands', 'CK', 'COK', '', 51, 1),
(51, 'Costa Rica', 'CR', 'CRI', '', 52, 1),
(52, 'Cote D''Ivoire', 'CI', 'CIV', '', 53, 1),
(53, 'Croatia', 'HR', 'HRV', '', 54, 1),
(54, 'Cuba', 'CU', 'CUB', '', 55, 1),
(55, 'Cyprus', 'CY', 'CYP', '', 56, 1),
(56, 'Czech Republic', 'CZ', 'CZE', '', 57, 1),
(57, 'Denmark', 'DK', 'DNK', '', 58, 1),
(58, 'Djibouti', 'DJ', 'DJI', '', 59, 1),
(59, 'Dominica', 'DM', 'DMA', '', 60, 1),
(60, 'Dominican Republic', 'DO', 'DOM', '', 61, 1),
(61, 'East Timor', 'TP', 'TMP', '', 62, 1),
(62, 'Ecuador', 'EC', 'ECU', '', 63, 1),
(63, 'Egypt', 'EG', 'EGY', '', 64, 1),
(64, 'El Salvador', 'SV', 'SLV', '', 65, 1),
(65, 'Equatorial Guinea', 'GQ', 'GNQ', '', 66, 1),
(66, 'Eritrea', 'ER', 'ERI', '', 67, 1),
(67, 'Estonia', 'EE', 'EST', '', 68, 1),
(68, 'Ethiopia', 'ET', 'ETH', '', 69, 1),
(69, 'Falkland Islands (Malvinas)', 'FK', 'FLK', '', 70, 1),
(70, 'Faroe Islands', 'FO', 'FRO', '', 71, 1),
(71, 'Fiji', 'FJ', 'FJI', '', 72, 1),
(72, 'Finland', 'FI', 'FIN', '', 73, 1),
(73, 'France', 'FR', 'FRA', '', 74, 1),
(74, 'France, Metropolitan', 'FX', 'FXX', '', 75, 1),
(75, 'French Guiana', 'GF', 'GUF', '', 76, 1),
(76, 'French Polynesia', 'PF', 'PYF', '', 77, 1),
(77, 'French Southern Territories', 'TF', 'ATF', '', 78, 1),
(78, 'Gabon', 'GA', 'GAB', '', 79, 1),
(79, 'Gambia', 'GM', 'GMB', '', 80, 1),
(80, 'Georgia', 'GE', 'GEO', '', 81, 1),
(81, 'Germany', 'DE', 'DEU', '{company}\r\n{firstname} {lastname}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}', 82, 1),
(82, 'Ghana', 'GH', 'GHA', '', 83, 1),
(83, 'Gibraltar', 'GI', 'GIB', '', 84, 1),
(84, 'Greece', 'GR', 'GRC', '', 85, 1),
(85, 'Greenland', 'GL', 'GRL', '', 86, 1),
(86, 'Grenada', 'GD', 'GRD', '', 87, 1),
(87, 'Guadeloupe', 'GP', 'GLP', '', 88, 1),
(88, 'Guam', 'GU', 'GUM', '', 89, 1),
(89, 'Guatemala', 'GT', 'GTM', '', 90, 1),
(90, 'Guinea', 'GN', 'GIN', '', 91, 1),
(91, 'Guinea-bissau', 'GW', 'GNB', '', 92, 1),
(92, 'Guyana', 'GY', 'GUY', '', 93, 1),
(93, 'Haiti', 'HT', 'HTI', '', 94, 1),
(94, 'Heard and Mc Donald Islands', 'HM', 'HMD', '', 95, 1),
(95, 'Honduras', 'HN', 'HND', '', 96, 1),
(96, 'Hong Kong', 'HK', 'HKG', '', 97, 1),
(97, 'Hungary', 'HU', 'HUN', '', 98, 1),
(98, 'Iceland', 'IS', 'ISL', '', 99, 1),
(99, 'India', 'IN', 'IND', '', 100, 1),
(100, 'Indonesia', 'ID', 'IDN', '', 101, 1),
(101, 'Iran (Islamic Republic of)', 'IR', 'IRN', '', 102, 1),
(102, 'Iraq', 'IQ', 'IRQ', '', 103, 1),
(103, 'Ireland', 'IE', 'IRL', '', 104, 1),
(104, 'Israel', 'IL', 'ISR', '', 105, 1),
(105, 'Italy', 'IT', 'ITA', '', 106, 1),
(106, 'Jamaica', 'JM', 'JAM', '', 107, 1),
(107, 'Japan', 'JP', 'JPN', '', 108, 1),
(108, 'Jordan', 'JO', 'JOR', '', 109, 1),
(109, 'Kazakhstan', 'KZ', 'KAZ', '', 110, 1),
(110, 'Kenya', 'KE', 'KEN', '', 2, 1),
(111, 'Kiribati', 'KI', 'KIR', '', 111, 1),
(112, 'North Korea', 'KP', 'PRK', '', 112, 1),
(113, 'Korea, Republic of', 'KR', 'KOR', '', 113, 1),
(114, 'Kuwait', 'KW', 'KWT', '', 114, 1),
(115, 'Kyrgyzstan', 'KG', 'KGZ', '', 115, 1),
(116, 'Lao People''s Democratic Republic', 'LA', 'LAO', '', 116, 1),
(117, 'Latvia', 'LV', 'LVA', '', 117, 1),
(118, 'Lebanon', 'LB', 'LBN', '', 118, 1),
(119, 'Lesotho', 'LS', 'LSO', '', 119, 1),
(120, 'Liberia', 'LR', 'LBR', '', 120, 1),
(121, 'Libyan Arab Jamahiriya', 'LY', 'LBY', '', 121, 1),
(122, 'Liechtenstein', 'LI', 'LIE', '', 122, 1),
(123, 'Lithuania', 'LT', 'LTU', '', 123, 1),
(124, 'Luxembourg', 'LU', 'LUX', '', 124, 1),
(125, 'Macau', 'MO', 'MAC', '', 125, 1),
(126, 'Macedonia', 'MK', 'MKD', '', 126, 1),
(127, 'Madagascar', 'MG', 'MDG', '', 127, 1),
(128, 'Malawi', 'MW', 'MWI', '', 128, 1),
(129, 'Malaysia', 'MY', 'MYS', '', 129, 1),
(130, 'Maldives', 'MV', 'MDV', '', 130, 1),
(131, 'Mali', 'ML', 'MLI', '', 131, 1),
(132, 'Malta', 'MT', 'MLT', '', 132, 1),
(133, 'Marshall Islands', 'MH', 'MHL', '', 133, 1),
(134, 'Martinique', 'MQ', 'MTQ', '', 134, 1),
(135, 'Mauritania', 'MR', 'MRT', '', 135, 1),
(136, 'Mauritius', 'MU', 'MUS', '', 136, 1),
(137, 'Mayotte', 'YT', 'MYT', '', 137, 1),
(138, 'Mexico', 'MX', 'MEX', '', 138, 1),
(139, 'Micronesia, Federated States of', 'FM', 'FSM', '', 139, 1),
(140, 'Moldova, Republic of', 'MD', 'MDA', '', 140, 1),
(141, 'Monaco', 'MC', 'MCO', '', 141, 1),
(142, 'Mongolia', 'MN', 'MNG', '', 142, 1),
(143, 'Montserrat', 'MS', 'MSR', '', 143, 1),
(144, 'Morocco', 'MA', 'MAR', '', 144, 1),
(145, 'Mozambique', 'MZ', 'MOZ', '', 145, 1),
(146, 'Myanmar', 'MM', 'MMR', '', 146, 1),
(147, 'Namibia', 'NA', 'NAM', '', 147, 1),
(148, 'Nauru', 'NR', 'NRU', '', 148, 1),
(149, 'Nepal', 'NP', 'NPL', '', 149, 1),
(150, 'Netherlands', 'NL', 'NLD', '', 150, 1),
(151, 'Netherlands Antilles', 'AN', 'ANT', '', 151, 1),
(152, 'New Caledonia', 'NC', 'NCL', '', 152, 1),
(153, 'New Zealand', 'NZ', 'NZL', '', 153, 1),
(154, 'Nicaragua', 'NI', 'NIC', '', 154, 1),
(155, 'Niger', 'NE', 'NER', '', 155, 1),
(156, 'Nigeria', 'NG', 'NGA', '', 156, 1),
(157, 'Niue', 'NU', 'NIU', '', 157, 1),
(158, 'Norfolk Island', 'NF', 'NFK', '', 158, 1),
(159, 'Northern Mariana Islands', 'MP', 'MNP', '', 159, 1),
(160, 'Norway', 'NO', 'NOR', '', 160, 1),
(161, 'Oman', 'OM', 'OMN', '', 161, 1),
(162, 'Pakistan', 'PK', 'PAK', '', 162, 1),
(163, 'Palau', 'PW', 'PLW', '', 163, 1),
(164, 'Panama', 'PA', 'PAN', '', 164, 1),
(165, 'Papua New Guinea', 'PG', 'PNG', '', 165, 1),
(166, 'Paraguay', 'PY', 'PRY', '', 166, 1),
(167, 'Peru', 'PE', 'PER', '', 167, 1),
(168, 'Philippines', 'PH', 'PHL', '', 168, 1),
(169, 'Pitcairn', 'PN', 'PCN', '', 169, 1),
(170, 'Poland', 'PL', 'POL', '', 170, 1),
(171, 'Portugal', 'PT', 'PRT', '', 171, 1),
(172, 'Puerto Rico', 'PR', 'PRI', '', 172, 1),
(173, 'Qatar', 'QA', 'QAT', '', 173, 1),
(174, 'Reunion', 'RE', 'REU', '', 174, 1),
(175, 'Romania', 'RO', 'ROM', '', 175, 1),
(176, 'Russian Federation', 'RU', 'RUS', '', 176, 1),
(177, 'Rwanda', 'RW', 'RWA', '', 177, 1),
(178, 'Saint Kitts and Nevis', 'KN', 'KNA', '', 178, 1),
(179, 'Saint Lucia', 'LC', 'LCA', '', 179, 1),
(180, 'Saint Vincent and the Grenadines', 'VC', 'VCT', '', 180, 1),
(181, 'Samoa', 'WS', 'WSM', '', 181, 1),
(182, 'San Marino', 'SM', 'SMR', '', 182, 1),
(183, 'Sao Tome and Principe', 'ST', 'STP', '', 183, 1),
(184, 'Saudi Arabia', 'SA', 'SAU', '', 184, 1),
(185, 'Senegal', 'SN', 'SEN', '', 185, 1),
(186, 'Seychelles', 'SC', 'SYC', '', 186, 1),
(187, 'Sierra Leone', 'SL', 'SLE', '', 187, 1),
(188, 'Singapore', 'SG', 'SGP', '', 188, 1),
(189, 'Slovak Republic', 'SK', 'SVK', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city} {postcode}\r\n{zone}\r\n{country}', 189, 1),
(190, 'Slovenia', 'SI', 'SVN', '', 190, 1),
(191, 'Solomon Islands', 'SB', 'SLB', '', 191, 1),
(192, 'Somalia', 'SO', 'SOM', '', 192, 1),
(193, 'South Africa', 'ZA', 'ZAF', '', 193, 1),
(194, 'South Georgia &amp; South Sandwich Islands', 'GS', 'SGS', '', 194, 1),
(195, 'Spain', 'ES', 'ESP', '', 195, 1),
(196, 'Sri Lanka', 'LK', 'LKA', '', 196, 1),
(197, 'St. Helena', 'SH', 'SHN', '', 197, 1),
(198, 'St. Pierre and Miquelon', 'PM', 'SPM', '', 198, 1),
(199, 'Sudan', 'SD', 'SDN', '', 199, 1),
(200, 'Suriname', 'SR', 'SUR', '', 200, 1),
(201, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '', 201, 1),
(202, 'Swaziland', 'SZ', 'SWZ', '', 202, 1),
(203, 'Sweden', 'SE', 'SWE', '', 203, 1),
(204, 'Switzerland', 'CH', 'CHE', '', 204, 1),
(205, 'Syrian Arab Republic', 'SY', 'SYR', '', 205, 1),
(206, 'Taiwan', 'TW', 'TWN', '', 206, 1),
(207, 'Tajikistan', 'TJ', 'TJK', '', 207, 1),
(208, 'Tanzania, United Republic of', 'TZ', 'TZA', '', 208, 1),
(209, 'Thailand', 'TH', 'THA', '', 209, 1),
(210, 'Togo', 'TG', 'TGO', '', 210, 1),
(211, 'Tokelau', 'TK', 'TKL', '', 211, 1),
(212, 'Tonga', 'TO', 'TON', '', 212, 1),
(213, 'Trinidad and Tobago', 'TT', 'TTO', '', 213, 1),
(214, 'Tunisia', 'TN', 'TUN', '', 214, 1),
(215, 'Turkey', 'TR', 'TUR', '', 215, 1),
(216, 'Turkmenistan', 'TM', 'TKM', '', 216, 1),
(217, 'Turks and Caicos Islands', 'TC', 'TCA', '', 217, 1),
(218, 'Tuvalu', 'TV', 'TUV', '', 218, 1),
(219, 'Uganda', 'UG', 'UGA', '', 219, 1),
(220, 'Ukraine', 'UA', 'UKR', '', 220, 1),
(221, 'United Arab Emirates', 'AE', 'ARE', '', 221, 1),
(222, 'United Kingdom', 'GB', 'GBR', '', 222, 1),
(223, 'United States', 'US', 'USA', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city}, {zone} {postcode}\r\n{country}', 223, 1),
(224, 'United States Minor Outlying Islands', 'UM', 'UMI', '', 224, 1),
(225, 'Uruguay', 'UY', 'URY', '', 225, 1),
(226, 'Uzbekistan', 'UZ', 'UZB', '', 226, 1),
(227, 'Vanuatu', 'VU', 'VUT', '', 227, 1),
(228, 'Vatican City State (Holy See)', 'VA', 'VAT', '', 228, 1),
(229, 'Venezuela', 'VE', 'VEN', '', 229, 1),
(230, 'Viet Nam', 'VN', 'VNM', '', 230, 1),
(231, 'Virgin Islands (British)', 'VG', 'VGB', '', 231, 1),
(232, 'Virgin Islands (U.S.)', 'VI', 'VIR', '', 232, 1),
(233, 'Wallis and Futuna Islands', 'WF', 'WLF', '', 233, 1),
(234, 'Western Sahara', 'EH', 'ESH', '', 234, 1),
(235, 'Yemen', 'YE', 'YEM', '', 235, 1),
(236, 'Yugoslavia', 'YU', 'YUG', '', 236, 1),
(237, 'Democratic Republic of Congo', 'CD', 'COD', '', 237, 1),
(238, 'Zambia', 'ZM', 'ZMB', '', 238, 1),
(239, 'Zimbabwe', 'ZW', 'ZWE', '', 239, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_dissertation`
--

CREATE TABLE IF NOT EXISTS `tb_dissertation` (
  `dissertation_id` int(255) NOT NULL AUTO_INCREMENT,
  `std_id` int(11) NOT NULL,
  `disseration_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `disseration_desc` text COLLATE utf8_bin NOT NULL,
  `disseration_cohort` int(255) NOT NULL,
  `disseration_program` int(11) NOT NULL DEFAULT '1',
  `disseration_concentration` int(255) NOT NULL,
  `disseration_language` int(3) NOT NULL DEFAULT '1',
  `disseration_process_state` enum('N','A','S','C') COLLATE utf8_bin NOT NULL DEFAULT 'N' COMMENT 'N--Not Started, A--Allocated, S--PassingthroughStages, C--completed',
  `disseration_status` enum('A','D') CHARACTER SET latin1 NOT NULL DEFAULT 'A',
  `disseration_doc` datetime NOT NULL,
  `disseration_doe` datetime NOT NULL,
  PRIMARY KEY (`dissertation_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tb_dissertation`
--

INSERT INTO `tb_dissertation` (`dissertation_id`, `std_id`, `disseration_name`, `disseration_desc`, `disseration_cohort`, `disseration_program`, `disseration_concentration`, `disseration_language`, `disseration_process_state`, `disseration_status`, `disseration_doc`, `disseration_doe`) VALUES
(1, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:49:17', '0000-00-00 00:00:00'),
(2, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:49:27', '0000-00-00 00:00:00'),
(3, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:50:29', '0000-00-00 00:00:00'),
(4, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:51:17', '0000-00-00 00:00:00'),
(5, 3, 'something', '', 3, 2, 1, 2, 'A', 'A', '2013-12-12 16:57:19', '2015-09-28 06:28:16'),
(6, 3, 'french', '', 3, 1, 1, 2, 'A', 'A', '2013-12-12 17:58:56', '0000-00-00 00:00:00'),
(7, 3, 'Church unity in the 21st century, USA', '', 4, 1, 3, 1, 'S', 'A', '2013-12-12 17:59:43', '2014-12-14 12:27:46'),
(8, 5, 'Running with endurence as we the church faces internal challenges', '', 5, 1, 4, 1, 'A', 'A', '2013-12-18 05:27:17', '2014-12-14 12:29:09'),
(9, 5, 'Churches role in envouraging evangelists', '', 4, 1, 3, 2, 'A', 'A', '2013-12-18 05:45:50', '2014-12-14 12:29:44'),
(10, 5, 'Technical Skills', '', 5, 1, 5, 1, 'A', 'A', '2013-12-18 08:53:27', '2013-12-18 08:53:40'),
(11, 5, 'Knowledge', '', 5, 1, 1, 3, 'A', 'A', '2013-12-18 09:06:01', '2013-12-18 09:06:35'),
(12, 5, 'Latest Technologies', '', 5, 1, 5, 1, 'A', 'A', '2013-12-18 09:07:31', '0000-00-00 00:00:00'),
(13, 5, 'Educational necessities for the current day church', '', 5, 1, 4, 1, 'A', 'A', '2013-12-18 12:49:56', '2014-12-14 12:28:18'),
(14, 8, 'Phd:A Theoretical Framework for an Integrated Competency-Based Approach to Theological Education in the Assemblies of God, Ghana', '', 5, 1, 4, 1, 'S', 'A', '2014-01-01 02:18:43', '2015-09-28 06:23:47'),
(15, 11, 'A Theoretical Framework for Integrating Missions into Theological Education in the Assemblies of God, Liberia: A Strategy for Enhancing the Sending Capacity of the Church', '', 6, 1, 4, 1, 'S', 'A', '2014-04-11 21:26:04', '0000-00-00 00:00:00'),
(17, 11, 'Educational necessities for the current day church', '', 6, 1, 4, 2, 'A', 'A', '2014-12-13 23:59:56', '2014-12-17 05:13:08'),
(18, 8, 'A Theory of Leadership Emergence Among Pastors of Assemblies of God District in Texas, USA', '', 8, 1, 5, 1, 'S', 'A', '2014-12-14 04:30:19', '2014-12-14 12:44:38');

-- --------------------------------------------------------

--
-- Table structure for table `tb_dissertation_documents`
--

CREATE TABLE IF NOT EXISTS `tb_dissertation_documents` (
  `document_id` int(255) NOT NULL AUTO_INCREMENT,
  `document_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `document_path` varchar(255) COLLATE utf8_bin NOT NULL,
  `disseration_id` int(255) NOT NULL,
  `document_uploader` int(255) NOT NULL,
  `document_hid` int(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tb_dissertation_documents`
--

INSERT INTO `tb_dissertation_documents` (`document_id`, `document_name`, `document_path`, `disseration_id`, `document_uploader`, `document_hid`) VALUES
(1, 'Dissertation Tracking System.docx', '10_Dissertation_Tracking_System.docx', 14, 8, 10),
(2, '5.29483.00.00.100481-20140120.pdf', '12_5.29483.00.00.100481-20140120.pdf', 7, 3, 12),
(3, 'Answer to Chuck Wilson  Ettiene Zongo.docx', '15_Answer_to_Chuck_Wilson__Ettiene_Zongo.docx', 14, 7, 15),
(4, 'DDM Review Draft_with_Marvins_Changes_and_Title_Changes (1).docx', '15_DDM_Review_Draft_with_Marvins_Changes_and_Title_Changes_(1).docx', 14, 7, 15),
(5, '1.67255445-20140125.pdf', '18_1.67255445-20140125.pdf', 7, 2, 18),
(6, '1.67255307-20140125.pdf', '19_1.67255307-20140125.pdf', 7, 3, 19),
(7, 'SriKadari_2005_Prospectus_V1.docx', '21_SriKadari_2005_Prospectus_V1.docx', 14, 8, 21),
(8, 'TheoreticalFramework-Jimmy-Chapter1.docx', '29_TheoreticalFramework-Jimmy-Chapter1.docx', 15, 11, 29),
(9, 'SriKadari_2005_Prospectus_V1-commented by Dean Of Research.docx', '30_SriKadari_2005_Prospectus_V1-commented_by_Dean_Of_Research.docx', 14, 9, 30),
(10, 'DTS-Admin-Help-V2.0.docx', '34_DTS-Admin-Help-V2.0.docx', 15, 11, 34),
(11, 'Preliminary - A Theory of Leadership Emergence Among Pastors of Assemblies of God District in Texas.docx', '35_Preliminary_-_A_Theory_of_Leadership_Emergence_Among_Pastors_of_Assemblies_of_God_District_in_Texas.docx', 18, 8, 35),
(12, 'Cell_Structures_and_Functions_Student_Notes.doc', '36_Cell_Structures_and_Functions_Student_Notes.doc', 14, 8, 36);

-- --------------------------------------------------------

--
-- Table structure for table `tb_dissertation_history`
--

CREATE TABLE IF NOT EXISTS `tb_dissertation_history` (
  `history_id` int(255) NOT NULL AUTO_INCREMENT,
  `std_id` int(255) NOT NULL,
  `dissertation_id` int(255) NOT NULL,
  `staff_id` int(255) NOT NULL,
  `role_id` int(3) NOT NULL,
  `stage_id` int(3) NOT NULL,
  `comments` text COLLATE utf8_bin NOT NULL,
  `status` enum('A','C','S','M','F') COLLATE utf8_bin DEFAULT NULL,
  `next_id` int(255) NOT NULL DEFAULT '0',
  `next_order` int(3) NOT NULL DEFAULT '0',
  `chk_staff` int(255) NOT NULL DEFAULT '0',
  `doc` datetime NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tb_dissertation_history`
--

INSERT INTO `tb_dissertation_history` (`history_id`, `std_id`, `dissertation_id`, `staff_id`, `role_id`, `stage_id`, `comments`, `status`, `next_id`, `next_order`, `chk_staff`, `doc`) VALUES
(1, 3, 5, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(2, 3, 6, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(3, 3, 7, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(4, 5, 8, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(5, 5, 9, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(6, 5, 10, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(7, 5, 11, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(8, 5, 12, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(9, 8, 14, 0, 0, 0, '', 'S', 8, 0, 0, '0000-00-00 00:00:00'),
(10, 8, 14, 0, 1, 1, 'This is a test note / <STRONG>comments.</STRONG>', 'S', 7, 1, 0, '2014-01-01 02:22:53'),
(14, 3, 7, 0, 1, 1, '', 'S', 2, 1, 0, '2014-01-24 16:28:07'),
(15, 8, 14, 7, 1, 1, '<P>This is a testing <STRONG>comment</STRONG>...</P>\r\n<P>&nbsp;</P>', 'M', 8, 1, 0, '2014-01-25 15:59:23'),
(16, 8, 14, 0, 1, 1, 'Sorry sir.. please review once again.', 'S', 7, 1, 0, '2014-01-25 16:04:54'),
(17, 8, 14, 7, 1, 1, 'I like it.', 'A', 8, 2, 0, '2014-01-25 16:05:20'),
(18, 3, 7, 2, 1, 1, 'something is important', 'A', 3, 2, 0, '0000-00-00 00:00:00'),
(19, 3, 7, 0, 2, 2, 'llkjkljlkjklj ljjl;kjkl', 'S', 4, 2, 0, '2014-01-27 20:28:08'),
(20, 5, 13, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(21, 8, 14, 0, 2, 2, 'Dr. Wilson,&nbsp;<div>Please review the attached Prospectus for my work.</div><div><br /></div><div>Thanks,</div><div>Sri</div>', 'S', 7, 2, 0, '2014-01-28 10:58:01'),
(22, 8, 14, 7, 2, 2, 'Dr. Gilbert, please review the documentation from our student. I approve this.', 'A', 9, 3, 0, '2014-01-28 11:36:56'),
(23, 11, 15, 0, 0, 0, '', 'S', 11, 0, 0, '0000-00-00 00:00:00'),
(24, 11, 15, 0, 1, 1, 'adadf', 'S', 7, 1, 0, '2014-04-11 21:29:42'),
(25, 11, 15, 7, 1, 1, '', 'A', 11, 2, 0, '2014-04-11 21:30:39'),
(26, 11, 15, 0, 2, 2, 'dadadf', 'S', 7, 2, 0, '2014-04-11 21:31:43'),
(27, 11, 15, 7, 2, 2, '', 'A', 9, 3, 0, '2014-04-11 21:33:57'),
(28, 11, 15, 9, 5, 2, '', 'A', 11, 4, 0, '2014-04-11 21:37:55'),
(29, 11, 15, 0, 4, 3, 'Please review the attached Chapter 1.<br /><br />I will follow-up with Mr.John Smith for the open questions.<br /><br />Thanks,<br />Jimmy.', 'S', 7, 4, 0, '2014-11-15 03:20:36'),
(30, 8, 14, 9, 5, 2, '<div>Hi Sri,&nbsp;</div><div><br /></div>The prospectus looks good to me. &nbsp;My only comment is that on page 12, the theme is not clear. &nbsp;I reworded it and attached the file. &nbsp;Check it.&nbsp;<div>Otherwise, I approve it.</div><div><br /></div><div>Thanks,</div><div>Dr. Gilbert</div>', 'C', 8, 4, 0, '2014-11-15 05:31:44'),
(31, 8, 18, 0, 0, 0, '', 'S', 8, 0, 0, '0000-00-00 00:00:00'),
(32, 11, 17, 0, 0, 0, '', 'S', 11, 0, 0, '0000-00-00 00:00:00'),
(33, 11, 15, 7, 4, 3, 'job completed<div>This is testing</div><div>done by</div><div>Dave <span style="font-weight: bold;">and </span>Sri</div><div><br /></div>', 'A', 11, 5, 0, '2015-03-12 22:16:21'),
(34, 11, 15, 0, 4, 4, 'Testing and email functionality', 'S', 7, 5, 0, '2015-09-05 05:18:55'),
(35, 8, 18, 0, 1, 1, 'Dear Bill Kirsch,<div><br /></div><div>Please find attached is my Preliminary Literature for review.</div><div><br /></div><div>Thanks,</div><div>Sri</div>', 'S', 10, 1, 0, '2015-09-08 02:39:17'),
(36, 8, 14, 0, 4, 3, 'Dr. Gilbert,<div>Please review chapter 1, attached with this email.</div><div>Thanks,</div><div>Sri</div>', 'S', 9, 4, 0, '2016-02-01 03:22:36');

-- --------------------------------------------------------

--
-- Table structure for table `tb_languages`
--

CREATE TABLE IF NOT EXISTS `tb_languages` (
  `lang_id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `lang_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `lang_code` char(4) COLLATE utf8_bin NOT NULL,
  `lang_doc` datetime NOT NULL,
  `lang_dom` datetime NOT NULL,
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `lang_name` (`lang_name`,`lang_code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Languages' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tb_languages`
--

INSERT INTO `tb_languages` (`lang_id`, `lang_name`, `lang_code`, `lang_doc`, `lang_dom`) VALUES
(1, 'English', 'Engl', '2013-10-03 16:38:03', '2014-12-12 12:06:14'),
(2, 'French', 'Fren', '2013-10-03 16:38:34', '0000-00-00 00:00:00'),
(3, 'Other', 'Othe', '2013-10-03 16:38:51', '2014-12-17 12:21:51'),
(5, 'Swahili', 'Kny1', '2014-12-13 01:04:02', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_programs`
--

CREATE TABLE IF NOT EXISTS `tb_programs` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `program_mandatory` enum('Y','N') CHARACTER SET latin1 NOT NULL DEFAULT 'N',
  PRIMARY KEY (`program_id`),
  UNIQUE KEY `program_name` (`program_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tb_programs`
--

INSERT INTO `tb_programs` (`program_id`, `program_name`, `program_mandatory`) VALUES
(1, 'DMin', 'Y'),
(2, 'PhD', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `tb_roles`
--

CREATE TABLE IF NOT EXISTS `tb_roles` (
  `role_id` smallint(3) NOT NULL AUTO_INCREMENT,
  `role_title` varchar(255) COLLATE utf8_bin NOT NULL,
  `role_sc` varchar(5) COLLATE utf8_bin NOT NULL,
  `role_desc` text COLLATE utf8_bin NOT NULL,
  `role_num` smallint(2) NOT NULL DEFAULT '1',
  `role_disp_ord` smallint(3) NOT NULL DEFAULT '0',
  `role_reqd` tinyint(1) NOT NULL DEFAULT '0',
  `role_constraints` tinyint(2) NOT NULL DEFAULT '0',
  `role_status` enum('A','D') COLLATE utf8_bin NOT NULL DEFAULT 'A',
  `role_doc` datetime NOT NULL,
  `role_dom` datetime NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_title` (`role_title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Different Roles RES992, RES993 ..... ' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tb_roles`
--

INSERT INTO `tb_roles` (`role_id`, `role_title`, `role_sc`, `role_desc`, `role_num`, `role_disp_ord`, `role_reqd`, `role_constraints`, `role_status`, `role_doc`, `role_dom`) VALUES
(1, 'RES 9103 Faculty', '9103', 'RES 9103 Faculty', 1, 1, 1, 0, 'A', '2013-09-04 00:00:00', '2015-09-08 02:34:52'),
(2, 'RES 9153 Faculty', '9153', 'Second Level Faculty', 1, 2, 0, 0, 'A', '0000-00-00 00:00:00', '2015-09-08 02:35:09'),
(3, 'RES 9203 Faculty', '', 'Level 3', 1, 4, 0, 0, 'A', '2013-09-04 00:00:00', '2014-11-01 21:17:34'),
(4, 'Research Supervisor', 'DS', 'Research Supervisor', 1, 3, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:59:14'),
(5, 'Dean of Research', 'DR', 'Dean', 1, 5, 0, 0, 'A', '2013-09-04 00:00:00', '0000-00-00 00:00:00'),
(6, 'Second Reader', 'SR', 'Dean', 1, 6, 0, 0, 'A', '2013-09-04 00:00:00', '0000-00-00 00:00:00'),
(7, 'Research Coordinator', 'DC', 'Research Coordinator', 1, 7, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:58:30'),
(8, 'Research Proposal Review Board', 'DPRB', 'Research Proposal Review Board', 1, 9, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:58:55'),
(9, 'Institutional Editor', 'InsED', 'Dean', 1, 8, 0, 0, 'A', '2013-09-04 00:00:00', '2014-10-29 06:47:16'),
(10, 'Research Committee', 'DCom', 'Research Committee', 1, 10, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:57:44'),
(11, 'Provost', 'Provo', '', 1, 11, 0, 0, 'A', '2013-09-24 00:00:00', '2015-09-08 02:35:02'),
(13, 'CFS', 'CFS', '', 1, 12, 1, 1, 'A', '2013-12-18 13:31:56', '2014-07-30 23:10:56');

-- --------------------------------------------------------

--
-- Table structure for table `tb_role_stage_rel`
--

CREATE TABLE IF NOT EXISTS `tb_role_stage_rel` (
  `stg_role_id` int(255) NOT NULL AUTO_INCREMENT,
  `stg_id` int(3) NOT NULL,
  `role_id` int(3) NOT NULL,
  `rel_ord` int(2) NOT NULL DEFAULT '1',
  `nextstep` int(3) NOT NULL DEFAULT '0',
  `failstep` int(3) NOT NULL DEFAULT '0',
  `chkrole` int(3) NOT NULL DEFAULT '0',
  `mail_to` int(11) NOT NULL,
  PRIMARY KEY (`stg_role_id`),
  UNIQUE KEY `rel_ord` (`rel_ord`),
  KEY `rel_ord_2` (`rel_ord`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tb_role_stage_rel`
--

INSERT INTO `tb_role_stage_rel` (`stg_role_id`, `stg_id`, `role_id`, `rel_ord`, `nextstep`, `failstep`, `chkrole`, `mail_to`) VALUES
(1, 1, 1, 1, 0, 0, 0, 0),
(2, 2, 2, 2, 3, 0, 0, 0),
(3, 2, 5, 3, 0, 2, 0, 4),
(4, 3, 4, 4, 0, 0, 0, 0),
(5, 4, 4, 5, 0, 0, 0, 0),
(6, 5, 4, 6, 0, 0, 0, 0),
(7, 6, 4, 7, 8, 0, 0, 0),
(8, 6, 5, 8, 0, 7, 0, 0),
(9, 7, 4, 9, 10, 0, 0, 0),
(10, 7, 3, 10, 11, 9, 0, 0),
(11, 7, 7, 11, 12, 9, 12, 0),
(12, 7, 8, 12, 0, 9, 0, 4),
(13, 8, 4, 13, 14, 0, 0, 0),
(14, 8, 6, 14, 0, 13, 0, 0),
(15, 9, 4, 15, 16, 0, 0, 0),
(16, 9, 6, 16, 17, 15, 0, 0),
(17, 9, 7, 17, 18, 15, 12, 0),
(18, 9, 9, 18, 0, 15, 0, 0),
(19, 10, 10, 19, 20, 0, 0, 0),
(20, 10, 11, 20, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_stages`
--

CREATE TABLE IF NOT EXISTS `tb_stages` (
  `stg_id` int(255) NOT NULL AUTO_INCREMENT,
  `stg_title` varchar(255) NOT NULL,
  `stg_description` text NOT NULL,
  `stg_order` int(2) NOT NULL,
  `stg_sts` enum('A','D') NOT NULL DEFAULT 'A',
  `stg_doc` datetime NOT NULL,
  `stg_dom` datetime NOT NULL,
  PRIMARY KEY (`stg_id`),
  UNIQUE KEY `stg_title` (`stg_title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tb_stages`
--

INSERT INTO `tb_stages` (`stg_id`, `stg_title`, `stg_description`, `stg_order`, `stg_sts`, `stg_doc`, `stg_dom`) VALUES
(1, 'Prelim. Lit. Review', '', 1, 'A', '2013-09-15 00:00:00', '0000-00-00 00:00:00'),
(2, 'Prospectus', '', 2, 'A', '2013-09-09 00:00:00', '0000-00-00 00:00:00'),
(3, 'Chapter 1', '', 3, 'A', '2013-09-11 00:00:00', '0000-00-00 00:00:00'),
(4, 'Chapter 2', '', 4, 'A', '2013-09-10 00:00:00', '0000-00-00 00:00:00'),
(5, 'Chapter 3', '', 5, 'A', '2013-09-11 00:00:00', '0000-00-00 00:00:00'),
(6, 'Chapter 4', '', 6, 'A', '2013-09-09 00:00:00', '0000-00-00 00:00:00'),
(7, 'Proposal', 'Proposal', 7, 'A', '2013-10-08 00:00:00', '2014-11-06 12:03:05'),
(8, 'Chapter 5', '', 8, 'A', '2013-09-11 00:00:00', '0000-00-00 00:00:00'),
(9, 'Chapter 6', '', 9, 'A', '2013-09-09 00:00:00', '0000-00-00 00:00:00'),
(10, 'Defense', '', 10, 'A', '2013-09-15 00:00:00', '0000-00-00 00:00:00'),
(11, 'Chapter7', '', 11, 'A', '2013-12-18 13:01:09', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_student_staff_rel`
--

CREATE TABLE IF NOT EXISTS `tb_student_staff_rel` (
  `rel_id` int(255) NOT NULL AUTO_INCREMENT,
  `std_id` int(255) NOT NULL,
  `dissertation_id` int(255) NOT NULL,
  `role_id` int(5) NOT NULL,
  `staff_id` int(255) NOT NULL,
  `rel_status` enum('A','S','P','C') COLLATE utf8_bin NOT NULL DEFAULT 'A' COMMENT 'A:Assigned,S:Start, P:Process, C:Completed',
  `rel_doc` datetime NOT NULL,
  PRIMARY KEY (`rel_id`),
  KEY `std_id` (`std_id`),
  KEY `dissertation_id` (`dissertation_id`),
  KEY `role_id` (`role_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='staff assigned to student' AUTO_INCREMENT=225 ;

--
-- Dumping data for table `tb_student_staff_rel`
--

INSERT INTO `tb_student_staff_rel` (`rel_id`, `std_id`, `dissertation_id`, `role_id`, `staff_id`, `rel_status`, `rel_doc`) VALUES
(13, 3, 5, 1, 4, 'A', '2013-12-12 17:58:11'),
(14, 3, 5, 2, 4, 'A', '2013-12-12 17:58:11'),
(15, 3, 5, 3, 4, 'A', '2013-12-12 17:58:11'),
(16, 3, 5, 4, 4, 'A', '2013-12-12 17:58:11'),
(17, 3, 5, 5, 4, 'A', '2013-12-12 17:58:11'),
(18, 3, 5, 6, 4, 'A', '2013-12-12 17:58:11'),
(19, 3, 5, 7, 0, 'A', '2013-12-12 17:58:11'),
(20, 3, 5, 9, 0, 'A', '2013-12-12 17:58:11'),
(21, 3, 5, 11, 0, 'A', '2013-12-12 17:58:11'),
(22, 3, 5, 12, 0, 'A', '2013-12-12 17:58:11'),
(11, 3, 5, 8, 0, 'A', '2013-12-12 16:58:12'),
(12, 3, 5, 10, 0, 'A', '2013-12-12 16:58:12'),
(172, 3, 6, 1, 4, 'A', '2014-07-02 07:28:13'),
(173, 3, 6, 2, 10, 'A', '2014-07-02 07:28:13'),
(174, 3, 6, 3, 0, 'A', '2014-07-02 07:28:13'),
(175, 3, 6, 4, 0, 'A', '2014-07-02 07:28:13'),
(176, 3, 6, 5, 0, 'A', '2014-07-02 07:28:13'),
(177, 3, 6, 6, 0, 'A', '2014-07-02 07:28:13'),
(178, 3, 6, 7, 0, 'A', '2014-07-02 07:28:13'),
(179, 3, 6, 9, 0, 'A', '2014-07-02 07:28:13'),
(180, 3, 6, 11, 0, 'A', '2014-07-02 07:28:13'),
(32, 3, 6, 12, 4, 'A', '2013-12-12 17:59:21'),
(33, 3, 6, 8, 0, 'A', '2013-12-12 17:59:21'),
(34, 3, 6, 10, 0, 'A', '2013-12-12 17:59:21'),
(35, 3, 7, 1, 2, 'C', '2013-12-18 05:20:09'),
(36, 3, 7, 2, 4, 'S', '2013-12-18 05:20:09'),
(37, 3, 7, 3, 2, 'A', '2013-12-18 05:20:09'),
(38, 3, 7, 4, 0, 'A', '2013-12-18 05:20:09'),
(39, 3, 7, 5, 0, 'A', '2013-12-18 05:20:09'),
(40, 3, 7, 6, 2, 'A', '2013-12-18 05:20:09'),
(41, 3, 7, 7, 0, 'A', '2013-12-18 05:20:09'),
(42, 3, 7, 9, 0, 'A', '2013-12-18 05:20:09'),
(43, 3, 7, 11, 0, 'A', '2013-12-18 05:20:09'),
(44, 3, 7, 8, 0, 'A', '2013-12-18 05:20:09'),
(45, 3, 7, 10, 0, 'A', '2013-12-18 05:20:09'),
(57, 5, 8, 1, 2, 'A', '2013-12-18 05:34:39'),
(58, 5, 8, 2, 4, 'A', '2013-12-18 05:34:39'),
(59, 5, 8, 3, 2, 'A', '2013-12-18 05:34:39'),
(60, 5, 8, 4, 4, 'A', '2013-12-18 05:34:39'),
(61, 5, 8, 5, 0, 'A', '2013-12-18 05:34:39'),
(62, 5, 8, 6, 0, 'A', '2013-12-18 05:34:39'),
(63, 5, 8, 7, 0, 'A', '2013-12-18 05:34:39'),
(64, 5, 8, 9, 0, 'A', '2013-12-18 05:34:39'),
(65, 5, 8, 11, 0, 'A', '2013-12-18 05:34:39'),
(55, 5, 8, 8, 0, 'A', '2013-12-18 05:34:09'),
(56, 5, 8, 10, 0, 'A', '2013-12-18 05:34:09'),
(66, 5, 9, 1, 2, 'A', '2013-12-18 05:46:43'),
(67, 5, 9, 2, 6, 'A', '2013-12-18 05:46:43'),
(68, 5, 9, 3, 2, 'A', '2013-12-18 05:46:43'),
(69, 5, 9, 4, 6, 'A', '2013-12-18 05:46:43'),
(70, 5, 9, 5, 0, 'A', '2013-12-18 05:46:43'),
(71, 5, 9, 6, 0, 'A', '2013-12-18 05:46:43'),
(72, 5, 9, 7, 0, 'A', '2013-12-18 05:46:43'),
(73, 5, 9, 9, 0, 'A', '2013-12-18 05:46:43'),
(74, 5, 9, 11, 0, 'A', '2013-12-18 05:46:43'),
(75, 5, 9, 12, 6, 'A', '2013-12-18 05:46:43'),
(76, 5, 9, 8, 0, 'A', '2013-12-18 05:46:43'),
(77, 5, 9, 10, 0, 'A', '2013-12-18 05:46:43'),
(78, 5, 10, 1, 2, 'A', '2013-12-18 08:55:04'),
(79, 5, 10, 2, 2, 'A', '2013-12-18 08:55:04'),
(80, 5, 10, 3, 6, 'A', '2013-12-18 08:55:04'),
(81, 5, 10, 4, 6, 'A', '2013-12-18 08:55:04'),
(82, 5, 10, 5, 0, 'A', '2013-12-18 08:55:04'),
(83, 5, 10, 6, 0, 'A', '2013-12-18 08:55:04'),
(84, 5, 10, 7, 0, 'A', '2013-12-18 08:55:04'),
(85, 5, 10, 9, 0, 'A', '2013-12-18 08:55:04'),
(86, 5, 10, 11, 0, 'A', '2013-12-18 08:55:04'),
(87, 5, 10, 8, 0, 'A', '2013-12-18 08:55:04'),
(88, 5, 10, 10, 0, 'A', '2013-12-18 08:55:04'),
(89, 5, 11, 1, 2, 'A', '2013-12-18 09:14:46'),
(90, 5, 11, 2, 6, 'A', '2013-12-18 09:14:46'),
(91, 5, 11, 3, 2, 'A', '2013-12-18 09:14:46'),
(92, 5, 11, 4, 6, 'A', '2013-12-18 09:14:46'),
(93, 5, 11, 5, 0, 'A', '2013-12-18 09:14:46'),
(94, 5, 11, 6, 0, 'A', '2013-12-18 09:14:46'),
(95, 5, 11, 7, 0, 'A', '2013-12-18 09:14:46'),
(96, 5, 11, 9, 0, 'A', '2013-12-18 09:14:46'),
(97, 5, 11, 11, 0, 'A', '2013-12-18 09:14:46'),
(98, 5, 11, 12, 6, 'A', '2013-12-18 09:14:46'),
(99, 5, 11, 8, 0, 'A', '2013-12-18 09:14:46'),
(100, 5, 11, 10, 0, 'A', '2013-12-18 09:14:46'),
(101, 5, 12, 1, 2, 'A', '2013-12-18 11:09:40'),
(102, 5, 12, 2, 6, 'A', '2013-12-18 11:09:40'),
(103, 5, 12, 3, 2, 'A', '2013-12-18 11:09:40'),
(104, 5, 12, 4, 6, 'A', '2013-12-18 11:09:40'),
(105, 5, 12, 5, 0, 'A', '2013-12-18 11:09:40'),
(106, 5, 12, 6, 0, 'A', '2013-12-18 11:09:40'),
(107, 5, 12, 7, 0, 'A', '2013-12-18 11:09:40'),
(108, 5, 12, 9, 0, 'A', '2013-12-18 11:09:40'),
(109, 5, 12, 11, 0, 'A', '2013-12-18 11:09:40'),
(110, 5, 12, 8, 0, 'A', '2013-12-18 11:09:40'),
(111, 5, 12, 10, 0, 'A', '2013-12-18 11:09:40'),
(112, 8, 14, 1, 7, 'C', '2014-01-01 02:19:24'),
(144, 8, 14, 2, 7, 'C', '2014-01-28 11:35:13'),
(188, 8, 14, 3, 9, 'A', '2014-11-15 03:10:52'),
(187, 8, 14, 4, 9, 'S', '2014-11-15 03:10:52'),
(189, 8, 14, 5, 9, 'C', '2014-11-15 03:10:52'),
(190, 8, 14, 6, 9, 'A', '2014-11-15 03:10:52'),
(191, 8, 14, 7, 0, 'A', '2014-11-15 03:10:52'),
(192, 8, 14, 9, 0, 'A', '2014-11-15 03:10:52'),
(193, 8, 14, 11, 0, 'A', '2014-11-15 03:10:52'),
(121, 8, 14, 8, 0, 'A', '2014-01-01 02:19:24'),
(122, 8, 14, 10, 0, 'A', '2014-01-01 02:19:24'),
(123, 8, 14, 13, 0, 'A', '2014-01-01 02:19:24'),
(124, 5, 13, 1, 7, 'A', '2014-01-28 10:40:00'),
(125, 5, 13, 2, 0, 'A', '2014-01-28 10:40:00'),
(126, 5, 13, 3, 0, 'A', '2014-01-28 10:40:00'),
(127, 5, 13, 4, 0, 'A', '2014-01-28 10:40:00'),
(128, 5, 13, 5, 0, 'A', '2014-01-28 10:40:00'),
(129, 5, 13, 6, 0, 'A', '2014-01-28 10:40:00'),
(130, 5, 13, 7, 0, 'A', '2014-01-28 10:40:00'),
(131, 5, 13, 9, 0, 'A', '2014-01-28 10:40:00'),
(132, 5, 13, 11, 0, 'A', '2014-01-28 10:40:00'),
(133, 5, 13, 8, 0, 'A', '2014-01-28 10:40:00'),
(134, 5, 13, 10, 0, 'A', '2014-01-28 10:40:00'),
(135, 5, 13, 13, 0, 'A', '2014-01-28 10:40:00'),
(152, 11, 15, 1, 7, 'C', '2014-04-11 21:27:25'),
(164, 11, 15, 2, 7, 'C', '2014-04-11 21:33:29'),
(220, 11, 15, 3, 0, 'A', '2015-03-12 22:21:04'),
(182, 11, 15, 4, 7, 'S', '2014-07-02 07:29:00'),
(167, 11, 15, 5, 9, 'C', '2014-04-11 21:33:29'),
(221, 11, 15, 6, 0, 'A', '2015-03-12 22:21:04'),
(222, 11, 15, 7, 2, 'A', '2015-03-12 22:21:04'),
(223, 11, 15, 9, 4, 'A', '2015-03-12 22:21:04'),
(224, 11, 15, 11, 0, 'A', '2015-03-12 22:21:04'),
(161, 11, 15, 8, 0, 'A', '2014-04-11 21:27:25'),
(162, 11, 15, 10, 0, 'A', '2014-04-11 21:27:25'),
(163, 11, 15, 13, 0, 'A', '2014-04-11 21:27:25'),
(194, 8, 18, 1, 10, 'S', '2014-12-17 05:12:26'),
(195, 8, 18, 2, 0, 'A', '2014-12-17 05:12:26'),
(196, 8, 18, 4, 7, 'A', '2014-12-17 05:12:26'),
(197, 8, 18, 3, 2, 'A', '2014-12-17 05:12:26'),
(198, 8, 18, 5, 9, 'A', '2014-12-17 05:12:26'),
(199, 8, 18, 6, 10, 'A', '2014-12-17 05:12:26'),
(200, 8, 18, 7, 9, 'A', '2014-12-17 05:12:26'),
(201, 8, 18, 9, 4, 'A', '2014-12-17 05:12:26'),
(202, 8, 18, 8, 10, 'A', '2014-12-17 05:12:26'),
(203, 8, 18, 8, 4, 'A', '2014-12-17 05:12:26'),
(204, 8, 18, 8, 7, 'A', '2014-12-17 05:12:26'),
(205, 8, 18, 11, 0, 'A', '2014-12-17 05:12:26'),
(206, 8, 18, 10, 0, 'A', '2014-12-17 05:12:26'),
(207, 11, 17, 1, 10, 'A', '2014-12-17 05:18:32'),
(208, 11, 17, 2, 0, 'A', '2014-12-17 05:18:32'),
(209, 11, 17, 4, 4, 'A', '2014-12-17 05:18:32'),
(210, 11, 17, 3, 10, 'A', '2014-12-17 05:18:32'),
(211, 11, 17, 5, 9, 'A', '2014-12-17 05:18:32'),
(212, 11, 17, 6, 0, 'A', '2014-12-17 05:18:32'),
(213, 11, 17, 7, 7, 'A', '2014-12-17 05:18:32'),
(214, 11, 17, 9, 10, 'A', '2014-12-17 05:18:32'),
(215, 11, 17, 8, 10, 'A', '2014-12-17 05:18:32'),
(216, 11, 17, 8, 4, 'A', '2014-12-17 05:18:32'),
(217, 11, 17, 11, 0, 'A', '2014-12-17 05:18:32'),
(218, 11, 17, 13, 2, 'A', '2014-12-17 05:18:32'),
(219, 11, 17, 10, 0, 'A', '2014-12-17 05:18:32');

-- --------------------------------------------------------

--
-- Table structure for table `tb_timezones`
--

CREATE TABLE IF NOT EXISTS `tb_timezones` (
  `tz_id` int(12) NOT NULL AUTO_INCREMENT,
  `tz_name` varchar(44) DEFAULT NULL,
  `tz_timezone` varchar(30) DEFAULT NULL,
  `tz_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tz_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=141 ;

--
-- Dumping data for table `tb_timezones`
--

INSERT INTO `tb_timezones` (`tz_id`, `tz_name`, `tz_timezone`, `tz_default`) VALUES
(1, '(GMT-11:00) Midway Island ', 'Pacific/Midway', 0),
(2, '(GMT-11:00) Samoa ', 'Pacific/Samoa', 0),
(3, '(GMT-10:00) Hawaii ', 'Pacific/Honolulu', 0),
(4, '(GMT-09:00) Alaska ', 'America/Anchorage', 0),
(5, '(GMT-08:00) Pacific Time (US &amp; Canada) ', 'America/Los_Angeles', 0),
(6, '(GMT-08:00) Tijuana ', 'America/Tijuana', 0),
(7, '(GMT-07:00) Chihuahua ', 'America/Chihuahua', 0),
(8, '(GMT-07:00) La Paz ', 'America/Chihuahua', 0),
(9, '(GMT-07:00) Mazatlan ', 'America/Mazatlan', 0),
(10, '(GMT-07:00) Mountain Time (US &amp; Canada) ', 'America/Denver', 0),
(11, '(GMT-06:00) Central America ', 'America/Managua', 0),
(12, '(GMT-06:00) Central Time (US &amp; Canada) ', 'America/Chicago', 0),
(13, '(GMT-06:00) Guadalajara ', 'America/Mexico_City', 0),
(14, '(GMT-06:00) Mexico City ', 'America/Mexico_City', 0),
(15, '(GMT-06:00) Monterrey ', 'America/Monterrey', 0),
(16, '(GMT-05:00) Bogota ', 'America/Bogota', 0),
(17, '(GMT-05:00) Eastern Time (US &amp; Canada) ', 'America/New_York', 0),
(18, '(GMT-05:00) Lima ', 'America/Lima', 0),
(19, '(GMT-05:00) Quito ', 'America/Bogota', 0),
(20, '(GMT-04:00) Atlantic Time (Canada) ', 'Canada/Atlantic', 0),
(21, '(GMT-04:30) Caracas ', 'America/Caracas', 0),
(22, '(GMT-04:00) La Paz ', 'America/La_Paz', 0),
(23, '(GMT-04:00) Santiago ', 'America/Santiago', 0),
(24, '(GMT-03:30) Newfoundland ', 'America/St_Johns', 0),
(25, '(GMT-03:00) Brasilia ', 'America/Sao_Paulo', 0),
(26, '(GMT-03:00) Buenos Aires ', 'America/Argentina/Buenos_Aires', 0),
(27, '(GMT-03:00) Georgetown ', 'America/Argentina/Buenos_Aires', 0),
(28, '(GMT-03:00) Greenland ', 'America/Godthab', 0),
(29, '(GMT-02:00) Mid-Atlantic ', 'America/Noronha', 0),
(30, '(GMT-01:00) Azores ', 'Atlantic/Azores', 0),
(31, '(GMT-01:00) Cape Verde Is. ', 'Atlantic/Cape_Verde', 0),
(32, '(GMT+00:00) Casablanca ', 'Africa/Casablanca', 0),
(33, '(GMT+00:00) Edinburgh ', 'Europe/London', 0),
(34, '(GMT+00:00) Dublin', 'Europe/Dublin', 0),
(35, '(GMT+00:00) Lisbon ', 'Europe/Lisbon', 0),
(36, '(GMT+00:00) London ', 'Europe/London', 0),
(37, '(GMT+00:00) Monrovia ', 'Africa/Monrovia', 0),
(38, '(GMT+00:00) UTC ', 'UTC', 0),
(39, '(GMT+01:00) Amsterdam ', 'Europe/Amsterdam', 0),
(40, '(GMT+01:00) Belgrade ', 'Europe/Belgrade', 0),
(41, '(GMT+01:00) Berlin ', 'Europe/Berlin', 0),
(42, '(GMT+01:00) Bern ', 'Europe/Berlin', 0),
(43, '(GMT+01:00) Bratislava ', 'Europe/Bratislava', 0),
(44, '(GMT+01:00) Brussels ', 'Europe/Brussels', 0),
(45, '(GMT+01:00) Budapest ', 'Europe/Budapest', 0),
(46, '(GMT+01:00) Copenhagen ', 'Europe/Copenhagen', 0),
(47, '(GMT+01:00) Ljubljana ', 'Europe/Ljubljana', 0),
(48, '(GMT+01:00) Madrid ', 'Europe/Madrid', 0),
(49, '(GMT+01:00) Paris ', 'Europe/Paris', 0),
(50, '(GMT+01:00) Prague ', 'Europe/Prague', 0),
(51, '(GMT+01:00) Rome ', 'Europe/Rome', 0),
(52, '(GMT+01:00) Sarajevo ', 'Europe/Sarajevo', 0),
(53, '(GMT+01:00) Skopje ', 'Europe/Skopje', 0),
(54, '(GMT+01:00) Stockholm ', 'Europe/Stockholm', 0),
(55, '(GMT+01:00) Vienna ', 'Europe/Vienna', 0),
(56, '(GMT+01:00) Warsaw ', 'Europe/Warsaw', 0),
(57, '(GMT+01:00) West Central Africa ', 'Africa/Lagos', 0),
(58, '(GMT+01:00) Zagreb ', 'Europe/Zagreb', 0),
(59, '(GMT+02:00) Athens ', 'Europe/Athens', 0),
(60, '(GMT+02:00) Bucharest ', 'Europe/Bucharest', 0),
(61, '(GMT+02:00) Cairo ', 'Africa/Cairo', 0),
(62, '(GMT+02:00) Harare ', 'Africa/Harare', 0),
(63, '(GMT+02:00) Helsinki ', 'Europe/Helsinki', 0),
(64, '(GMT+02:00) Istanbul ', 'Europe/Istanbul', 0),
(65, '(GMT+02:00) Jerusalem ', 'Asia/Jerusalem', 0),
(66, '(GMT+02:00) Kyiv ', 'Europe/Helsinki', 0),
(67, '(GMT+02:00) Pretoria ', 'Africa/Johannesburg', 0),
(68, '(GMT+02:00) Riga ', 'Europe/Riga', 0),
(69, '(GMT+02:00) Sofia ', 'Europe/Sofia', 0),
(70, '(GMT+02:00) Tallinn ', 'Europe/Tallinn', 0),
(71, '(GMT+02:00) Vilnius ', 'Europe/Vilnius', 0),
(72, '(GMT+03:00) Baghdad ', 'Asia/Baghdad', 0),
(73, '(GMT+03:00) Kuwait ', 'Asia/Kuwait', 0),
(74, '(GMT+03:00) Minsk ', 'Europe/Minsk', 0),
(75, '(GMT+03:00) Nairobi ', 'Africa/Nairobi', 0),
(76, '(GMT+03:00) Riyadh ', 'Asia/Riyadh', 0),
(77, '(GMT+03:00) Volgograd ', 'Europe/Volgograd', 0),
(78, '(GMT+03:30) Tehran ', 'Asia/Tehran', 0),
(79, '(GMT+04:00) Abu Dhabi ', 'Asia/Muscat', 0),
(80, '(GMT+04:00) Baku ', 'Asia/Baku', 0),
(81, '(GMT+04:00) Moscow ', 'Europe/Moscow', 0),
(82, '(GMT+04:00) Muscat ', 'Asia/Muscat', 0),
(83, '(GMT+04:00) St. Petersburg ', 'Europe/Moscow', 0),
(84, '(GMT+04:00) Tbilisi ', 'Asia/Tbilisi', 0),
(85, '(GMT+04:00) Yerevan ', 'Asia/Yerevan', 0),
(86, '(GMT+04:30) Kabul ', 'Asia/Kabul', 0),
(87, '(GMT+05:00) Islamabad ', 'Asia/Karachi', 0),
(88, '(GMT+05:00) Karachi ', 'Asia/Karachi', 0),
(89, '(GMT+05:00) Tashkent ', 'Asia/Tashkent', 0),
(90, '(GMT+05:30) Chennai ', 'Asia/Calcutta', 0),
(91, '(GMT+05:30) Kolkata ', 'Asia/Kolkata', 0),
(92, '(GMT+05:30) Mumbai ', 'Asia/Calcutta', 0),
(93, '(GMT+05:30) New Delhi', 'Asia/Calcutta', 1),
(94, '(GMT+05:30) Sri Jayawardenepura ', 'Asia/Calcutta', 0),
(95, '(GMT+05:45) Kathmandu ', 'Asia/Katmandu', 0),
(96, '(GMT+06:00) Almaty ', 'Asia/Almaty', 0),
(97, '(GMT+06:00) Astana ', 'Asia/Dhaka', 0),
(98, '(GMT+06:00) Dhaka ', 'Asia/Dhaka', 0),
(99, '(GMT+06:00) Ekaterinburg ', 'Asia/Yekaterinburg', 0),
(100, '(GMT+06:30) Rangoon ', 'Asia/Rangoon', 0),
(101, '(GMT+07:00) Bangkok ', 'Asia/Bangkok', 0),
(102, '(GMT+07:00) Hanoi ', 'Asia/Bangkok', 0),
(103, '(GMT+07:00) Jakarta ', 'Asia/Jakarta', 0),
(104, '(GMT+07:00) Novosibirsk ', 'Asia/Novosibirsk', 0),
(105, '(GMT+08:00) Beijing ', 'Asia/Hong_Kong', 0),
(106, '(GMT+08:00) Chongqing ', 'Asia/Chongqing', 0),
(107, '(GMT+08:00) Hong Kong ', 'Asia/Hong_Kong', 0),
(108, '(GMT+08:00) Krasnoyarsk ', 'Asia/Krasnoyarsk', 0),
(109, '(GMT+08:00) Kuala Lumpur ', 'Asia/Kuala_Lumpur', 0),
(110, '(GMT+08:00) Perth ', 'Australia/Perth', 0),
(111, '(GMT+08:00) Singapore ', 'Asia/Singapore', 0),
(112, '(GMT+08:00) Taipei ', 'Asia/Taipei', 0),
(113, '(GMT+08:00) Ulaan Bataar ', 'Asia/Ulan_Bator', 0),
(114, '(GMT+08:00) Urumqi ', 'Asia/Urumqi', 0),
(115, '(GMT+09:00) Irkutsk ', 'Asia/Irkutsk', 0),
(116, '(GMT+09:00) Osaka ', 'Asia/Tokyo', 0),
(117, '(GMT+09:00) Sapporo ', 'Asia/Tokyo', 0),
(118, '(GMT+09:00) Seoul ', 'Asia/Seoul', 0),
(119, '(GMT+09:00) Tokyo ', 'Asia/Tokyo', 0),
(120, '(GMT+09:30) Adelaide ', 'Australia/Adelaide', 0),
(121, '(GMT+09:30) Darwin ', 'Australia/Darwin', 0),
(122, '(GMT+10:00) Brisbane ', 'Australia/Brisbane', 0),
(123, '(GMT+10:00) Canberra ', 'Australia/Canberra', 0),
(124, '(GMT+10:00) Guam ', 'Pacific/Guam', 0),
(125, '(GMT+10:00) Hobart ', 'Australia/Hobart', 0),
(126, '(GMT+10:00) Melbourne ', 'Australia/Melbourne', 0),
(127, '(GMT+10:00) Port Moresby ', 'Pacific/Port_Moresby', 0),
(128, '(GMT+10:00) Sydney ', 'Australia/Sydney', 0),
(129, '(GMT+10:00) Yakutsk ', 'Asia/Yakutsk', 0),
(130, '(GMT+11:00) Vladivostok ', 'Asia/Vladivostok', 0),
(131, '(GMT+12:00) Auckland ', 'Pacific/Auckland', 0),
(132, '(GMT+12:00) Fiji ', 'Pacific/Fiji', 0),
(133, '(GMT+12:00) International Date Line West ', 'Pacific/Kwajalein', 0),
(134, '(GMT+12:00) Kamchatka ', 'Asia/Kamchatka', 0),
(135, '(GMT+12:00) Magadan ', 'Asia/Magadan', 0),
(136, '(GMT+12:00) Marshall Is. ', 'Pacific/Fiji', 0),
(137, '(GMT+12:00) New Caledonia ', 'Asia/Magadan', 0),
(138, '(GMT+12:00) Solomon Is. ', 'Asia/Magadan', 0),
(139, '(GMT+12:00) Wellington ', 'Pacific/Auckland', 0),
(140, '(GMT+13:00) Nuku\\alofa ', 'Pacific/Tongatapu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE IF NOT EXISTS `tb_users` (
  `user_id` int(255) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_password` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_fullname` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_type` enum('SA','SD','SF','AD') COLLATE utf8_bin NOT NULL DEFAULT 'SD',
  `user_email` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_status` enum('A','D') COLLATE utf8_bin NOT NULL DEFAULT 'D',
  `user_sess` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_login` datetime NOT NULL,
  `user_doc` datetime NOT NULL,
  `user_dom` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User Types' AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`user_id`, `user_name`, `user_password`, `user_fullname`, `user_type`, `user_email`, `user_status`, `user_sess`, `user_login`, `user_doc`, `user_dom`) VALUES
(1, 'superadmin', '17c4520f6cfd1ab53d8745e84681eb49', 'Sri Kadari', 'SA', 'distracker@distracker.com', 'A', '0', '2016-06-03 19:22:33', '2013-09-04 00:00:00', '2015-03-12 00:07:11'),
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'John Abraham', 'AD', 'admin@distracker.com', 'A', '8a27db16fd3c9194d5993d6e29561bd2', '2016-06-03 19:19:57', '2013-09-04 00:00:00', '2014-12-11 03:57:14'),
(3, 'student1', '5e5545d38a68148a2d5bd5ec9a89e327', 'student1 student1', 'SD', 'student1@student1.com', 'A', '0b5746aaedf6ea3b776153fa9745dd23', '0000-00-00 00:00:00', '2013-12-12 16:48:10', '2013-12-12 16:50:01'),
(4, 'blord01', 'cf156305afe3106dc49f4e0495c8e957', 'Beth Lord', 'SF', 'mrajkumar83@gmail.com', 'A', '', '0000-00-00 00:00:00', '2013-12-12 16:48:59', '2013-12-12 16:50:18'),
(5, 'rajesh', 'e360bc13bcba071f4746adbb334cd78e', 'Rajesh Reddy', 'SD', 'rajesh99hosters@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-18 05:24:40', '2013-12-18 11:10:12'),
(6, 'staff31', '9931ef8765abfb1dce13b9c7016c2c4e', 'Staff3 Staff3', '', 'staff31@staff31.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-18 05:42:32', '2013-12-18 12:55:07'),
(10, 'bkirsch', 'def1b5b5b579ac3ce8162fab959a7c88', 'Bill Kirsch', 'SF', 'bkirsch@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2014-03-11 19:55:42', '2014-12-14 18:19:51'),
(7, 'cwilson', '3b6e32729cf785133e5a63d92039597c', 'Chuck Wilson', 'AD', 'cwilson@sagu.edu', 'A', 'a0a3a3c7fdecae9916f50a8aedf58690', '0000-00-00 00:00:00', '2014-01-01 02:13:11', '2014-04-11 21:34:00'),
(8, 'skadari', '52a399b218b9208cade790a26255db6b', 'Sri Kadari', 'SD', 'srikanth.kadari@berachahtechnologies.com', 'A', '0', '2016-06-03 19:21:19', '2014-01-01 02:17:08', '2014-11-01 01:33:23'),
(9, 'mgilbert', '02e98800f21e0d79b83c2f481614bc96', 'Marvin Gilbert', 'AD', 'testing@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2014-01-28 11:30:22', '2014-12-15 00:25:47'),
(11, 'jkuoh01', '02e98800f21e0d79b83c2f481614bc96', 'Jimmy Kuoh', 'SD', 'jimmy@testing.com', 'A', 'c1d9d5c643d591149d944c985a09de46', '0000-00-00 00:00:00', '2014-04-11 21:22:52', '2014-04-11 21:23:56'),
(12, 'rajkumar23', 'dbf1cb75000583f6f31a2bcb6babe7f2', 'Raj Kumar', 'SD', 'rajkumar23@rajkumar23.com', 'D', '0', '0000-00-00 00:00:00', '2014-07-31 07:23:49', '2014-08-21 08:57:38'),
(14, 'google', 'c822c1b63853ed273b89687ac505f9fa', 'Testing from google Kadari', 'SD', 'sarahkadari@gmail.com', 'D', '0', '0000-00-00 00:00:00', '2014-10-23 17:42:02', '0000-00-00 00:00:00'),
(20, 'something', '437b930db84b8079c2dd804a71936b5f', 'something something', 'SD', 'something@something.com', 'A', '0', '0000-00-00 00:00:00', '2014-12-15 15:11:18', '2014-12-15 15:15:50'),
(15, 'testingactive', '02e98800f21e0d79b83c2f481614bc96', 'testing active', 'SD', 'testingactive@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2014-11-03 05:36:30', '2014-11-03 05:39:31'),
(17, 'rajmadi', 'c2e3b59f16703549efa15e6daec8de18', 'raj Madishetti', '', 'raj@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2014-12-13 23:42:56', '2014-12-13 23:45:38'),
(18, 'jbond01', 'c2e3b59f16703549efa15e6daec8de18', 'James Bond', 'SD', 'jbond@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2014-12-13 23:58:30', '2014-12-13 23:58:50'),
(24, 'tuandier33@gmail.com', 'e06781af360a3fa851daedaa6c940703', 'citsnvkao citsnvkao', 'SD', 'tuandier33@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2015-04-05 20:28:38', '0000-00-00 00:00:00'),
(21, 'user_status', '79a4868ad56a5cbb961ea21c62290e74', 'user_status user_status', 'SD', 'user_status@user_status.com', 'D', '0', '0000-00-00 00:00:00', '2014-12-15 15:18:59', '0000-00-00 00:00:00'),
(22, 'something1', '09891eb590524e35fc73372cddc5d596', 'something1 something1', 'SD', 'something1@something1.com', 'A', '0', '0000-00-00 00:00:00', '2014-12-15 15:24:50', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user_info`
--

CREATE TABLE IF NOT EXISTS `tb_user_info` (
  `user_id` int(255) NOT NULL,
  `user_fname` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_lname` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_prefix` enum('Mr','Mrs','Miss','Dr','Rev') COLLATE utf8_bin NOT NULL,
  `user_desc` text COLLATE utf8_bin NOT NULL,
  `user_registration` varchar(20) COLLATE utf8_bin NOT NULL,
  `user_lang` varchar(256) COLLATE utf8_bin NOT NULL,
  `user_doe` date NOT NULL,
  `user_mobile` int(16) NOT NULL,
  `user_address` text COLLATE utf8_bin NOT NULL,
  `user_suite` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_city` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_state` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_country` int(3) NOT NULL,
  `user_zip` varchar(12) COLLATE utf8_bin NOT NULL,
  `user_dob` date NOT NULL,
  `user_skype` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_photo` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_doc` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users Information';

--
-- Dumping data for table `tb_user_info`
--

INSERT INTO `tb_user_info` (`user_id`, `user_fname`, `user_lname`, `user_prefix`, `user_desc`, `user_registration`, `user_lang`, `user_doe`, `user_mobile`, `user_address`, `user_suite`, `user_city`, `user_state`, `user_country`, `user_zip`, `user_dob`, `user_skype`, `user_photo`, `user_doc`) VALUES
(1, 'Sri', 'Kadari', 'Mr', '', '0789809', '', '0000-00-00', 8789791, 'something is better than nothing', '', '', '', 0, '', '0000-00-00', 'jhjkhk@something.com', '1_Chrysanthemum.jpg', '2015-03-12 00:07:11'),
(2, 'John', 'Abraham', 'Mr', '', '', '', '0000-00-00', 123, '', '', '', '', 223, '', '0000-00-00', 'madishetti', '', '2014-12-11 03:57:14'),
(3, 'student1', 'student1', 'Mr', '', '978098', '', '2013-12-12', 0, '', '', 'student1', '', 0, '', '0000-00-00', '', '', '2013-12-12 16:50:01'),
(4, 'staff1', 'staff1', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-12 16:50:18'),
(5, 'Rajesh', 'Reddy', 'Mr', '', '31', '', '2013-12-18', 0, '', '', '', '', 0, '', '0000-00-00', '', '5_2-cyber-ice-stage-design.jpg', '2013-12-18 11:10:12'),
(6, 'Staff3', 'Staff3', 'Mr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-18 05:42:47'),
(7, 'Chuck', 'Wilson', 'Dr', '', '', '', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-04-11 21:34:00'),
(8, 'Sri', 'Kadari', 'Mr', '', '1001', '', '2013-12-31', 0, '1111 Apple Tree Rd', 'Apt 120', 'Hurst', 'TX', 223, '76078', '0000-00-00', '', '8_Srikanth.jpg', '2014-11-01 01:33:23'),
(9, 'Marvin', 'Gilbert', 'Dr', '', '', '', '0000-00-00', 0, '', '', '', '', 219, '', '0000-00-00', '', '9_74.jpg', '2014-10-31 05:27:49'),
(10, 'Bill', 'Kirsch', 'Mr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-12-13 03:23:12'),
(11, 'Jimmy', 'Kuoh', 'Mr', '', '2011001', '', '2014-04-23', 0, '', '', '', '', 120, '', '0000-00-00', '', '', '2014-04-11 21:23:56'),
(12, 'Raj', 'Kumar', 'Rev', '', '1234', '', '2014-07-15', 0, 'jkj', '', '', '', 0, '', '0000-00-00', '', '', '2014-08-21 08:57:38'),
(14, 'Testing from google', 'Kadari', 'Mrs', '', '12345', '', '2014-10-23', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-10-23 17:42:02'),
(15, 'testing', 'active', 'Mr', '', '101010', '', '2014-11-02', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-11-03 05:39:31'),
(17, 'raj', 'Madishetti', 'Mr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-12-13 23:43:47'),
(18, 'James', 'Bond', 'Mr', '', '101011', '', '2014-12-17', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-12-13 23:58:50'),
(24, 'citsnvkao', 'citsnvkao', 'Miss', '', '', '', '0000-00-00', 123456, 'Indianapolis', '', 'Cincinnati', 'CA', 131, '123456', '0000-00-00', 'emsnszluhQT', '', '2015-04-05 20:28:38'),
(20, 'something', 'something', 'Mr', '', '78789798', '', '2014-12-15', 0, 'something', '', '', '', 99, '', '0000-00-00', '', '', '2014-12-15 15:15:50'),
(21, 'user_status', 'user_status', 'Mr', '', '878796', '', '2014-12-15', 0, '', '', '', 'A', 0, '', '0000-00-00', '', '', '2014-12-15 15:18:59'),
(22, 'something1', 'something1', 'Mrs', '', '6786786', '', '2014-12-15', 0, '', '', '', '', 99, '', '0000-00-00', '', '', '2014-12-15 15:24:50');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_dissertation_details`
--
CREATE TABLE IF NOT EXISTS `vw_dissertation_details` (
`std_id` int(255)
,`std_name` varchar(255)
,`email` varchar(255)
,`login_time` datetime
,`std_photo` varchar(255)
,`con_id` int(255)
,`con_name` varchar(255)
,`chrt_id` int(255)
,`chrt_name` varchar(255)
,`program_id` int(11)
,`program_name` varchar(255)
,`dist_id` int(255)
,`dist_name` varchar(255)
,`dist_desc` text
,`dist_doc` datetime
,`lang_id` tinyint(2)
,`lang_name` varchar(255)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_stage_role_rel`
--
CREATE TABLE IF NOT EXISTS `vw_stage_role_rel` (
`stg_id` int(255)
,`stg_title` varchar(255)
,`role_id` smallint(3)
,`role_title` varchar(255)
);
-- --------------------------------------------------------

--
-- Structure for view `vw_dissertation_details`
--
DROP TABLE IF EXISTS `vw_dissertation_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`distrack`@`localhost` SQL SECURITY DEFINER VIEW `vw_dissertation_details` AS select `u`.`user_id` AS `std_id`,`u`.`user_fullname` AS `std_name`,`u`.`user_email` AS `email`,`u`.`user_login` AS `login_time`,`ui`.`user_photo` AS `std_photo`,`con`.`concentration_id` AS `con_id`,`con`.`concentration_name` AS `con_name`,`cht`.`cohort_id` AS `chrt_id`,`cht`.`cohort_name` AS `chrt_name`,`d`.`disseration_program` AS `program_id`,`p`.`program_name` AS `program_name`,`d`.`dissertation_id` AS `dist_id`,`d`.`disseration_name` AS `dist_name`,`d`.`disseration_desc` AS `dist_desc`,`d`.`disseration_doc` AS `dist_doc`,`l`.`lang_id` AS `lang_id`,`l`.`lang_name` AS `lang_name` from ((((((`tb_users` `u` join `tb_user_info` `ui`) join `tb_cohort` `cht`) join `tb_dissertation` `d`) join `tb_languages` `l`) left join `tb_programs` `p` on((`p`.`program_id` = `d`.`disseration_program`))) left join `tb_concentration` `con` on((`d`.`disseration_concentration` = `con`.`concentration_id`))) where ((`u`.`user_id` = `ui`.`user_id`) and (`u`.`user_type` = 'SD') and (`u`.`user_status` = 'A') and (`d`.`disseration_cohort` = `cht`.`cohort_id`) and (`d`.`std_id` = `u`.`user_id`) and (`l`.`lang_id` = `d`.`disseration_language`));

-- --------------------------------------------------------

--
-- Structure for view `vw_stage_role_rel`
--
DROP TABLE IF EXISTS `vw_stage_role_rel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`distrack`@`localhost` SQL SECURITY DEFINER VIEW `vw_stage_role_rel` AS select `s`.`stg_id` AS `stg_id`,`s`.`stg_title` AS `stg_title`,`r`.`role_id` AS `role_id`,`r`.`role_title` AS `role_title` from ((`tb_role_stage_rel` `rel` join `tb_stages` `s`) join `tb_roles` `r`) where ((`rel`.`stg_id` = `s`.`stg_id`) and (`rel`.`role_id` = `r`.`role_id`)) order by `rel`.`rel_ord`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
