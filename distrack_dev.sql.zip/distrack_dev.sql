-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 05, 2016 at 01:01 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `distrack_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_cohort`
--

CREATE TABLE IF NOT EXISTS `tb_cohort` (
  `cohort_id` int(255) NOT NULL AUTO_INCREMENT,
  `cohort_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `cohort_ref` varchar(255) CHARACTER SET latin1 NOT NULL,
  `cohort_edate` date NOT NULL,
  `cohort_languages` varchar(20) CHARACTER SET latin1 NOT NULL,
  `cohort_description` text CHARACTER SET latin1 NOT NULL,
  `cohort_status` enum('A','D') CHARACTER SET latin1 NOT NULL DEFAULT 'A',
  `cohort_created` int(255) NOT NULL,
  `cohort_modified` int(255) NOT NULL DEFAULT '0',
  `cohort_doc` datetime NOT NULL,
  `cohort_dom` datetime NOT NULL,
  PRIMARY KEY (`cohort_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tb_cohort`
--

INSERT INTO `tb_cohort` (`cohort_id`, `cohort_name`, `cohort_ref`, `cohort_edate`, `cohort_languages`, `cohort_description`, `cohort_status`, `cohort_created`, `cohort_modified`, `cohort_doc`, `cohort_dom`) VALUES
(3, '2003', '', '2013-09-16', '5', 'Cohort Description', 'A', 27, 2, '2013-10-03 17:41:19', '2015-10-04 20:29:34'),
(4, '2004', '12345', '2013-10-02', '4,5,6', 'Cohort Description', 'A', 27, 0, '2013-10-03 17:42:00', '0000-00-00 00:00:00'),
(5, '2005', '123458', '2013-10-01', '', 'Cohort Description', 'A', 27, 2, '2013-10-03 17:42:42', '2013-12-18 05:52:48'),
(6, '2011 WA', '2011 WA', '2014-04-15', '', '', 'A', 7, 0, '2014-04-11 21:25:05', '0000-00-00 00:00:00'),
(8, '2015 WA', '7', '2015-03-18', '1,2', '2015 cohort in West Africa', 'D', 7, 2, '2014-12-12 10:27:30', '2015-09-09 11:22:17');

-- --------------------------------------------------------

--
-- Table structure for table `tb_concentration`
--

CREATE TABLE IF NOT EXISTS `tb_concentration` (
  `concentration_id` int(255) NOT NULL AUTO_INCREMENT,
  `concentration_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `concentration_ref` varchar(255) CHARACTER SET latin1 NOT NULL,
  `concentration_edate` date NOT NULL,
  `concentration_languages` varchar(20) CHARACTER SET latin1 NOT NULL,
  `concentration_description` text CHARACTER SET latin1 NOT NULL,
  `concentration_status` enum('A','D') CHARACTER SET latin1 NOT NULL DEFAULT 'A',
  `concentration_created` int(11) NOT NULL,
  `concentration_modified` int(11) NOT NULL,
  `concentration_doc` datetime NOT NULL,
  `concentration_dom` datetime NOT NULL,
  PRIMARY KEY (`concentration_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tb_concentration`
--

INSERT INTO `tb_concentration` (`concentration_id`, `concentration_name`, `concentration_ref`, `concentration_edate`, `concentration_languages`, `concentration_description`, `concentration_status`, `concentration_created`, `concentration_modified`, `concentration_doc`, `concentration_dom`) VALUES
(1, 'Biblical Theology', '1234', '2013-10-01', '4,5,6', 'Concentration Description', 'A', 27, 0, '2013-10-03 17:43:46', '0000-00-00 00:00:00'),
(2, 'Technology', '12345', '2013-10-01', '', 'Technology in churches', 'D', 27, 7, '2013-10-03 17:44:33', '2014-12-12 10:49:29'),
(3, 'Mission', '123456', '2013-10-01', '5', 'Concentration Description', 'A', 27, 1, '2013-10-03 17:45:16', '2014-12-17 12:22:23'),
(4, 'Education Test', '1234567', '2013-10-01', '1,2', 'Concentration Description', 'A', 27, 7, '2013-10-03 17:45:52', '2014-12-12 12:02:24'),
(5, 'Leadership', '12345678', '2013-12-18', '', 'Concentration Description', 'A', 2, 7, '2013-12-18 05:55:49', '2014-12-12 10:48:47'),
(7, 'Multimedia', '9', '2016-07-12', '', 'Using multimedia in churches', 'A', 2, 0, '2015-09-09 11:34:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_country`
--

CREATE TABLE IF NOT EXISTS `tb_country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `iso_code_2` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '',
  `iso_code_3` varchar(3) COLLATE utf8_bin NOT NULL DEFAULT '',
  `address_format` text COLLATE utf8_bin NOT NULL,
  `country_disp_ord` smallint(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=240 ;

--
-- Dumping data for table `tb_country`
--

INSERT INTO `tb_country` (`country_id`, `country_name`, `iso_code_2`, `iso_code_3`, `address_format`, `country_disp_ord`, `status`) VALUES
(1, 'Afghanistan', 'AF', 'AFG', '', 1, 1),
(2, 'Albania', 'AL', 'ALB', '', 3, 1),
(3, 'Algeria', 'DZ', 'DZA', '', 4, 1),
(4, 'American Samoa', 'AS', 'ASM', '', 5, 1),
(5, 'Andorra', 'AD', 'AND', '', 6, 1),
(6, 'Angola', 'AO', 'AGO', '', 7, 1),
(7, 'Anguilla', 'AI', 'AIA', '', 8, 1),
(8, 'Antarctica', 'AQ', 'ATA', '', 9, 1),
(9, 'Antigua and Barbuda', 'AG', 'ATG', '', 10, 1),
(10, 'Argentina', 'AR', 'ARG', '', 11, 1),
(11, 'Armenia', 'AM', 'ARM', '', 12, 1),
(12, 'Aruba', 'AW', 'ABW', '', 13, 1),
(13, 'Australia', 'AU', 'AUS', '', 14, 1),
(14, 'Austria', 'AT', 'AUT', '', 15, 1),
(15, 'Azerbaijan', 'AZ', 'AZE', '', 16, 1),
(16, 'Bahamas', 'BS', 'BHS', '', 17, 1),
(17, 'Bahrain', 'BH', 'BHR', '', 18, 1),
(18, 'Bangladesh', 'BD', 'BGD', '', 19, 1),
(19, 'Barbados', 'BB', 'BRB', '', 20, 1),
(20, 'Belarus', 'BY', 'BLR', '', 21, 1),
(21, 'Belgium', 'BE', 'BEL', '', 22, 1),
(22, 'Belize', 'BZ', 'BLZ', '', 23, 1),
(23, 'Benin', 'BJ', 'BEN', '', 24, 1),
(24, 'Bermuda', 'BM', 'BMU', '', 25, 1),
(25, 'Bhutan', 'BT', 'BTN', '', 26, 1),
(26, 'Bolivia', 'BO', 'BOL', '', 27, 1),
(27, 'Bosnia and Herzegowina', 'BA', 'BIH', '', 28, 1),
(28, 'Botswana', 'BW', 'BWA', '', 29, 1),
(29, 'Bouvet Island', 'BV', 'BVT', '', 30, 1),
(30, 'Brazil', 'BR', 'BRA', '', 31, 1),
(31, 'British Indian Ocean Territory', 'IO', 'IOT', '', 32, 1),
(32, 'Brunei Darussalam', 'BN', 'BRN', '', 33, 1),
(33, 'Bulgaria', 'BG', 'BGR', '', 34, 33),
(34, 'Burkina Faso', 'BF', 'BFA', '', 35, 1),
(35, 'Burundi', 'BI', 'BDI', '', 36, 1),
(36, 'Cambodia', 'KH', 'KHM', '', 37, 1),
(37, 'Cameroon', 'CM', 'CMR', '', 38, 1),
(38, 'Canada', 'CA', 'CAN', '', 39, 1),
(39, 'Cape Verde', 'CV', 'CPV', '', 40, 1),
(40, 'Cayman Islands', 'KY', 'CYM', '', 41, 1),
(41, 'Central African Republic', 'CF', 'CAF', '', 42, 1),
(42, 'Chad', 'TD', 'TCD', '', 43, 1),
(43, 'Chile', 'CL', 'CHL', '', 44, 1),
(44, 'China', 'CN', 'CHN', '', 45, 1),
(45, 'Christmas Island', 'CX', 'CXR', '', 46, 1),
(46, 'Cocos (Keeling) Islands', 'CC', 'CCK', '', 47, 1),
(47, 'Colombia', 'CO', 'COL', '', 48, 1),
(48, 'Comoros', 'KM', 'COM', '', 49, 1),
(49, 'Congo', 'CG', 'COG', '', 50, 1),
(50, 'Cook Islands', 'CK', 'COK', '', 51, 1),
(51, 'Costa Rica', 'CR', 'CRI', '', 52, 1),
(52, 'Cote D''Ivoire', 'CI', 'CIV', '', 53, 1),
(53, 'Croatia', 'HR', 'HRV', '', 54, 1),
(54, 'Cuba', 'CU', 'CUB', '', 55, 1),
(55, 'Cyprus', 'CY', 'CYP', '', 56, 1),
(56, 'Czech Republic', 'CZ', 'CZE', '', 57, 1),
(57, 'Denmark', 'DK', 'DNK', '', 58, 1),
(58, 'Djibouti', 'DJ', 'DJI', '', 59, 1),
(59, 'Dominica', 'DM', 'DMA', '', 60, 1),
(60, 'Dominican Republic', 'DO', 'DOM', '', 61, 1),
(61, 'East Timor', 'TP', 'TMP', '', 62, 1),
(62, 'Ecuador', 'EC', 'ECU', '', 63, 1),
(63, 'Egypt', 'EG', 'EGY', '', 64, 1),
(64, 'El Salvador', 'SV', 'SLV', '', 65, 1),
(65, 'Equatorial Guinea', 'GQ', 'GNQ', '', 66, 1),
(66, 'Eritrea', 'ER', 'ERI', '', 67, 1),
(67, 'Estonia', 'EE', 'EST', '', 68, 1),
(68, 'Ethiopia', 'ET', 'ETH', '', 69, 1),
(69, 'Falkland Islands (Malvinas)', 'FK', 'FLK', '', 70, 1),
(70, 'Faroe Islands', 'FO', 'FRO', '', 71, 1),
(71, 'Fiji', 'FJ', 'FJI', '', 72, 1),
(72, 'Finland', 'FI', 'FIN', '', 73, 1),
(73, 'France', 'FR', 'FRA', '', 74, 1),
(74, 'France, Metropolitan', 'FX', 'FXX', '', 75, 1),
(75, 'French Guiana', 'GF', 'GUF', '', 76, 1),
(76, 'French Polynesia', 'PF', 'PYF', '', 77, 1),
(77, 'French Southern Territories', 'TF', 'ATF', '', 78, 1),
(78, 'Gabon', 'GA', 'GAB', '', 79, 1),
(79, 'Gambia', 'GM', 'GMB', '', 80, 1),
(80, 'Georgia', 'GE', 'GEO', '', 81, 1),
(81, 'Germany', 'DE', 'DEU', '{company}\r\n{firstname} {lastname}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}', 82, 1),
(82, 'Ghana', 'GH', 'GHA', '', 83, 1),
(83, 'Gibraltar', 'GI', 'GIB', '', 84, 1),
(84, 'Greece', 'GR', 'GRC', '', 85, 1),
(85, 'Greenland', 'GL', 'GRL', '', 86, 1),
(86, 'Grenada', 'GD', 'GRD', '', 87, 1),
(87, 'Guadeloupe', 'GP', 'GLP', '', 88, 1),
(88, 'Guam', 'GU', 'GUM', '', 89, 1),
(89, 'Guatemala', 'GT', 'GTM', '', 90, 1),
(90, 'Guinea', 'GN', 'GIN', '', 91, 1),
(91, 'Guinea-bissau', 'GW', 'GNB', '', 92, 1),
(92, 'Guyana', 'GY', 'GUY', '', 93, 1),
(93, 'Haiti', 'HT', 'HTI', '', 94, 1),
(94, 'Heard and Mc Donald Islands', 'HM', 'HMD', '', 95, 1),
(95, 'Honduras', 'HN', 'HND', '', 96, 1),
(96, 'Hong Kong', 'HK', 'HKG', '', 97, 1),
(97, 'Hungary', 'HU', 'HUN', '', 98, 1),
(98, 'Iceland', 'IS', 'ISL', '', 99, 1),
(99, 'India', 'IN', 'IND', '', 100, 1),
(100, 'Indonesia', 'ID', 'IDN', '', 101, 1),
(101, 'Iran (Islamic Republic of)', 'IR', 'IRN', '', 102, 1),
(102, 'Iraq', 'IQ', 'IRQ', '', 103, 1),
(103, 'Ireland', 'IE', 'IRL', '', 104, 1),
(104, 'Israel', 'IL', 'ISR', '', 105, 1),
(105, 'Italy', 'IT', 'ITA', '', 106, 1),
(106, 'Jamaica', 'JM', 'JAM', '', 107, 1),
(107, 'Japan', 'JP', 'JPN', '', 108, 1),
(108, 'Jordan', 'JO', 'JOR', '', 109, 1),
(109, 'Kazakhstan', 'KZ', 'KAZ', '', 110, 1),
(110, 'Kenya', 'KE', 'KEN', '', 2, 1),
(111, 'Kiribati', 'KI', 'KIR', '', 111, 1),
(112, 'North Korea', 'KP', 'PRK', '', 112, 1),
(113, 'Korea, Republic of', 'KR', 'KOR', '', 113, 1),
(114, 'Kuwait', 'KW', 'KWT', '', 114, 1),
(115, 'Kyrgyzstan', 'KG', 'KGZ', '', 115, 1),
(116, 'Lao People''s Democratic Republic', 'LA', 'LAO', '', 116, 1),
(117, 'Latvia', 'LV', 'LVA', '', 117, 1),
(118, 'Lebanon', 'LB', 'LBN', '', 118, 1),
(119, 'Lesotho', 'LS', 'LSO', '', 119, 1),
(120, 'Liberia', 'LR', 'LBR', '', 120, 1),
(121, 'Libyan Arab Jamahiriya', 'LY', 'LBY', '', 121, 1),
(122, 'Liechtenstein', 'LI', 'LIE', '', 122, 1),
(123, 'Lithuania', 'LT', 'LTU', '', 123, 1),
(124, 'Luxembourg', 'LU', 'LUX', '', 124, 1),
(125, 'Macau', 'MO', 'MAC', '', 125, 1),
(126, 'Macedonia', 'MK', 'MKD', '', 126, 1),
(127, 'Madagascar', 'MG', 'MDG', '', 127, 1),
(128, 'Malawi', 'MW', 'MWI', '', 128, 1),
(129, 'Malaysia', 'MY', 'MYS', '', 129, 1),
(130, 'Maldives', 'MV', 'MDV', '', 130, 1),
(131, 'Mali', 'ML', 'MLI', '', 131, 1),
(132, 'Malta', 'MT', 'MLT', '', 132, 1),
(133, 'Marshall Islands', 'MH', 'MHL', '', 133, 1),
(134, 'Martinique', 'MQ', 'MTQ', '', 134, 1),
(135, 'Mauritania', 'MR', 'MRT', '', 135, 1),
(136, 'Mauritius', 'MU', 'MUS', '', 136, 1),
(137, 'Mayotte', 'YT', 'MYT', '', 137, 1),
(138, 'Mexico', 'MX', 'MEX', '', 138, 1),
(139, 'Micronesia, Federated States of', 'FM', 'FSM', '', 139, 1),
(140, 'Moldova, Republic of', 'MD', 'MDA', '', 140, 1),
(141, 'Monaco', 'MC', 'MCO', '', 141, 1),
(142, 'Mongolia', 'MN', 'MNG', '', 142, 1),
(143, 'Montserrat', 'MS', 'MSR', '', 143, 1),
(144, 'Morocco', 'MA', 'MAR', '', 144, 1),
(145, 'Mozambique', 'MZ', 'MOZ', '', 145, 1),
(146, 'Myanmar', 'MM', 'MMR', '', 146, 1),
(147, 'Namibia', 'NA', 'NAM', '', 147, 1),
(148, 'Nauru', 'NR', 'NRU', '', 148, 1),
(149, 'Nepal', 'NP', 'NPL', '', 149, 1),
(150, 'Netherlands', 'NL', 'NLD', '', 150, 1),
(151, 'Netherlands Antilles', 'AN', 'ANT', '', 151, 1),
(152, 'New Caledonia', 'NC', 'NCL', '', 152, 1),
(153, 'New Zealand', 'NZ', 'NZL', '', 153, 1),
(154, 'Nicaragua', 'NI', 'NIC', '', 154, 1),
(155, 'Niger', 'NE', 'NER', '', 155, 1),
(156, 'Nigeria', 'NG', 'NGA', '', 156, 1),
(157, 'Niue', 'NU', 'NIU', '', 157, 1),
(158, 'Norfolk Island', 'NF', 'NFK', '', 158, 1),
(159, 'Northern Mariana Islands', 'MP', 'MNP', '', 159, 1),
(160, 'Norway', 'NO', 'NOR', '', 160, 1),
(161, 'Oman', 'OM', 'OMN', '', 161, 1),
(162, 'Pakistan', 'PK', 'PAK', '', 162, 1),
(163, 'Palau', 'PW', 'PLW', '', 163, 1),
(164, 'Panama', 'PA', 'PAN', '', 164, 1),
(165, 'Papua New Guinea', 'PG', 'PNG', '', 165, 1),
(166, 'Paraguay', 'PY', 'PRY', '', 166, 1),
(167, 'Peru', 'PE', 'PER', '', 167, 1),
(168, 'Philippines', 'PH', 'PHL', '', 168, 1),
(169, 'Pitcairn', 'PN', 'PCN', '', 169, 1),
(170, 'Poland', 'PL', 'POL', '', 170, 1),
(171, 'Portugal', 'PT', 'PRT', '', 171, 1),
(172, 'Puerto Rico', 'PR', 'PRI', '', 172, 1),
(173, 'Qatar', 'QA', 'QAT', '', 173, 1),
(174, 'Reunion', 'RE', 'REU', '', 174, 1),
(175, 'Romania', 'RO', 'ROM', '', 175, 1),
(176, 'Russian Federation', 'RU', 'RUS', '', 176, 1),
(177, 'Rwanda', 'RW', 'RWA', '', 177, 1),
(178, 'Saint Kitts and Nevis', 'KN', 'KNA', '', 178, 1),
(179, 'Saint Lucia', 'LC', 'LCA', '', 179, 1),
(180, 'Saint Vincent and the Grenadines', 'VC', 'VCT', '', 180, 1),
(181, 'Samoa', 'WS', 'WSM', '', 181, 1),
(182, 'San Marino', 'SM', 'SMR', '', 182, 1),
(183, 'Sao Tome and Principe', 'ST', 'STP', '', 183, 1),
(184, 'Saudi Arabia', 'SA', 'SAU', '', 184, 1),
(185, 'Senegal', 'SN', 'SEN', '', 185, 1),
(186, 'Seychelles', 'SC', 'SYC', '', 186, 1),
(187, 'Sierra Leone', 'SL', 'SLE', '', 187, 1),
(188, 'Singapore', 'SG', 'SGP', '', 188, 1),
(189, 'Slovak Republic', 'SK', 'SVK', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city} {postcode}\r\n{zone}\r\n{country}', 189, 1),
(190, 'Slovenia', 'SI', 'SVN', '', 190, 1),
(191, 'Solomon Islands', 'SB', 'SLB', '', 191, 1),
(192, 'Somalia', 'SO', 'SOM', '', 192, 1),
(193, 'South Africa', 'ZA', 'ZAF', '', 193, 1),
(194, 'South Georgia &amp; South Sandwich Islands', 'GS', 'SGS', '', 194, 1),
(195, 'Spain', 'ES', 'ESP', '', 195, 1),
(196, 'Sri Lanka', 'LK', 'LKA', '', 196, 1),
(197, 'St. Helena', 'SH', 'SHN', '', 197, 1),
(198, 'St. Pierre and Miquelon', 'PM', 'SPM', '', 198, 1),
(199, 'Sudan', 'SD', 'SDN', '', 199, 1),
(200, 'Suriname', 'SR', 'SUR', '', 200, 1),
(201, 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '', 201, 1),
(202, 'Swaziland', 'SZ', 'SWZ', '', 202, 1),
(203, 'Sweden', 'SE', 'SWE', '', 203, 1),
(204, 'Switzerland', 'CH', 'CHE', '', 204, 1),
(205, 'Syrian Arab Republic', 'SY', 'SYR', '', 205, 1),
(206, 'Taiwan', 'TW', 'TWN', '', 206, 1),
(207, 'Tajikistan', 'TJ', 'TJK', '', 207, 1),
(208, 'Tanzania, United Republic of', 'TZ', 'TZA', '', 208, 1),
(209, 'Thailand', 'TH', 'THA', '', 209, 1),
(210, 'Togo', 'TG', 'TGO', '', 210, 1),
(211, 'Tokelau', 'TK', 'TKL', '', 211, 1),
(212, 'Tonga', 'TO', 'TON', '', 212, 1),
(213, 'Trinidad and Tobago', 'TT', 'TTO', '', 213, 1),
(214, 'Tunisia', 'TN', 'TUN', '', 214, 1),
(215, 'Turkey', 'TR', 'TUR', '', 215, 1),
(216, 'Turkmenistan', 'TM', 'TKM', '', 216, 1),
(217, 'Turks and Caicos Islands', 'TC', 'TCA', '', 217, 1),
(218, 'Tuvalu', 'TV', 'TUV', '', 218, 1),
(219, 'Uganda', 'UG', 'UGA', '', 219, 1),
(220, 'Ukraine', 'UA', 'UKR', '', 220, 1),
(221, 'United Arab Emirates', 'AE', 'ARE', '', 221, 1),
(222, 'United Kingdom', 'GB', 'GBR', '', 222, 1),
(223, 'United States', 'US', 'USA', '{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city}, {zone} {postcode}\r\n{country}', 223, 1),
(224, 'United States Minor Outlying Islands', 'UM', 'UMI', '', 224, 1),
(225, 'Uruguay', 'UY', 'URY', '', 225, 1),
(226, 'Uzbekistan', 'UZ', 'UZB', '', 226, 1),
(227, 'Vanuatu', 'VU', 'VUT', '', 227, 1),
(228, 'Vatican City State (Holy See)', 'VA', 'VAT', '', 228, 1),
(229, 'Venezuela', 'VE', 'VEN', '', 229, 1),
(230, 'Viet Nam', 'VN', 'VNM', '', 230, 1),
(231, 'Virgin Islands (British)', 'VG', 'VGB', '', 231, 1),
(232, 'Virgin Islands (U.S.)', 'VI', 'VIR', '', 232, 1),
(233, 'Wallis and Futuna Islands', 'WF', 'WLF', '', 233, 1),
(234, 'Western Sahara', 'EH', 'ESH', '', 234, 1),
(235, 'Yemen', 'YE', 'YEM', '', 235, 1),
(236, 'Yugoslavia', 'YU', 'YUG', '', 236, 1),
(237, 'Democratic Republic of Congo', 'CD', 'COD', '', 237, 1),
(238, 'Zambia', 'ZM', 'ZMB', '', 238, 1),
(239, 'Zimbabwe', 'ZW', 'ZWE', '', 239, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_dissertation`
--

CREATE TABLE IF NOT EXISTS `tb_dissertation` (
  `dissertation_id` int(255) NOT NULL AUTO_INCREMENT,
  `std_id` int(11) NOT NULL,
  `disseration_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `disseration_desc` text COLLATE utf8_bin NOT NULL,
  `disseration_cohort` int(255) NOT NULL,
  `disseration_program` int(11) NOT NULL DEFAULT '1',
  `disseration_concentration` int(255) NOT NULL,
  `disseration_language` int(3) NOT NULL DEFAULT '1',
  `disseration_process_state` enum('N','A','S','C') COLLATE utf8_bin NOT NULL DEFAULT 'N' COMMENT 'N--Not Started, A--Allocated, S--PassingthroughStages, C--completed',
  `disseration_status` enum('A','D') CHARACTER SET latin1 NOT NULL DEFAULT 'A',
  `disseration_doc` datetime NOT NULL,
  `disseration_doe` datetime NOT NULL,
  PRIMARY KEY (`dissertation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tb_dissertation`
--

INSERT INTO `tb_dissertation` (`dissertation_id`, `std_id`, `disseration_name`, `disseration_desc`, `disseration_cohort`, `disseration_program`, `disseration_concentration`, `disseration_language`, `disseration_process_state`, `disseration_status`, `disseration_doc`, `disseration_doe`) VALUES
(1, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:49:17', '0000-00-00 00:00:00'),
(2, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:49:27', '0000-00-00 00:00:00'),
(3, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:50:29', '0000-00-00 00:00:00'),
(4, 0, '', '', 0, 1, 0, 0, 'N', 'A', '2013-12-12 16:51:17', '0000-00-00 00:00:00'),
(5, 3, 'something', '', 3, 2, 1, 2, 'A', 'A', '2013-12-12 16:57:19', '2015-09-28 06:28:16'),
(6, 3, 'french', '', 3, 1, 1, 2, 'A', 'A', '2013-12-12 17:58:56', '0000-00-00 00:00:00'),
(7, 3, 'Church unity in the 21st century, USA', '', 4, 1, 3, 1, 'S', 'A', '2013-12-12 17:59:43', '2014-12-14 12:27:46'),
(8, 5, 'Running with endurence as we the church faces internal challenges', '', 5, 1, 4, 1, 'A', 'A', '2013-12-18 05:27:17', '2014-12-14 12:29:09'),
(9, 5, 'Churches role in envouraging evangelists', '', 4, 1, 3, 2, 'A', 'A', '2013-12-18 05:45:50', '2014-12-14 12:29:44'),
(10, 5, 'Technical Skills', '', 5, 1, 5, 1, 'A', 'A', '2013-12-18 08:53:27', '2013-12-18 08:53:40'),
(11, 5, 'Knowledge', '', 5, 1, 1, 3, 'A', 'A', '2013-12-18 09:06:01', '2013-12-18 09:06:35'),
(12, 5, 'Latest Technologies', '', 5, 1, 5, 1, 'A', 'A', '2013-12-18 09:07:31', '0000-00-00 00:00:00'),
(13, 5, 'Educational necessities for the current day church', '', 5, 1, 4, 1, 'A', 'A', '2013-12-18 12:49:56', '2014-12-14 12:28:18'),
(14, 8, 'Phd:A Theoretical Framework for an Integrated Competency-Based Approach to Theological Education in the Assemblies of God, Ghana', '', 5, 1, 4, 1, 'S', 'A', '2014-01-01 02:18:43', '2015-09-28 06:23:47'),
(15, 11, 'A Theoretical Framework for Integrating Missions into Theological Education in the Assemblies of God, Liberia: A Strategy for Enhancing the Sending Capacity of the Church', '', 6, 1, 4, 1, 'S', 'A', '2014-04-11 21:26:04', '0000-00-00 00:00:00'),
(17, 11, 'Educational necessities for the current day church', '', 6, 1, 4, 2, 'A', 'A', '2014-12-13 23:59:56', '2014-12-17 05:13:08'),
(18, 8, 'A Theory of Leadership Emergence Among Pastors of Assemblies of God District in Texas, USA', '', 8, 1, 5, 1, 'S', 'A', '2014-12-14 04:30:19', '2014-12-14 12:44:38'),
(19, 11, 'Testing by Sri', '', 5, 1, 5, 2, 'A', 'A', '2015-09-25 09:53:36', '2015-10-05 14:15:41'),
(20, 8, 'testing123', '', 3, 2, 1, 1, 'N', 'A', '2015-09-28 06:29:16', '2015-10-05 14:20:50'),
(22, 3, 'something is better than nothing', 'something is better than nothing', 3, 1, 4, 1, 'S', 'A', '2015-10-09 01:26:46', '0000-00-00 00:00:00'),
(23, 3, 'testing123', 'testing123', 4, 1, 4, 1, 'A', 'A', '2015-10-09 02:23:18', '0000-00-00 00:00:00'),
(24, 3, 'something is testing', 'something is testing', 3, 1, 0, 2, 'N', 'A', '2016-01-01 23:29:11', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_dissertation_documents`
--

CREATE TABLE IF NOT EXISTS `tb_dissertation_documents` (
  `document_id` int(255) NOT NULL AUTO_INCREMENT,
  `document_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `document_path` varchar(255) COLLATE utf8_bin NOT NULL,
  `disseration_id` int(255) NOT NULL,
  `document_uploader` int(255) NOT NULL,
  `document_hid` int(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tb_dissertation_documents`
--

INSERT INTO `tb_dissertation_documents` (`document_id`, `document_name`, `document_path`, `disseration_id`, `document_uploader`, `document_hid`) VALUES
(1, 'Dissertation Tracking System.docx', '10_Dissertation_Tracking_System.docx', 14, 8, 10),
(2, '5.29483.00.00.100481-20140120.pdf', '12_5.29483.00.00.100481-20140120.pdf', 7, 3, 12),
(3, 'Answer to Chuck Wilson  Ettiene Zongo.docx', '15_Answer_to_Chuck_Wilson__Ettiene_Zongo.docx', 14, 7, 15),
(4, 'DDM Review Draft_with_Marvins_Changes_and_Title_Changes (1).docx', '15_DDM_Review_Draft_with_Marvins_Changes_and_Title_Changes_(1).docx', 14, 7, 15),
(5, '1.67255445-20140125.pdf', '18_1.67255445-20140125.pdf', 7, 2, 18),
(6, '1.67255307-20140125.pdf', '19_1.67255307-20140125.pdf', 7, 3, 19),
(7, 'SriKadari_2005_Prospectus_V1.docx', '21_SriKadari_2005_Prospectus_V1.docx', 14, 8, 21),
(8, 'TheoreticalFramework-Jimmy-Chapter1.docx', '29_TheoreticalFramework-Jimmy-Chapter1.docx', 15, 11, 29),
(9, 'SriKadari_2005_Prospectus_V1-commented by Dean Of Research.docx', '30_SriKadari_2005_Prospectus_V1-commented_by_Dean_Of_Research.docx', 14, 9, 30),
(10, 'DTS-Admin-Help-V2.0.docx', '34_DTS-Admin-Help-V2.0.docx', 15, 11, 34),
(11, 'Preliminary - A Theory of Leadership Emergence Among Pastors of Assemblies of God District in Texas.docx', '35_Preliminary_-_A_Theory_of_Leadership_Emergence_Among_Pastors_of_Assemblies_of_God_District_in_Texas.docx', 18, 8, 35),
(12, 'IAM_Project_documentation.doc', '37_IAM_Project_documentation.doc', 22, 3, 37);

-- --------------------------------------------------------

--
-- Table structure for table `tb_dissertation_history`
--

CREATE TABLE IF NOT EXISTS `tb_dissertation_history` (
  `history_id` int(255) NOT NULL AUTO_INCREMENT,
  `std_id` int(255) NOT NULL,
  `dissertation_id` int(255) NOT NULL,
  `staff_id` int(255) NOT NULL,
  `role_id` int(3) NOT NULL,
  `stage_id` int(3) NOT NULL,
  `comments` text COLLATE utf8_bin NOT NULL,
  `status` enum('A','C','S','M','F') COLLATE utf8_bin DEFAULT NULL,
  `next_id` int(255) NOT NULL DEFAULT '0',
  `next_order` int(3) NOT NULL DEFAULT '0',
  `chk_staff` int(255) NOT NULL DEFAULT '0',
  `doc` datetime NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=42 ;

--
-- Dumping data for table `tb_dissertation_history`
--

INSERT INTO `tb_dissertation_history` (`history_id`, `std_id`, `dissertation_id`, `staff_id`, `role_id`, `stage_id`, `comments`, `status`, `next_id`, `next_order`, `chk_staff`, `doc`) VALUES
(1, 3, 5, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(2, 3, 6, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(3, 3, 7, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(4, 5, 8, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(5, 5, 9, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(6, 5, 10, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(7, 5, 11, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(8, 5, 12, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(9, 8, 14, 0, 0, 0, '', 'S', 8, 0, 0, '0000-00-00 00:00:00'),
(10, 8, 14, 0, 1, 1, 'This is a test note / <STRONG>comments.</STRONG>', 'S', 7, 1, 0, '2014-01-01 02:22:53'),
(14, 3, 7, 0, 1, 1, '', 'S', 2, 1, 0, '2014-01-24 16:28:07'),
(15, 8, 14, 7, 1, 1, '<P>This is a testing <STRONG>comment</STRONG>...</P>\r\n<P>&nbsp;</P>', 'M', 8, 1, 0, '2014-01-25 15:59:23'),
(16, 8, 14, 0, 1, 1, 'Sorry sir.. please review once again.', 'S', 7, 1, 0, '2014-01-25 16:04:54'),
(17, 8, 14, 7, 1, 1, 'I like it.', 'A', 8, 2, 0, '2014-01-25 16:05:20'),
(18, 3, 7, 2, 1, 1, 'something is important', 'A', 3, 2, 0, '0000-00-00 00:00:00'),
(19, 3, 7, 0, 2, 2, 'llkjkljlkjklj ljjl;kjkl', 'S', 4, 2, 0, '2014-01-27 20:28:08'),
(20, 5, 13, 0, 0, 0, '', 'S', 5, 0, 0, '0000-00-00 00:00:00'),
(21, 8, 14, 0, 2, 2, 'Dr. Wilson,&nbsp;<div>Please review the attached Prospectus for my work.</div><div><br /></div><div>Thanks,</div><div>Sri</div>', 'S', 7, 2, 0, '2014-01-28 10:58:01'),
(22, 8, 14, 7, 2, 2, 'Dr. Gilbert, please review the documentation from our student. I approve this.', 'A', 9, 3, 0, '2014-01-28 11:36:56'),
(23, 11, 15, 0, 0, 0, '', 'S', 11, 0, 0, '0000-00-00 00:00:00'),
(24, 11, 15, 0, 1, 1, 'adadf', 'S', 7, 1, 0, '2014-04-11 21:29:42'),
(25, 11, 15, 7, 1, 1, '', 'A', 11, 2, 0, '2014-04-11 21:30:39'),
(26, 11, 15, 0, 2, 2, 'dadadf', 'S', 7, 2, 0, '2014-04-11 21:31:43'),
(27, 11, 15, 7, 2, 2, '', 'A', 9, 3, 0, '2014-04-11 21:33:57'),
(28, 11, 15, 9, 5, 2, '', 'A', 11, 4, 0, '2014-04-11 21:37:55'),
(29, 11, 15, 0, 4, 3, 'Please review the attached Chapter 1.<br /><br />I will follow-up with Mr.John Smith for the open questions.<br /><br />Thanks,<br />Jimmy.', 'S', 7, 4, 0, '2014-11-15 03:20:36'),
(30, 8, 14, 9, 5, 2, '<div>Hi Sri,&nbsp;</div><div><br /></div>The prospectus looks good to me. &nbsp;My only comment is that on page 12, the theme is not clear. &nbsp;I reworded it and attached the file. &nbsp;Check it.&nbsp;<div>Otherwise, I approve it.</div><div><br /></div><div>Thanks,</div><div>Dr. Gilbert</div>', 'C', 8, 4, 0, '2014-11-15 05:31:44'),
(31, 8, 18, 0, 0, 0, '', 'S', 8, 0, 0, '0000-00-00 00:00:00'),
(32, 11, 17, 0, 0, 0, '', 'S', 11, 0, 0, '0000-00-00 00:00:00'),
(33, 11, 15, 7, 4, 3, 'job completed<div>This is testing</div><div>done by</div><div>Dave <span style="font-weight: bold;">and </span>Sri</div><div><br /></div>', 'A', 11, 5, 0, '2015-03-12 22:16:21'),
(34, 11, 15, 0, 4, 4, 'Testing and email functionality', 'S', 7, 5, 0, '2015-09-05 05:18:55'),
(35, 8, 18, 0, 1, 1, 'Dear Bill Kirsch,<div><br /></div><div>Please find attached is my Preliminary Literature for review.</div><div><br /></div><div>Thanks,</div><div>Sri</div>', 'S', 10, 1, 0, '2015-09-08 02:39:17'),
(36, 3, 22, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(37, 3, 22, 0, 1, 1, 'something is better than nothing...', 'S', 10, 1, 0, '2015-10-09 01:55:12'),
(38, 3, 22, 10, 1, 1, 'ok fine', 'A', 3, 2, 0, '2015-10-09 02:02:14'),
(39, 11, 19, 0, 0, 0, '', 'S', 11, 0, 0, '0000-00-00 00:00:00'),
(40, 3, 23, 0, 0, 0, '', 'S', 3, 0, 0, '0000-00-00 00:00:00'),
(41, 0, 24, 0, 0, 0, '', 'S', 0, 0, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_languages`
--

CREATE TABLE IF NOT EXISTS `tb_languages` (
  `lang_id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `lang_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `lang_code` char(4) COLLATE utf8_bin NOT NULL,
  `lang_doc` datetime NOT NULL,
  `lang_dom` datetime NOT NULL,
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `lang_name` (`lang_name`,`lang_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Languages' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tb_languages`
--

INSERT INTO `tb_languages` (`lang_id`, `lang_name`, `lang_code`, `lang_doc`, `lang_dom`) VALUES
(1, 'English', 'Engl', '2013-10-03 16:38:03', '2014-12-12 12:06:14'),
(2, 'French', 'Fren', '2013-10-03 16:38:34', '0000-00-00 00:00:00'),
(3, 'Other', 'Othe', '2013-10-03 16:38:51', '2014-12-17 12:21:51'),
(5, 'Swahili', 'Kny1', '2014-12-13 01:04:02', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_programs`
--

CREATE TABLE IF NOT EXISTS `tb_programs` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `program_mandatory` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N',
  PRIMARY KEY (`program_id`),
  UNIQUE KEY `pname` (`program_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tb_programs`
--

INSERT INTO `tb_programs` (`program_id`, `program_name`, `program_mandatory`) VALUES
(1, 'D.Min', 'N'),
(2, 'Phd', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tb_roles`
--

CREATE TABLE IF NOT EXISTS `tb_roles` (
  `role_id` smallint(3) NOT NULL AUTO_INCREMENT,
  `role_title` varchar(255) COLLATE utf8_bin NOT NULL,
  `role_sc` varchar(5) COLLATE utf8_bin NOT NULL,
  `role_desc` text COLLATE utf8_bin NOT NULL,
  `role_num` smallint(2) NOT NULL DEFAULT '1',
  `role_disp_ord` smallint(3) NOT NULL DEFAULT '0',
  `role_reqd` tinyint(1) NOT NULL DEFAULT '0',
  `role_constraints` tinyint(2) NOT NULL DEFAULT '0',
  `role_status` enum('A','D') COLLATE utf8_bin NOT NULL DEFAULT 'A',
  `role_doc` datetime NOT NULL,
  `role_dom` datetime NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_title` (`role_title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Different Roles RES992, RES993 ..... ' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tb_roles`
--

INSERT INTO `tb_roles` (`role_id`, `role_title`, `role_sc`, `role_desc`, `role_num`, `role_disp_ord`, `role_reqd`, `role_constraints`, `role_status`, `role_doc`, `role_dom`) VALUES
(1, 'RES 9103 Faculty', '9103', 'RES 9103 Faculty', 1, 1, 1, 0, 'A', '2013-09-04 00:00:00', '2015-09-08 02:34:52'),
(2, 'RES 9153 Faculty', '9153', 'Second Level Faculty', 1, 2, 0, 0, 'A', '0000-00-00 00:00:00', '2015-09-08 02:35:09'),
(3, 'RES 9203 Faculty', '', 'Level 3', 1, 4, 0, 0, 'A', '2013-09-04 00:00:00', '2014-11-01 21:17:34'),
(4, 'Research Supervisor', 'DS', 'Research Supervisor', 1, 3, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:59:14'),
(5, 'Dean of Research', 'DR', 'Dean', 1, 5, 0, 0, 'A', '2013-09-04 00:00:00', '0000-00-00 00:00:00'),
(6, 'Second Reader', 'SR', 'Dean', 1, 6, 0, 0, 'A', '2013-09-04 00:00:00', '0000-00-00 00:00:00'),
(7, 'Research Coordinator', 'DC', 'Research Coordinator', 1, 7, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:58:30'),
(8, 'Research Proposal Review Board', 'DPRB', 'Research Proposal Review Board', 1, 9, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:58:55'),
(9, 'Institutional Editor', 'InsED', 'Dean', 1, 8, 0, 0, 'A', '2013-09-04 00:00:00', '2014-10-29 06:47:16'),
(10, 'Research Committee', 'DCom', 'Research Committee', 1, 10, 0, 0, 'A', '2013-09-04 00:00:00', '2015-09-30 08:57:44'),
(11, 'Provost', 'Provo', '', 1, 11, 0, 0, 'A', '2013-09-24 00:00:00', '2015-09-08 02:35:02'),
(13, 'CFS', 'CFS', '', 1, 12, 1, 1, 'A', '2013-12-18 13:31:56', '2014-07-30 23:10:56');

-- --------------------------------------------------------

--
-- Table structure for table `tb_role_stage_rel`
--

CREATE TABLE IF NOT EXISTS `tb_role_stage_rel` (
  `stg_role_id` int(255) NOT NULL AUTO_INCREMENT,
  `stg_id` int(3) NOT NULL,
  `role_id` int(3) NOT NULL,
  `rel_ord` int(2) NOT NULL DEFAULT '1',
  `nextstep` int(3) NOT NULL DEFAULT '0',
  `failstep` int(3) NOT NULL DEFAULT '0',
  `chkrole` int(3) NOT NULL DEFAULT '0',
  `mail_to` int(11) NOT NULL,
  PRIMARY KEY (`stg_role_id`),
  UNIQUE KEY `rel_ord` (`rel_ord`),
  KEY `rel_ord_2` (`rel_ord`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tb_role_stage_rel`
--

INSERT INTO `tb_role_stage_rel` (`stg_role_id`, `stg_id`, `role_id`, `rel_ord`, `nextstep`, `failstep`, `chkrole`, `mail_to`) VALUES
(1, 1, 1, 1, 0, 0, 0, 0),
(2, 2, 2, 2, 3, 0, 0, 0),
(3, 2, 5, 3, 0, 2, 0, 4),
(4, 3, 4, 4, 0, 0, 0, 0),
(5, 4, 4, 5, 0, 0, 0, 0),
(6, 5, 4, 6, 0, 0, 0, 0),
(7, 6, 4, 7, 8, 0, 0, 0),
(8, 6, 5, 8, 0, 7, 0, 0),
(9, 7, 4, 9, 10, 0, 0, 0),
(10, 7, 3, 10, 11, 9, 0, 0),
(11, 7, 7, 11, 12, 9, 12, 0),
(12, 7, 8, 12, 0, 9, 0, 4),
(13, 8, 4, 13, 14, 0, 0, 0),
(14, 8, 6, 14, 0, 13, 0, 0),
(15, 9, 4, 15, 16, 0, 0, 0),
(16, 9, 6, 16, 17, 15, 0, 0),
(17, 9, 7, 17, 18, 15, 12, 0),
(18, 9, 9, 18, 0, 15, 0, 0),
(19, 10, 10, 19, 20, 0, 0, 0),
(20, 10, 11, 20, 0, 0, 0, 0),
(21, 11, 13, 21, 0, 0, 0, 0),
(22, 9, 13, 22, 0, 0, 0, 13);

-- --------------------------------------------------------

--
-- Table structure for table `tb_stages`
--

CREATE TABLE IF NOT EXISTS `tb_stages` (
  `stg_id` int(255) NOT NULL AUTO_INCREMENT,
  `stg_title` varchar(255) CHARACTER SET latin1 NOT NULL,
  `stg_description` text CHARACTER SET latin1 NOT NULL,
  `stg_order` int(2) NOT NULL,
  `stg_sts` enum('A','D') CHARACTER SET latin1 NOT NULL DEFAULT 'A',
  `stg_doc` datetime NOT NULL,
  `stg_dom` datetime NOT NULL,
  PRIMARY KEY (`stg_id`),
  UNIQUE KEY `stg_title` (`stg_title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tb_stages`
--

INSERT INTO `tb_stages` (`stg_id`, `stg_title`, `stg_description`, `stg_order`, `stg_sts`, `stg_doc`, `stg_dom`) VALUES
(1, 'Prelim. Lit. Review', '', 1, 'A', '2013-09-15 00:00:00', '0000-00-00 00:00:00'),
(2, 'Prospectus', '', 2, 'A', '2013-09-09 00:00:00', '0000-00-00 00:00:00'),
(3, 'Chapter 1', '', 3, 'A', '2013-09-11 00:00:00', '0000-00-00 00:00:00'),
(4, 'Chapter 2', '', 4, 'A', '2013-09-10 00:00:00', '0000-00-00 00:00:00'),
(5, 'Chapter 3', '', 5, 'A', '2013-09-11 00:00:00', '0000-00-00 00:00:00'),
(6, 'Chapter 4', '', 6, 'A', '2013-09-09 00:00:00', '0000-00-00 00:00:00'),
(7, 'Proposal', 'Proposal', 7, 'A', '2013-10-08 00:00:00', '2014-11-06 12:03:05'),
(8, 'Chapter 5', '', 8, 'A', '2013-09-11 00:00:00', '0000-00-00 00:00:00'),
(9, 'Chapter 6', '', 9, 'A', '2013-09-09 00:00:00', '0000-00-00 00:00:00'),
(10, 'Defense', '', 10, 'A', '2013-09-15 00:00:00', '0000-00-00 00:00:00'),
(11, 'Chapter7', '', 11, 'A', '2013-12-18 13:01:09', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_student_staff_rel`
--

CREATE TABLE IF NOT EXISTS `tb_student_staff_rel` (
  `rel_id` int(255) NOT NULL AUTO_INCREMENT,
  `std_id` int(255) NOT NULL,
  `dissertation_id` int(255) NOT NULL,
  `role_id` int(5) NOT NULL,
  `staff_id` int(255) NOT NULL,
  `rel_status` enum('A','S','P','C') COLLATE utf8_bin NOT NULL DEFAULT 'A' COMMENT 'A:Assigned,S:Start, P:Process, C:Completed',
  `rel_doc` datetime NOT NULL,
  PRIMARY KEY (`rel_id`),
  KEY `std_id` (`std_id`),
  KEY `dissertation_id` (`dissertation_id`),
  KEY `role_id` (`role_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='staff assigned to student' AUTO_INCREMENT=271 ;

--
-- Dumping data for table `tb_student_staff_rel`
--

INSERT INTO `tb_student_staff_rel` (`rel_id`, `std_id`, `dissertation_id`, `role_id`, `staff_id`, `rel_status`, `rel_doc`) VALUES
(11, 3, 5, 8, 0, 'A', '2013-12-12 16:58:12'),
(12, 3, 5, 10, 0, 'A', '2013-12-12 16:58:12'),
(13, 3, 5, 1, 4, 'A', '2013-12-12 17:58:11'),
(14, 3, 5, 2, 4, 'A', '2013-12-12 17:58:11'),
(15, 3, 5, 3, 4, 'A', '2013-12-12 17:58:11'),
(16, 3, 5, 4, 4, 'A', '2013-12-12 17:58:11'),
(17, 3, 5, 5, 4, 'A', '2013-12-12 17:58:11'),
(18, 3, 5, 6, 4, 'A', '2013-12-12 17:58:11'),
(19, 3, 5, 7, 0, 'A', '2013-12-12 17:58:11'),
(20, 3, 5, 9, 0, 'A', '2013-12-12 17:58:11'),
(21, 3, 5, 11, 0, 'A', '2013-12-12 17:58:11'),
(22, 3, 5, 12, 0, 'A', '2013-12-12 17:58:11'),
(32, 3, 6, 12, 4, 'A', '2013-12-12 17:59:21'),
(33, 3, 6, 8, 0, 'A', '2013-12-12 17:59:21'),
(34, 3, 6, 10, 0, 'A', '2013-12-12 17:59:21'),
(35, 3, 7, 1, 2, 'C', '2013-12-18 05:20:09'),
(36, 3, 7, 2, 4, 'S', '2013-12-18 05:20:09'),
(37, 3, 7, 3, 2, 'A', '2013-12-18 05:20:09'),
(38, 3, 7, 4, 0, 'A', '2013-12-18 05:20:09'),
(39, 3, 7, 5, 0, 'A', '2013-12-18 05:20:09'),
(40, 3, 7, 6, 2, 'A', '2013-12-18 05:20:09'),
(41, 3, 7, 7, 0, 'A', '2013-12-18 05:20:09'),
(42, 3, 7, 9, 0, 'A', '2013-12-18 05:20:09'),
(43, 3, 7, 11, 0, 'A', '2013-12-18 05:20:09'),
(44, 3, 7, 8, 0, 'A', '2013-12-18 05:20:09'),
(45, 3, 7, 10, 0, 'A', '2013-12-18 05:20:09'),
(55, 5, 8, 8, 0, 'A', '2013-12-18 05:34:09'),
(56, 5, 8, 10, 0, 'A', '2013-12-18 05:34:09'),
(57, 5, 8, 1, 2, 'A', '2013-12-18 05:34:39'),
(58, 5, 8, 2, 4, 'A', '2013-12-18 05:34:39'),
(59, 5, 8, 3, 2, 'A', '2013-12-18 05:34:39'),
(60, 5, 8, 4, 4, 'A', '2013-12-18 05:34:39'),
(61, 5, 8, 5, 0, 'A', '2013-12-18 05:34:39'),
(62, 5, 8, 6, 0, 'A', '2013-12-18 05:34:39'),
(63, 5, 8, 7, 0, 'A', '2013-12-18 05:34:39'),
(64, 5, 8, 9, 0, 'A', '2013-12-18 05:34:39'),
(65, 5, 8, 11, 0, 'A', '2013-12-18 05:34:39'),
(66, 5, 9, 1, 2, 'A', '2013-12-18 05:46:43'),
(67, 5, 9, 2, 6, 'A', '2013-12-18 05:46:43'),
(68, 5, 9, 3, 2, 'A', '2013-12-18 05:46:43'),
(69, 5, 9, 4, 6, 'A', '2013-12-18 05:46:43'),
(70, 5, 9, 5, 0, 'A', '2013-12-18 05:46:43'),
(71, 5, 9, 6, 0, 'A', '2013-12-18 05:46:43'),
(72, 5, 9, 7, 0, 'A', '2013-12-18 05:46:43'),
(73, 5, 9, 9, 0, 'A', '2013-12-18 05:46:43'),
(74, 5, 9, 11, 0, 'A', '2013-12-18 05:46:43'),
(75, 5, 9, 12, 6, 'A', '2013-12-18 05:46:43'),
(76, 5, 9, 8, 0, 'A', '2013-12-18 05:46:43'),
(77, 5, 9, 10, 0, 'A', '2013-12-18 05:46:43'),
(78, 5, 10, 1, 2, 'A', '2013-12-18 08:55:04'),
(79, 5, 10, 2, 2, 'A', '2013-12-18 08:55:04'),
(80, 5, 10, 3, 6, 'A', '2013-12-18 08:55:04'),
(81, 5, 10, 4, 6, 'A', '2013-12-18 08:55:04'),
(82, 5, 10, 5, 0, 'A', '2013-12-18 08:55:04'),
(83, 5, 10, 6, 0, 'A', '2013-12-18 08:55:04'),
(84, 5, 10, 7, 0, 'A', '2013-12-18 08:55:04'),
(85, 5, 10, 9, 0, 'A', '2013-12-18 08:55:04'),
(86, 5, 10, 11, 0, 'A', '2013-12-18 08:55:04'),
(87, 5, 10, 8, 0, 'A', '2013-12-18 08:55:04'),
(88, 5, 10, 10, 0, 'A', '2013-12-18 08:55:04'),
(89, 5, 11, 1, 2, 'A', '2013-12-18 09:14:46'),
(90, 5, 11, 2, 6, 'A', '2013-12-18 09:14:46'),
(91, 5, 11, 3, 2, 'A', '2013-12-18 09:14:46'),
(92, 5, 11, 4, 6, 'A', '2013-12-18 09:14:46'),
(93, 5, 11, 5, 0, 'A', '2013-12-18 09:14:46'),
(94, 5, 11, 6, 0, 'A', '2013-12-18 09:14:46'),
(95, 5, 11, 7, 0, 'A', '2013-12-18 09:14:46'),
(96, 5, 11, 9, 0, 'A', '2013-12-18 09:14:46'),
(97, 5, 11, 11, 0, 'A', '2013-12-18 09:14:46'),
(98, 5, 11, 12, 6, 'A', '2013-12-18 09:14:46'),
(99, 5, 11, 8, 0, 'A', '2013-12-18 09:14:46'),
(100, 5, 11, 10, 0, 'A', '2013-12-18 09:14:46'),
(101, 5, 12, 1, 2, 'A', '2013-12-18 11:09:40'),
(102, 5, 12, 2, 6, 'A', '2013-12-18 11:09:40'),
(103, 5, 12, 3, 2, 'A', '2013-12-18 11:09:40'),
(104, 5, 12, 4, 6, 'A', '2013-12-18 11:09:40'),
(105, 5, 12, 5, 0, 'A', '2013-12-18 11:09:40'),
(106, 5, 12, 6, 0, 'A', '2013-12-18 11:09:40'),
(107, 5, 12, 7, 0, 'A', '2013-12-18 11:09:40'),
(108, 5, 12, 9, 0, 'A', '2013-12-18 11:09:40'),
(109, 5, 12, 11, 0, 'A', '2013-12-18 11:09:40'),
(110, 5, 12, 8, 0, 'A', '2013-12-18 11:09:40'),
(111, 5, 12, 10, 0, 'A', '2013-12-18 11:09:40'),
(112, 8, 14, 1, 7, 'C', '2014-01-01 02:19:24'),
(121, 8, 14, 8, 0, 'A', '2014-01-01 02:19:24'),
(122, 8, 14, 10, 0, 'A', '2014-01-01 02:19:24'),
(123, 8, 14, 13, 0, 'A', '2014-01-01 02:19:24'),
(124, 5, 13, 1, 7, 'A', '2014-01-28 10:40:00'),
(125, 5, 13, 2, 0, 'A', '2014-01-28 10:40:00'),
(126, 5, 13, 3, 0, 'A', '2014-01-28 10:40:00'),
(127, 5, 13, 4, 0, 'A', '2014-01-28 10:40:00'),
(128, 5, 13, 5, 0, 'A', '2014-01-28 10:40:00'),
(129, 5, 13, 6, 0, 'A', '2014-01-28 10:40:00'),
(130, 5, 13, 7, 0, 'A', '2014-01-28 10:40:00'),
(131, 5, 13, 9, 0, 'A', '2014-01-28 10:40:00'),
(132, 5, 13, 11, 0, 'A', '2014-01-28 10:40:00'),
(133, 5, 13, 8, 0, 'A', '2014-01-28 10:40:00'),
(134, 5, 13, 10, 0, 'A', '2014-01-28 10:40:00'),
(135, 5, 13, 13, 0, 'A', '2014-01-28 10:40:00'),
(144, 8, 14, 2, 7, 'C', '2014-01-28 11:35:13'),
(152, 11, 15, 1, 7, 'C', '2014-04-11 21:27:25'),
(161, 11, 15, 8, 0, 'A', '2014-04-11 21:27:25'),
(162, 11, 15, 10, 0, 'A', '2014-04-11 21:27:25'),
(163, 11, 15, 13, 0, 'A', '2014-04-11 21:27:25'),
(164, 11, 15, 2, 7, 'C', '2014-04-11 21:33:29'),
(167, 11, 15, 5, 9, 'C', '2014-04-11 21:33:29'),
(172, 3, 6, 1, 4, 'A', '2014-07-02 07:28:13'),
(173, 3, 6, 2, 10, 'A', '2014-07-02 07:28:13'),
(174, 3, 6, 3, 0, 'A', '2014-07-02 07:28:13'),
(175, 3, 6, 4, 0, 'A', '2014-07-02 07:28:13'),
(176, 3, 6, 5, 0, 'A', '2014-07-02 07:28:13'),
(177, 3, 6, 6, 0, 'A', '2014-07-02 07:28:13'),
(178, 3, 6, 7, 0, 'A', '2014-07-02 07:28:13'),
(179, 3, 6, 9, 0, 'A', '2014-07-02 07:28:13'),
(180, 3, 6, 11, 0, 'A', '2014-07-02 07:28:13'),
(182, 11, 15, 4, 7, 'S', '2014-07-02 07:29:00'),
(187, 8, 14, 4, 9, 'A', '2014-11-15 03:10:52'),
(188, 8, 14, 3, 9, 'A', '2014-11-15 03:10:52'),
(189, 8, 14, 5, 9, 'C', '2014-11-15 03:10:52'),
(190, 8, 14, 6, 9, 'A', '2014-11-15 03:10:52'),
(191, 8, 14, 7, 0, 'A', '2014-11-15 03:10:52'),
(192, 8, 14, 9, 0, 'A', '2014-11-15 03:10:52'),
(193, 8, 14, 11, 0, 'A', '2014-11-15 03:10:52'),
(194, 8, 18, 1, 10, 'S', '2014-12-17 05:12:26'),
(195, 8, 18, 2, 0, 'A', '2014-12-17 05:12:26'),
(196, 8, 18, 4, 7, 'A', '2014-12-17 05:12:26'),
(197, 8, 18, 3, 2, 'A', '2014-12-17 05:12:26'),
(198, 8, 18, 5, 9, 'A', '2014-12-17 05:12:26'),
(199, 8, 18, 6, 10, 'A', '2014-12-17 05:12:26'),
(200, 8, 18, 7, 9, 'A', '2014-12-17 05:12:26'),
(201, 8, 18, 9, 4, 'A', '2014-12-17 05:12:26'),
(202, 8, 18, 8, 10, 'A', '2014-12-17 05:12:26'),
(203, 8, 18, 8, 4, 'A', '2014-12-17 05:12:26'),
(204, 8, 18, 8, 7, 'A', '2014-12-17 05:12:26'),
(205, 8, 18, 11, 0, 'A', '2014-12-17 05:12:26'),
(206, 8, 18, 10, 0, 'A', '2014-12-17 05:12:26'),
(207, 11, 17, 1, 10, 'A', '2014-12-17 05:18:32'),
(208, 11, 17, 2, 0, 'A', '2014-12-17 05:18:32'),
(209, 11, 17, 4, 4, 'A', '2014-12-17 05:18:32'),
(210, 11, 17, 3, 10, 'A', '2014-12-17 05:18:32'),
(211, 11, 17, 5, 9, 'A', '2014-12-17 05:18:32'),
(212, 11, 17, 6, 0, 'A', '2014-12-17 05:18:32'),
(213, 11, 17, 7, 7, 'A', '2014-12-17 05:18:32'),
(214, 11, 17, 9, 10, 'A', '2014-12-17 05:18:32'),
(215, 11, 17, 8, 10, 'A', '2014-12-17 05:18:32'),
(216, 11, 17, 8, 4, 'A', '2014-12-17 05:18:32'),
(217, 11, 17, 11, 0, 'A', '2014-12-17 05:18:32'),
(218, 11, 17, 13, 2, 'A', '2014-12-17 05:18:32'),
(219, 11, 17, 10, 0, 'A', '2014-12-17 05:18:32'),
(220, 11, 15, 3, 0, 'A', '2015-03-12 22:21:04'),
(221, 11, 15, 6, 0, 'A', '2015-03-12 22:21:04'),
(222, 11, 15, 7, 2, 'A', '2015-03-12 22:21:04'),
(223, 11, 15, 9, 4, 'A', '2015-03-12 22:21:04'),
(224, 11, 15, 11, 0, 'A', '2015-03-12 22:21:04'),
(225, 3, 22, 1, 10, 'C', '2015-10-09 01:52:51'),
(226, 3, 22, 2, 0, 'A', '2015-10-09 01:52:51'),
(227, 3, 22, 4, 0, 'A', '2015-10-09 01:52:51'),
(228, 3, 22, 3, 0, 'A', '2015-10-09 01:52:51'),
(229, 3, 22, 5, 4, 'A', '2015-10-09 01:52:51'),
(230, 3, 22, 6, 0, 'A', '2015-10-09 01:52:51'),
(231, 3, 22, 7, 0, 'A', '2015-10-09 01:52:51'),
(232, 3, 22, 9, 0, 'A', '2015-10-09 01:52:51'),
(233, 3, 22, 8, 0, 'A', '2015-10-09 01:52:51'),
(234, 3, 22, 10, 0, 'A', '2015-10-09 01:52:51'),
(235, 3, 22, 11, 0, 'A', '2015-10-09 01:52:51'),
(236, 11, 19, 1, 35, 'A', '2016-01-01 23:11:22'),
(237, 11, 19, 2, 35, 'A', '2016-01-01 23:11:22'),
(238, 11, 19, 4, 0, 'A', '2016-01-01 23:11:22'),
(239, 11, 19, 3, 0, 'A', '2016-01-01 23:11:22'),
(240, 11, 19, 5, 0, 'A', '2016-01-01 23:11:22'),
(241, 11, 19, 6, 0, 'A', '2016-01-01 23:11:22'),
(242, 11, 19, 7, 0, 'A', '2016-01-01 23:11:22'),
(243, 11, 19, 9, 0, 'A', '2016-01-01 23:11:22'),
(244, 11, 19, 8, 0, 'A', '2016-01-01 23:11:22'),
(245, 11, 19, 10, 0, 'A', '2016-01-01 23:11:22'),
(246, 11, 19, 11, 0, 'A', '2016-01-01 23:11:22'),
(247, 11, 19, 13, 47, 'A', '2016-01-01 23:11:22'),
(248, 3, 23, 1, 49, 'A', '2016-01-01 23:27:43'),
(249, 3, 23, 2, 38, 'A', '2016-01-01 23:27:43'),
(250, 3, 23, 4, 98, 'A', '2016-01-01 23:27:43'),
(251, 3, 23, 3, 98, 'A', '2016-01-01 23:27:43'),
(252, 3, 23, 5, 118, 'A', '2016-01-01 23:27:43'),
(253, 3, 23, 6, 44, 'A', '2016-01-01 23:27:43'),
(254, 3, 23, 7, 49, 'A', '2016-01-01 23:27:43'),
(255, 3, 23, 9, 44, 'A', '2016-01-01 23:27:43'),
(256, 3, 23, 8, 37, 'A', '2016-01-01 23:27:43'),
(257, 3, 23, 10, 34, 'A', '2016-01-01 23:27:43'),
(258, 3, 23, 11, 49, 'A', '2016-01-01 23:27:43'),
(259, 0, 24, 1, 49, 'A', '2016-01-01 23:31:08'),
(260, 0, 24, 2, 49, 'A', '2016-01-01 23:31:08'),
(261, 0, 24, 4, 49, 'A', '2016-01-01 23:31:08'),
(262, 0, 24, 3, 49, 'A', '2016-01-01 23:31:08'),
(263, 0, 24, 5, 49, 'A', '2016-01-01 23:31:08'),
(264, 0, 24, 6, 0, 'A', '2016-01-01 23:31:08'),
(265, 0, 24, 7, 0, 'A', '2016-01-01 23:31:08'),
(266, 0, 24, 9, 0, 'A', '2016-01-01 23:31:08'),
(267, 0, 24, 8, 0, 'A', '2016-01-01 23:31:08'),
(268, 0, 24, 10, 0, 'A', '2016-01-01 23:31:08'),
(269, 0, 24, 11, 0, 'A', '2016-01-01 23:31:08'),
(270, 0, 24, 13, 113, 'A', '2016-01-01 23:31:08');

-- --------------------------------------------------------

--
-- Table structure for table `tb_timezones`
--

CREATE TABLE IF NOT EXISTS `tb_timezones` (
  `tz_id` int(12) NOT NULL AUTO_INCREMENT,
  `tz_name` varchar(44) CHARACTER SET utf8 DEFAULT NULL,
  `tz_timezone` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `tz_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tz_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=141 ;

--
-- Dumping data for table `tb_timezones`
--

INSERT INTO `tb_timezones` (`tz_id`, `tz_name`, `tz_timezone`, `tz_default`) VALUES
(1, '(GMT-11:00) Midway Island ', 'Pacific/Midway', 0),
(2, '(GMT-11:00) Samoa ', 'Pacific/Samoa', 0),
(3, '(GMT-10:00) Hawaii ', 'Pacific/Honolulu', 0),
(4, '(GMT-09:00) Alaska ', 'America/Anchorage', 0),
(5, '(GMT-08:00) Pacific Time (US &amp; Canada) ', 'America/Los_Angeles', 0),
(6, '(GMT-08:00) Tijuana ', 'America/Tijuana', 0),
(7, '(GMT-07:00) Chihuahua ', 'America/Chihuahua', 0),
(8, '(GMT-07:00) La Paz ', 'America/Chihuahua', 0),
(9, '(GMT-07:00) Mazatlan ', 'America/Mazatlan', 0),
(10, '(GMT-07:00) Mountain Time (US &amp; Canada) ', 'America/Denver', 0),
(11, '(GMT-06:00) Central America ', 'America/Managua', 0),
(12, '(GMT-06:00) Central Time (US &amp; Canada) ', 'America/Chicago', 0),
(13, '(GMT-06:00) Guadalajara ', 'America/Mexico_City', 0),
(14, '(GMT-06:00) Mexico City ', 'America/Mexico_City', 0),
(15, '(GMT-06:00) Monterrey ', 'America/Monterrey', 0),
(16, '(GMT-05:00) Bogota ', 'America/Bogota', 0),
(17, '(GMT-05:00) Eastern Time (US &amp; Canada) ', 'America/New_York', 0),
(18, '(GMT-05:00) Lima ', 'America/Lima', 0),
(19, '(GMT-05:00) Quito ', 'America/Bogota', 0),
(20, '(GMT-04:00) Atlantic Time (Canada) ', 'Canada/Atlantic', 0),
(21, '(GMT-04:30) Caracas ', 'America/Caracas', 0),
(22, '(GMT-04:00) La Paz ', 'America/La_Paz', 0),
(23, '(GMT-04:00) Santiago ', 'America/Santiago', 0),
(24, '(GMT-03:30) Newfoundland ', 'America/St_Johns', 0),
(25, '(GMT-03:00) Brasilia ', 'America/Sao_Paulo', 0),
(26, '(GMT-03:00) Buenos Aires ', 'America/Argentina/Buenos_Aires', 0),
(27, '(GMT-03:00) Georgetown ', 'America/Argentina/Buenos_Aires', 0),
(28, '(GMT-03:00) Greenland ', 'America/Godthab', 0),
(29, '(GMT-02:00) Mid-Atlantic ', 'America/Noronha', 0),
(30, '(GMT-01:00) Azores ', 'Atlantic/Azores', 0),
(31, '(GMT-01:00) Cape Verde Is. ', 'Atlantic/Cape_Verde', 0),
(32, '(GMT+00:00) Casablanca ', 'Africa/Casablanca', 0),
(33, '(GMT+00:00) Edinburgh ', 'Europe/London', 0),
(34, '(GMT+00:00) Dublin', 'Europe/Dublin', 0),
(35, '(GMT+00:00) Lisbon ', 'Europe/Lisbon', 0),
(36, '(GMT+00:00) London ', 'Europe/London', 0),
(37, '(GMT+00:00) Monrovia ', 'Africa/Monrovia', 0),
(38, '(GMT+00:00) UTC ', 'UTC', 0),
(39, '(GMT+01:00) Amsterdam ', 'Europe/Amsterdam', 0),
(40, '(GMT+01:00) Belgrade ', 'Europe/Belgrade', 0),
(41, '(GMT+01:00) Berlin ', 'Europe/Berlin', 0),
(42, '(GMT+01:00) Bern ', 'Europe/Berlin', 0),
(43, '(GMT+01:00) Bratislava ', 'Europe/Bratislava', 0),
(44, '(GMT+01:00) Brussels ', 'Europe/Brussels', 0),
(45, '(GMT+01:00) Budapest ', 'Europe/Budapest', 0),
(46, '(GMT+01:00) Copenhagen ', 'Europe/Copenhagen', 0),
(47, '(GMT+01:00) Ljubljana ', 'Europe/Ljubljana', 0),
(48, '(GMT+01:00) Madrid ', 'Europe/Madrid', 0),
(49, '(GMT+01:00) Paris ', 'Europe/Paris', 0),
(50, '(GMT+01:00) Prague ', 'Europe/Prague', 0),
(51, '(GMT+01:00) Rome ', 'Europe/Rome', 0),
(52, '(GMT+01:00) Sarajevo ', 'Europe/Sarajevo', 0),
(53, '(GMT+01:00) Skopje ', 'Europe/Skopje', 0),
(54, '(GMT+01:00) Stockholm ', 'Europe/Stockholm', 0),
(55, '(GMT+01:00) Vienna ', 'Europe/Vienna', 0),
(56, '(GMT+01:00) Warsaw ', 'Europe/Warsaw', 0),
(57, '(GMT+01:00) West Central Africa ', 'Africa/Lagos', 0),
(58, '(GMT+01:00) Zagreb ', 'Europe/Zagreb', 0),
(59, '(GMT+02:00) Athens ', 'Europe/Athens', 0),
(60, '(GMT+02:00) Bucharest ', 'Europe/Bucharest', 0),
(61, '(GMT+02:00) Cairo ', 'Africa/Cairo', 0),
(62, '(GMT+02:00) Harare ', 'Africa/Harare', 0),
(63, '(GMT+02:00) Helsinki ', 'Europe/Helsinki', 0),
(64, '(GMT+02:00) Istanbul ', 'Europe/Istanbul', 0),
(65, '(GMT+02:00) Jerusalem ', 'Asia/Jerusalem', 0),
(66, '(GMT+02:00) Kyiv ', 'Europe/Helsinki', 0),
(67, '(GMT+02:00) Pretoria ', 'Africa/Johannesburg', 0),
(68, '(GMT+02:00) Riga ', 'Europe/Riga', 0),
(69, '(GMT+02:00) Sofia ', 'Europe/Sofia', 0),
(70, '(GMT+02:00) Tallinn ', 'Europe/Tallinn', 0),
(71, '(GMT+02:00) Vilnius ', 'Europe/Vilnius', 0),
(72, '(GMT+03:00) Baghdad ', 'Asia/Baghdad', 0),
(73, '(GMT+03:00) Kuwait ', 'Asia/Kuwait', 0),
(74, '(GMT+03:00) Minsk ', 'Europe/Minsk', 0),
(75, '(GMT+03:00) Nairobi ', 'Africa/Nairobi', 0),
(76, '(GMT+03:00) Riyadh ', 'Asia/Riyadh', 0),
(77, '(GMT+03:00) Volgograd ', 'Europe/Volgograd', 0),
(78, '(GMT+03:30) Tehran ', 'Asia/Tehran', 0),
(79, '(GMT+04:00) Abu Dhabi ', 'Asia/Muscat', 0),
(80, '(GMT+04:00) Baku ', 'Asia/Baku', 0),
(81, '(GMT+04:00) Moscow ', 'Europe/Moscow', 0),
(82, '(GMT+04:00) Muscat ', 'Asia/Muscat', 0),
(83, '(GMT+04:00) St. Petersburg ', 'Europe/Moscow', 0),
(84, '(GMT+04:00) Tbilisi ', 'Asia/Tbilisi', 0),
(85, '(GMT+04:00) Yerevan ', 'Asia/Yerevan', 0),
(86, '(GMT+04:30) Kabul ', 'Asia/Kabul', 0),
(87, '(GMT+05:00) Islamabad ', 'Asia/Karachi', 0),
(88, '(GMT+05:00) Karachi ', 'Asia/Karachi', 0),
(89, '(GMT+05:00) Tashkent ', 'Asia/Tashkent', 0),
(90, '(GMT+05:30) Chennai ', 'Asia/Calcutta', 0),
(91, '(GMT+05:30) Kolkata ', 'Asia/Kolkata', 0),
(92, '(GMT+05:30) Mumbai ', 'Asia/Calcutta', 0),
(93, '(GMT+05:30) New Delhi', 'Asia/Calcutta', 1),
(94, '(GMT+05:30) Sri Jayawardenepura ', 'Asia/Calcutta', 0),
(95, '(GMT+05:45) Kathmandu ', 'Asia/Katmandu', 0),
(96, '(GMT+06:00) Almaty ', 'Asia/Almaty', 0),
(97, '(GMT+06:00) Astana ', 'Asia/Dhaka', 0),
(98, '(GMT+06:00) Dhaka ', 'Asia/Dhaka', 0),
(99, '(GMT+06:00) Ekaterinburg ', 'Asia/Yekaterinburg', 0),
(100, '(GMT+06:30) Rangoon ', 'Asia/Rangoon', 0),
(101, '(GMT+07:00) Bangkok ', 'Asia/Bangkok', 0),
(102, '(GMT+07:00) Hanoi ', 'Asia/Bangkok', 0),
(103, '(GMT+07:00) Jakarta ', 'Asia/Jakarta', 0),
(104, '(GMT+07:00) Novosibirsk ', 'Asia/Novosibirsk', 0),
(105, '(GMT+08:00) Beijing ', 'Asia/Hong_Kong', 0),
(106, '(GMT+08:00) Chongqing ', 'Asia/Chongqing', 0),
(107, '(GMT+08:00) Hong Kong ', 'Asia/Hong_Kong', 0),
(108, '(GMT+08:00) Krasnoyarsk ', 'Asia/Krasnoyarsk', 0),
(109, '(GMT+08:00) Kuala Lumpur ', 'Asia/Kuala_Lumpur', 0),
(110, '(GMT+08:00) Perth ', 'Australia/Perth', 0),
(111, '(GMT+08:00) Singapore ', 'Asia/Singapore', 0),
(112, '(GMT+08:00) Taipei ', 'Asia/Taipei', 0),
(113, '(GMT+08:00) Ulaan Bataar ', 'Asia/Ulan_Bator', 0),
(114, '(GMT+08:00) Urumqi ', 'Asia/Urumqi', 0),
(115, '(GMT+09:00) Irkutsk ', 'Asia/Irkutsk', 0),
(116, '(GMT+09:00) Osaka ', 'Asia/Tokyo', 0),
(117, '(GMT+09:00) Sapporo ', 'Asia/Tokyo', 0),
(118, '(GMT+09:00) Seoul ', 'Asia/Seoul', 0),
(119, '(GMT+09:00) Tokyo ', 'Asia/Tokyo', 0),
(120, '(GMT+09:30) Adelaide ', 'Australia/Adelaide', 0),
(121, '(GMT+09:30) Darwin ', 'Australia/Darwin', 0),
(122, '(GMT+10:00) Brisbane ', 'Australia/Brisbane', 0),
(123, '(GMT+10:00) Canberra ', 'Australia/Canberra', 0),
(124, '(GMT+10:00) Guam ', 'Pacific/Guam', 0),
(125, '(GMT+10:00) Hobart ', 'Australia/Hobart', 0),
(126, '(GMT+10:00) Melbourne ', 'Australia/Melbourne', 0),
(127, '(GMT+10:00) Port Moresby ', 'Pacific/Port_Moresby', 0),
(128, '(GMT+10:00) Sydney ', 'Australia/Sydney', 0),
(129, '(GMT+10:00) Yakutsk ', 'Asia/Yakutsk', 0),
(130, '(GMT+11:00) Vladivostok ', 'Asia/Vladivostok', 0),
(131, '(GMT+12:00) Auckland ', 'Pacific/Auckland', 0),
(132, '(GMT+12:00) Fiji ', 'Pacific/Fiji', 0),
(133, '(GMT+12:00) International Date Line West ', 'Pacific/Kwajalein', 0),
(134, '(GMT+12:00) Kamchatka ', 'Asia/Kamchatka', 0),
(135, '(GMT+12:00) Magadan ', 'Asia/Magadan', 0),
(136, '(GMT+12:00) Marshall Is. ', 'Pacific/Fiji', 0),
(137, '(GMT+12:00) New Caledonia ', 'Asia/Magadan', 0),
(138, '(GMT+12:00) Solomon Is. ', 'Asia/Magadan', 0),
(139, '(GMT+12:00) Wellington ', 'Pacific/Auckland', 0),
(140, '(GMT+13:00) Nuku\\alofa ', 'Pacific/Tongatapu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE IF NOT EXISTS `tb_users` (
  `user_id` int(255) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_password` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_fullname` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_type` enum('SA','SD','SF','AD') COLLATE utf8_bin NOT NULL DEFAULT 'SD',
  `user_email` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_status` enum('A','D') COLLATE utf8_bin NOT NULL DEFAULT 'D',
  `user_sess` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_login` datetime NOT NULL,
  `user_doc` datetime NOT NULL,
  `user_dom` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User Types' AUTO_INCREMENT=122 ;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`user_id`, `user_name`, `user_password`, `user_fullname`, `user_type`, `user_email`, `user_status`, `user_sess`, `user_login`, `user_doc`, `user_dom`) VALUES
(1, 'superadmin', '17c4520f6cfd1ab53d8745e84681eb49', 'Sri Kadari', 'SA', 'superadmin@distracker.com', 'A', 'nugm6s73b19dc6g7c60uv4bhc7', '2016-01-19 00:34:11', '2013-09-04 00:00:00', '2014-08-22 11:01:33'),
(3, 'student', 'cd73502828457d15655bbd7a63fb0bc8', 'Ayi M. Adade', 'SD', 'beneco10@yahoo.fr', 'A', 'lppdre2lrfbgt0fck8s7lkl5o0', '2016-02-20 15:50:09', '2013-12-12 15:19:50', '2015-06-05 01:13:53'),
(4, 'daja01', '02e98800f21e0d79b83c2f481614bc96', 'David Aja', 'SD', 'daemacares@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:21:19', '2015-06-05 01:15:15'),
(5, 'parthur', '02e98800f21e0d79b83c2f481614bc96', 'Phillip Arthur', 'SD', 'revphi@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:22:16', '2015-06-05 01:16:55'),
(6, 'nbanda', '02e98800f21e0d79b83c2f481614bc96', 'Nelson Banda', 'SD', 'nelsonbanda53@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:23:51', '2015-06-05 01:17:31'),
(7, 'dbangoret', '02e98800f21e0d79b83c2f481614bc96', 'Dominique Bangoret', 'SD', '000206@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:25:24', '2014-05-17 02:25:55'),
(8, 'mbomboko', '02e98800f21e0d79b83c2f481614bc96', 'Marcel Bomboko', 'SD', 'marcel_bomboko@yahoo.fr', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:27:22', '2015-06-05 01:22:35'),
(9, 'cbomboko', '02e98800f21e0d79b83c2f481614bc96', 'Cecile Bomboko', 'SD', 'cecilebomboko@yahoo.fr', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:28:39', '2015-06-05 01:50:16'),
(10, 'cvdzoagbe', '02e98800f21e0d79b83c2f481614bc96', 'Chris Victor Dzoagbe', 'SD', 'paschris@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:29:59', '2015-06-05 01:26:52'),
(11, 'jeikpe', '02e98800f21e0d79b83c2f481614bc96', 'Joel Ede Ikpe', 'SD', '000211@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:53:51', '2014-05-17 02:36:40'),
(12, 'jnelson', '02e98800f21e0d79b83c2f481614bc96', 'Jeff Nelson', 'SD', 'jeff.nelson@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:54:56', '2015-04-23 16:26:20'),
(13, 'fniba01', '02e98800f21e0d79b83c2f481614bc96', 'Felix Niba', 'SD', 'felixniba@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:55:54', '2015-06-05 01:58:04'),
(14, 'ncoganya', '02e98800f21e0d79b83c2f481614bc96', 'Ngozi Cecilia Oganya', 'SD', '000213@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:56:53', '2014-05-17 07:31:20'),
(15, 'lyoppong', '02e98800f21e0d79b83c2f481614bc96', 'Louis Yaw Oppong-Kyekyeku', 'SD', '000214@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:57:57', '2014-05-17 02:40:10'),
(16, 'gnpanka', '02e98800f21e0d79b83c2f481614bc96', 'Gideon Namyela Panka', 'SD', '000215@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 15:59:16', '2014-05-17 02:33:54'),
(17, 'ssaba01', '02e98800f21e0d79b83c2f481614bc96', 'Salam Saba', 'SD', '000216@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:01:36', '2014-05-17 07:50:04'),
(18, 'dsaglimbeni', '02e98800f21e0d79b83c2f481614bc96', 'Dan Saglimbeni', 'SD', '000217@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:02:21', '2014-05-17 02:21:42'),
(20, 'gbagudu', '02e98800f21e0d79b83c2f481614bc96', 'Gideon Bagudu', 'SD', 'gbagudu@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:12:44', '2015-06-05 19:54:21'),
(21, 'cdampak', '02e98800f21e0d79b83c2f481614bc96', 'Caleb Dampak', 'SD', 'pstdampak@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:13:34', '2015-06-05 01:23:58'),
(22, 'oejindu', '3b9b6cb55ffea3bc109172d1344d9211', 'Ogboso Ejindu', 'SD', 'ogbosoe@yahoo.com', 'A', '00ca9a06ee5267da8f835f3612d9df4b', '0000-00-00 00:00:00', '2013-12-12 16:14:19', '2015-10-07 17:39:51'),
(23, 'oflindja', '02e98800f21e0d79b83c2f481614bc96', 'Douti Flindja', 'SD', 'flindouti@yahoo.fr', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:15:10', '2015-06-05 01:32:42'),
(24, 'aikedinma', '2f97b0a76091e74afc866a88d4bc5db9', 'Alfred Ikedinma', 'SD', 'alfredikedinma@gmail.com', 'A', '7965aae072606e5c2fad39609d58e970', '0000-00-00 00:00:00', '2013-12-12 16:16:34', '2015-09-24 18:15:29'),
(25, 'jilunga', '02e98800f21e0d79b83c2f481614bc96', 'Jean Ilunga', 'SD', '000424@distracker.com', 'D', '0', '0000-00-00 00:00:00', '2013-12-12 16:17:51', '2015-06-05 01:39:32'),
(26, 'ckoutouan', 'd79da8da64ae74198da4247ea3e2db45', 'Claver Koutouan', 'SD', 'koclavery@yahoo.fr', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:18:44', '2015-06-05 01:45:51'),
(27, 'jkuoh01', '02e98800f21e0d79b83c2f481614bc96', 'Jimmy Kuoh', 'SD', 'jimmyandchristinakuoh@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:19:46', '2015-06-05 01:47:46'),
(28, 'wmuyabwa', 'a85765e3e58afde4749a4c427af84990', 'William Muyabwa', 'SD', 'wmuyabwa@gmail.com', 'A', '77527de0623f2b4aeed3445e56a7bc38', '0000-00-00 00:00:00', '2013-12-12 16:20:44', '2015-07-16 01:26:57'),
(29, 'poganya', '02e98800f21e0d79b83c2f481614bc96', 'Paul Oganya', 'SD', '000428@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:21:37', '2014-05-17 02:04:35'),
(30, 'kokereke', '02e98800f21e0d79b83c2f481614bc96', 'Kingsley Okereke', 'SD', '000429@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:22:27', '2014-05-17 02:06:34'),
(31, 'aoladapo', 'e9f56d780e96897df0a10a0d117be026', 'Alfred Oladapo', 'SD', '000432@distracker.com', 'A', '5c2dd50ca908fed574fa9b1f18856fa0', '0000-00-00 00:00:00', '2013-12-12 16:23:25', '2014-05-17 02:08:32'),
(32, 'jsawadogo', '02e98800f21e0d79b83c2f481614bc96', 'JephtÃ© Sawadogo', 'SD', '000430@distracker.com', 'A', 'b500990b804ea58497059609560d5147', '0000-00-00 00:00:00', '2013-12-12 16:24:41', '2015-08-04 15:23:21'),
(33, 'suwah01', '02e98800f21e0d79b83c2f481614bc96', 'Sylvester Uwah', 'SD', 'scuwahpowerline@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:25:38', '2015-06-05 02:01:25'),
(34, 'dlowenberg', '02e98800f21e0d79b83c2f481614bc96', 'Douglas Lowenberg', 'SF', 'douglo1@mail.regent.edu', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:31:48', '2013-12-12 17:32:42'),
(35, 'dmiller', '02e98800f21e0d79b83c2f481614bc96', 'Denny Miller', 'SF', 'denny.miller@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:34:58', '2013-12-12 17:32:35'),
(36, 'cgibbs', '02e98800f21e0d79b83c2f481614bc96', 'Carl Gibbs', 'SF', 'carl.gibbs@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:37:07', '2015-06-05 00:29:27'),
(37, 'jeaster', '02e98800f21e0d79b83c2f481614bc96', 'John Easter', 'SF', 'john.easter@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:38:25', '2015-06-05 00:52:18'),
(38, 'ajohnson', '02e98800f21e0d79b83c2f481614bc96', 'Alan Johnson', 'SF', 'alan.johnson@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:39:29', '2015-06-05 00:33:02'),
(39, 'mballenger', '02e98800f21e0d79b83c2f481614bc96', 'Mary Ballenger', 'SF', 'mary.ballenger@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:40:16', '2015-06-05 00:36:56'),
(40, 'elwesya', '02e98800f21e0d79b83c2f481614bc96', 'Enson Lwesya', 'SF', 'staff07@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:41:15', '2014-01-01 01:28:19'),
(42, 'bpowers', 'bbe52ef02f7217b9df37f6fb45eabc6a', 'Boyd Powers', 'SF', 'Boyd.Powers@oregonag.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:42:52', '2015-04-21 21:05:34'),
(43, 'mmcculley', '47e93d55895a444c46db0ee5432ebe2c', 'Murriell McCulley', 'SF', 'murriellmcculley@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:44:48', '2015-06-05 00:43:58'),
(44, 'ezongo', '02e98800f21e0d79b83c2f481614bc96', 'Etienne ZONGO', 'SF', 'staff11@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:49:13', '2013-12-12 17:32:55'),
(45, 'jlemons', '02e98800f21e0d79b83c2f481614bc96', 'Jimmie Lemons', 'SF', 'jim.lemons@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:51:47', '2015-06-05 00:43:19'),
(46, 'cblock', '02e98800f21e0d79b83c2f481614bc96', 'Chip Block', 'SF', 'staff13@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:53:17', '2013-12-12 17:32:21'),
(47, 'jelliott', '02e98800f21e0d79b83c2f481614bc96', 'John Elliott', 'SF', 'staff14@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:55:38', '2013-12-12 17:33:22'),
(48, 'jthacker', '02e98800f21e0d79b83c2f481614bc96', 'James M. Thacker', 'SF', 'staff15@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 16:58:35', '2014-01-01 01:29:20'),
(49, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Chuck Wilson', 'AD', 'chuckwilson@pathseminary.org', 'A', '0', '2016-02-20 15:48:39', '2013-12-12 17:31:47', '2013-12-12 20:21:05'),
(50, 'pfaculty', '02e98800f21e0d79b83c2f481614bc96', 'Pre Tracking Info', 'SF', 'staff17@distracker.com', 'A', 'b8406d3ea0a6fe62c382e7699c47e2a1', '0000-00-00 00:00:00', '2013-12-12 17:48:47', '2014-01-01 01:46:44'),
(51, 'rbogere', '02e98800f21e0d79b83c2f481614bc96', 'Richard Bogere', 'SD', '000304@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 18:02:20', '2014-05-17 07:44:46'),
(52, 'NkoNxuma', '02e98800f21e0d79b83c2f481614bc96', 'Nkosenhle Nxumalo', 'SD', 'nxumalo1@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 18:03:48', '2014-05-17 07:38:22'),
(53, 'antogbon', '02e98800f21e0d79b83c2f481614bc96', 'Anthony Ogbonna', 'SD', 'ogbotony2009@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 18:04:42', '2014-05-17 02:11:34'),
(54, 'vsetsoafia', '02e98800f21e0d79b83c2f481614bc96', 'Vincent Setsoafia', 'SD', '000318@distracker.com', 'A', '11dfeba8e396430c5796434e007f5885', '0000-00-00 00:00:00', '2013-12-12 18:05:41', '2014-05-17 07:53:43'),
(55, 'dwoods', '02e98800f21e0d79b83c2f481614bc96', 'Dene Woods', 'SF', 'staff18@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 18:12:02', '2013-12-12 18:13:14'),
(56, 'mgilbert', '0441bc1481058e34e83cac3a577f2396', 'Marvin Gilbert', 'AD', 'marvin.gilbert@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2013-12-12 18:12:50', '2015-04-24 22:12:48'),
(57, 'kirsch', 'def1b5b5b579ac3ce8162fab959a7c88', 'William Kirsch', 'AD', 'billkirsch@pathseminary.org', 'A', '2e0d34bd1a8c8259dfb18eaf69e23a6d', '0000-00-00 00:00:00', '2014-03-14 16:21:32', '2015-01-23 03:23:18'),
(58, 'pambuka', '02e98800f21e0d79b83c2f481614bc96', 'Painito Nixon Ambuka', 'SD', '000417@distracker.com', 'D', '0', '0000-00-00 00:00:00', '2014-03-20 00:56:11', '2015-06-05 01:16:12'),
(59, 'eamoafo', 'cc2fa1f41951b591131f72b54c9e2900', 'Emmanuel Amoafo', 'SD', 'keatkenya@gmail.com', 'A', '21e9fed950c980ed65248e78c50afe6c', '0000-00-00 00:00:00', '2014-03-20 01:00:05', '2015-04-23 16:10:42'),
(60, 'rbanda', '02e98800f21e0d79b83c2f481614bc96', 'Reuben Banda', 'SD', '000455@distracker.com', 'D', '0', '0000-00-00 00:00:00', '2014-03-20 01:02:11', '2015-06-05 01:18:20'),
(61, 'ekananji', '02e98800f21e0d79b83c2f481614bc96', 'Elton Kananji', 'SD', 'elkanaji@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-03-20 01:03:50', '2015-06-05 01:42:15'),
(62, 'gphiri', '38be36f455d0d71ad3b3d88356401994', 'Gideon Phiri', 'SD', 'gideonphiri@yahoo.co.uk', 'A', '08bf9e78a0502ecf281465f78db272a8', '0000-00-00 00:00:00', '2014-03-20 01:05:14', '2015-04-23 16:27:21'),
(63, 'jtiacoh', '02e98800f21e0d79b83c2f481614bc96', 'Jean Marie Tiacoh', 'SD', 'tiacohjeanmarie@yahoo.fr', 'A', '49c8d0cee505c3cab5dfc7c0eab29228', '0000-00-00 00:00:00', '2014-03-20 01:06:42', '2015-06-05 02:00:03'),
(65, 'bbraswell', 'cd0d9157c1df9fa7914e73f40d9325d5', 'Bob Braswell', 'SF', 'bob.braswell@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2014-03-20 01:32:51', '2015-04-24 22:35:57'),
(66, 'nname01', '02e98800f21e0d79b83c2f481614bc96', 'no name', 'SD', 'test@distracker.com', 'A', '0', '0000-00-00 00:00:00', '2014-03-20 02:10:39', '2014-05-17 01:20:33'),
(67, 'noname2', 'c75e05454a4b6d02ee9ae3e4ac1d3f11', 'No Name2', 'SD', 'cwilson@sagu.edu', 'A', '8cc4aa54b8a96be175f29c8bdc9494dd', '0000-00-00 00:00:00', '2014-03-20 21:11:15', '2014-03-20 21:11:41'),
(70, 'joyyork', '02e98800f21e0d79b83c2f481614bc96', 'Joy York', 'AD', 'joyyork@pathseminary.org', 'A', '878a52322ec227c59ff11f3e9840493d', '0000-00-00 00:00:00', '2014-04-26 01:28:53', '2014-04-26 01:29:27'),
(71, 'tagbemenu', '02e98800f21e0d79b83c2f481614bc96', 'Theodore Agbemenu', 'SD', '000439@distracker.com', 'D', '0', '0000-00-00 00:00:00', '2014-04-26 02:12:26', '2015-06-05 01:15:49'),
(74, 'tdeugoue', '02e98800f21e0d79b83c2f481614bc96', 'Tite Aime Deugoue', 'SD', 'titusfgbi@yahoo.com', 'A', 'fc9b281758ddb3ce643037da4ac477c6', '0000-00-00 00:00:00', '2014-04-26 02:30:02', '2015-06-05 01:25:16'),
(75, 'mdjeha', '02e98800f21e0d79b83c2f481614bc96', 'Mawulawoe Djeha', 'SD', 'djehaagustin@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-04-26 02:32:49', '2015-06-05 01:25:56'),
(76, 'bethlord', '02e98800f21e0d79b83c2f481614bc96', 'Beth Lord', 'AD', 'bethlord@pathseminary.org', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 00:19:54', '2015-01-23 08:36:19'),
(77, 'echitsonga', '9f31f34cee8dfa18c8ba82c33f95c9af', 'Edward Chitsonga', 'SD', 'edwardchanza@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 00:40:33', '2015-04-23 22:37:27'),
(78, 'lchomba', '02e98800f21e0d79b83c2f481614bc96', 'Lewis Chomba', 'SD', 'lchomba@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 00:43:57', '2015-06-05 01:23:36'),
(79, 'jamesdema', '02e98800f21e0d79b83c2f481614bc96', 'James Dema', 'SD', 'james.dema@ias-intl.org', 'A', 'e91b301f6dba75c464b039d0b7f50b0d', '0000-00-00 00:00:00', '2014-05-17 00:47:55', '2015-04-23 16:15:58'),
(80, 'schaloner', '02e98800f21e0d79b83c2f481614bc96', 'Stephen Chaloner', 'SD', 'chalonersw@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 00:54:41', '2015-06-05 01:23:12'),
(81, 'andrewdube', '84f8dba0f2f465773801076520d402b2', 'Andrew Dube', 'SD', 'andrewdube@aol.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:03:22', '2015-06-05 01:27:33'),
(82, 'hgichuhi', '02e98800f21e0d79b83c2f481614bc96', 'Harris Gichuhi', 'SD', '000435@distracker.com', 'D', '0', '0000-00-00 00:00:00', '2014-05-17 01:07:18', '2015-06-05 01:33:18'),
(83, 'jmulinda', '02e98800f21e0d79b83c2f481614bc96', 'Jean Marie Mulinda', 'SD', 'jmvmulinda@yahoo.com', 'A', '67871e6f4e9bed066723957a30869b64', '0000-00-00 00:00:00', '2014-05-17 01:13:55', '2015-04-23 16:19:23'),
(84, 'bidowu', '02e98800f21e0d79b83c2f481614bc96', 'Babatunde Idowu', 'SD', 'tunde4Christ2007@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:19:01', '2015-01-23 01:14:21'),
(85, 'jmwaba', '3de8ecc6d249d874e5936e86c2454f29', 'Joseph Mwaba', 'SD', 'josephmwaba2001@yahoo.fr', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:22:57', '2015-04-23 16:24:12'),
(86, 'cadehenu', '02e98800f21e0d79b83c2f481614bc96', 'Cephas Adehenu', 'SD', 'adehenu@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:27:31', '2015-06-06 13:56:16'),
(87, 'inhigula', 'e2b75c5bcce14988c65c7a35d221a65a', 'Immaculate Nhigula', 'SD', 'emmanhigu@gmail.com', 'A', '00d8c7be86c1323feda611629b76e8e0', '0000-00-00 00:00:00', '2014-05-17 01:28:24', '2015-06-10 16:53:42'),
(88, 'pnjuguna', '02e98800f21e0d79b83c2f481614bc96', 'Phelista Njuguna', 'SD', '000411@distracker.com', 'D', '0', '0000-00-00 00:00:00', '2014-05-17 01:31:03', '2015-06-05 01:57:29'),
(89, 'cotieno', '6a12b9910cb2ddc2408308b9836cce76', 'Charles Otieno', 'SD', 'chuckmicemmanuel@yahoo.com', 'A', 'a932abd380a90d23f5d11df62cb339f9', '0000-00-00 00:00:00', '2014-05-17 01:35:23', '2015-04-23 23:08:03'),
(90, 'arthurmba', '956e35406fbfd2bceb7600cb3454810c', 'Arthur Mba', 'SD', 'arthur_mba@yahoo.fr', 'A', 'c332e641fa5be1e05467e5224e60042b', '0000-00-00 00:00:00', '2014-05-17 01:35:33', '2015-09-08 03:11:22'),
(91, 'aobeng-amoako', '02e98800f21e0d79b83c2f481614bc96', 'Abraham Obeng-Amoako', 'SD', 'Obeng-Amoako@cegghana.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:37:57', '2015-06-05 01:59:33'),
(92, 'eyateesa', '02e98800f21e0d79b83c2f481614bc96', 'Esther Yateesa', 'SD', 'eyateesa@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:41:39', '2015-06-05 02:09:37'),
(93, 'johntawo ', '081fe72d4e7e01e4c309bb353c5c79d6', 'John Tawo', 'SD', '000450@distracker.com', 'A', 'f44675e0a590be67438985d62fceffb2', '0000-00-00 00:00:00', '2014-05-17 01:42:40', '2014-07-12 13:24:12'),
(94, 'paulyork', '030fb46f66f370901054352c9ad65183', 'Paul York', 'SD', 'YorkP@evangel.edu', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:44:06', '2015-04-23 22:55:43'),
(95, 'mturney', '02e98800f21e0d79b83c2f481614bc96', 'Mark Turney', 'SD', 'mark.turney@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:49:49', '2015-06-05 02:00:25'),
(96, 'wnewberry', '02e98800f21e0d79b83c2f481614bc96', 'Warren Newberry', 'SF', 'wbnewberry@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:50:08', '2014-05-17 01:50:30'),
(97, 'lwonget', '02e98800f21e0d79b83c2f481614bc96', 'Lydia Wonget', 'SD', 'wongets@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 01:51:03', '2015-06-05 02:10:08'),
(98, 'amkwaila', '02e98800f21e0d79b83c2f481614bc96', 'Andrew Mkwaila', 'SF', 'andymkwaila@hotmail.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 02:01:05', '2014-05-17 02:07:19'),
(99, 'kwasivibalo', '02e98800f21e0d79b83c2f481614bc96', 'Kwasivi Balo', 'SD', 'balokwasivi@yahoo.fr', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 08:27:30', '2015-06-05 01:29:20'),
(100, 'sbentil', '02e98800f21e0d79b83c2f481614bc96', 'Sam Bentil', 'SD', 'sab4christ@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2014-05-17 08:34:03', '2015-06-05 01:19:16'),
(103, 'celsebal', '02e98800f21e0d79b83c2f481614bc96', 'Celestin Sebalinda', 'SD', 'ligoseb@yahoo.fr', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:31:03', '0000-00-00 00:00:00'),
(104, 'milthind', '02e98800f21e0d79b83c2f481614bc96', 'Milton Thindwa', 'SD', 'miltonthindwa@yahoo.com ', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:37:07', '0000-00-00 00:00:00'),
(105, 'adrphir', '02e98800f21e0d79b83c2f481614bc96', 'Adrian Phiri', 'SD', 'phiriadrian@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:40:38', '0000-00-00 00:00:00'),
(106, 'salndegh', '02e98800f21e0d79b83c2f481614bc96', 'Salomon Ndegha', 'SD', 'sandegha@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:44:22', '0000-00-00 00:00:00'),
(107, 'davakons', '02e98800f21e0d79b83c2f481614bc96', 'David Akonsi', 'SD', 'dakonsi@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:45:45', '2015-01-22 22:52:47'),
(108, 'henmoyo', '02e98800f21e0d79b83c2f481614bc96', 'Henry Moyo', 'SD', 'kufaithtemple@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:46:37', '0000-00-00 00:00:00'),
(109, 'isakasil', 'b9d540a26a8f07c9b771d929f502acc5', 'Isaac Kasili', 'SD', 'isaackasili@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:48:28', '2015-04-23 16:18:13'),
(110, 'johede', '02e98800f21e0d79b83c2f481614bc96', 'John Ede', 'SD', 'edejon@yahoo.com', 'A', '626ecfa003e2f245cef0d2f6f7bcf77d', '0000-00-00 00:00:00', '2015-01-22 22:50:47', '0000-00-00 00:00:00'),
(111, 'samdlami', '02e98800f21e0d79b83c2f481614bc96', 'Samuel Dlamini', 'SD', 'samuelfdlamini@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2015-01-22 22:51:54', '0000-00-00 00:00:00'),
(113, 'hyoung', '02e98800f21e0d79b83c2f481614bc96', 'Howard Young', 'SF', 'howardlyoung@aol.com', 'A', '0', '0000-00-00 00:00:00', '2015-03-24 01:57:42', '2015-06-05 00:13:44'),
(114, 'dcollins', '02e98800f21e0d79b83c2f481614bc96', 'Duane Collins', 'SF', 'dcollins@sagu.edu', 'A', '0', '0000-00-00 00:00:00', '2015-03-24 02:45:27', '2015-06-05 00:56:34'),
(115, 'rshipley', '02e98800f21e0d79b83c2f481614bc96', 'Rob Shipley', 'SF', 'robert.shipley@agmd.org', 'A', '0', '0000-00-00 00:00:00', '2015-03-24 03:09:03', '2015-06-05 01:10:46'),
(117, '3731', '15c7b1d22c48949c6de6861cd1ec2251', 'klark klark', 'SD', 'luidji2d@gmail.com', 'D', '0', '0000-00-00 00:00:00', '2015-04-08 09:37:26', '0000-00-00 00:00:00'),
(118, 'boydpowers', '8da1892a6e3dc332cd0f4650e5d14ab7', 'Boyd Powers', 'SF', 'boyd.powers@oregonag.org', 'A', '0', '0000-00-00 00:00:00', '2015-04-21 20:36:34', '0000-00-00 00:00:00'),
(119, 'byeongjun', '02e98800f21e0d79b83c2f481614bc96', 'Byeong Jun', 'SF', 'drbjun@gmail.com', 'A', '0', '0000-00-00 00:00:00', '2015-06-04 23:44:59', '0000-00-00 00:00:00'),
(120, 'rmapes', '02e98800f21e0d79b83c2f481614bc96', 'Robert Mapes', 'SF', 'rmapes@sagu.edu', 'A', '0', '0000-00-00 00:00:00', '2015-06-05 02:29:29', '0000-00-00 00:00:00'),
(121, 'emsangi', '02e98800f21e0d79b83c2f481614bc96', 'Eieti Msangi', 'SD', 'epmmsangi@yahoo.com', 'A', '0', '0000-00-00 00:00:00', '2015-06-05 21:02:06', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user_info`
--

CREATE TABLE IF NOT EXISTS `tb_user_info` (
  `user_id` int(255) NOT NULL,
  `user_fname` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_lname` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_prefix` enum('Mr','Mrs','Miss','Dr','Rev') COLLATE utf8_bin NOT NULL,
  `user_desc` text COLLATE utf8_bin NOT NULL,
  `user_registration` varchar(20) COLLATE utf8_bin NOT NULL,
  `user_lang` varchar(256) COLLATE utf8_bin NOT NULL,
  `user_doe` date NOT NULL,
  `user_mobile` int(16) NOT NULL,
  `user_address` text COLLATE utf8_bin NOT NULL,
  `user_suite` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_city` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_state` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_country` int(3) NOT NULL,
  `user_zip` varchar(12) COLLATE utf8_bin NOT NULL,
  `user_dob` date NOT NULL,
  `user_skype` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_photo` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_doc` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users Information';

--
-- Dumping data for table `tb_user_info`
--

INSERT INTO `tb_user_info` (`user_id`, `user_fname`, `user_lname`, `user_prefix`, `user_desc`, `user_registration`, `user_lang`, `user_doe`, `user_mobile`, `user_address`, `user_suite`, `user_city`, `user_state`, `user_country`, `user_zip`, `user_dob`, `user_skype`, `user_photo`, `user_doc`) VALUES
(1, 'Sri', 'Kadari', 'Mr', '', '0789809', '', '0000-00-00', 0, 'NA', '', '', '', 0, '', '0000-00-00', '', '1_Srikanth.jpg', '2014-08-22 11:01:33'),
(3, 'Ayi M.', 'Adade', 'Mr', '', '000201', '', '2007-11-11', 0, '', '', '', '', 210, '', '0000-00-00', '', '', '2015-06-05 01:13:53'),
(4, 'David', 'Aja', 'Mr', '', '000202', '', '2007-11-11', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2015-06-05 01:15:15'),
(5, 'Phillip', 'Arthur', 'Mr', '', '000203', '', '2007-11-11', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 01:16:55'),
(6, 'Nelson', 'Banda', 'Mr', '', '000205', '', '2007-11-11', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2015-06-05 01:17:31'),
(7, 'Dominique', 'Bangoret', 'Mr', '', '000206', '', '2007-11-11', 0, '', '', '', '', 52, '', '0000-00-00', '', '', '2014-05-17 02:25:55'),
(8, 'Marcel', 'Bomboko', 'Mr', '', '000208', '', '2007-11-11', 0, '', '', '', '', 237, '', '0000-00-00', '', '', '2015-06-05 01:22:35'),
(9, 'Cecile', 'Bomboko', 'Mrs', '', '000207', '', '2007-11-11', 0, '', '', '', '', 237, '', '0000-00-00', '', '', '2015-06-05 01:50:16'),
(10, 'Chris Victor', 'Dzoagbe', 'Mr', '', '000209', '', '2007-11-11', 0, '', '', '', '', 82, '', '0000-00-00', '', '', '2015-06-05 01:26:52'),
(11, 'Joel Ede', 'Ikpe', 'Mr', '', '000211', '', '2007-06-11', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2014-05-17 02:36:40'),
(12, 'Jeff', 'Nelson', 'Mr', '', '000212', '', '2007-06-11', 0, '', '', '', '', 110, '', '0000-00-00', '', '', '2015-04-23 16:26:20'),
(13, 'Felix', 'Niba', 'Mr', '', '000109', '', '2007-11-11', 0, '', '', '', '', 37, '', '0000-00-00', '', '', '2015-06-05 01:58:04'),
(14, 'Ngozi Cecilia', 'Oganya', 'Mr', '', '000213', '', '2007-11-11', 0, '', '', '', '', 37, '', '0000-00-00', '', '', '2014-05-17 07:31:20'),
(15, 'Louis Yaw', 'Oppong-Kyekyeku', 'Mr', '', '000214', '', '2007-11-11', 0, '', '', '', '', 82, '', '0000-00-00', '', '', '2014-05-17 02:40:10'),
(16, 'Gideon Namyela', 'Panka', 'Mr', '', '000215', '', '2007-11-11', 0, '', '', '', '', 202, '', '0000-00-00', '', '', '2014-05-17 02:33:54'),
(17, 'Salam', 'Saba', 'Mr', '', '000216', '', '2007-11-11', 0, '', '', '', '', 34, '', '0000-00-00', '', '', '2014-05-17 07:50:04'),
(18, 'Dan', 'Saglimbeni', 'Mr', '', '000217', '', '2007-11-11', 0, '', '', '', '', 110, '', '0000-00-00', '', '', '2014-05-17 02:21:42'),
(20, 'Gideon', 'Bagudu', 'Mr', '', '000419', '', '2011-11-13', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2015-06-05 19:54:21'),
(21, 'Caleb', 'Dampak', 'Mr', '', '000420', '', '2011-11-13', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2015-06-05 01:23:58'),
(22, 'Ogboso', 'Ejindu', 'Mr', '', '000422', '', '2011-11-13', 0, '', '', '', '', 156, '', '0000-00-00', '', '22_DSC_0208.JPG', '2015-10-07 17:39:51'),
(23, 'Douti', 'Flindja', 'Mr', '', '000423', '', '2011-11-13', 0, '', '', '', '', 210, '', '0000-00-00', '', '', '2015-06-05 01:32:42'),
(24, 'Alfred', 'Ikedinma', 'Mr', '', '4533333', '', '2011-11-13', 2147483647, '', '', '', '', 156, '', '0000-00-00', '', '', '2015-09-24 18:15:29'),
(25, 'Jean', 'Ilunga', 'Mr', '', '000424', '', '2011-11-13', 0, '', '', '', '', 237, '', '0000-00-00', '', '', '2015-06-05 01:39:32'),
(26, 'Claver', 'Koutouan', 'Mr', '', '000436', '', '2011-11-13', 0, '', '', '', '', 52, '', '0000-00-00', '', '', '2015-06-05 01:45:51'),
(27, 'Jimmy', 'Kuoh', 'Mr', '', '000426', '', '2011-11-13', 0, '', '', '', '', 120, '', '0000-00-00', '', '', '2015-06-05 01:47:46'),
(28, 'William', 'Muyabwa', 'Mr', '', '000427', '', '2011-11-13', 2147483647, 'BF 037, Gate 215 ', '', 'Niamey ', '', 155, '', '0000-00-00', 'muyabwa', '28_22-03-2015_22;18;08.JPG', '2015-07-16 01:26:57'),
(29, 'Paul', 'Oganya', 'Mr', '', '000428', '', '2011-11-13', 0, '', '', '', '', 37, '', '0000-00-00', '', '', '2014-05-17 02:04:35'),
(30, 'Kingsley', 'Okereke', 'Mr', '', '000429', '', '2011-11-13', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2014-05-17 02:06:34'),
(31, 'Alfred', 'Oladapo', 'Mr', '', '000432', '', '2011-11-13', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2014-05-17 02:08:32'),
(32, 'JephtÃ©', 'Sawadogo', 'Mr', '', '000430', '', '2011-06-13', 0, '', '', '', '', 34, '', '0000-00-00', '', '32_BiblicalPerspectiveofPrayer.docx', '2015-08-04 15:23:21'),
(33, 'Sylvester', 'Uwah', 'Mr', '', '000437', '', '2011-11-13', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2015-06-05 02:01:25'),
(34, 'Douglas', 'Lowenberg', 'Dr', '', '', '1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-12 17:32:42'),
(35, 'Denny', 'Miller', 'Dr', '', '', '1,2,3', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-12 17:32:35'),
(36, 'Carl', 'Gibbs', 'Dr', '', '', '3,1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:29:27'),
(37, 'John', 'Easter', 'Dr', '', '', '3,1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:52:18'),
(38, 'Alan', 'Johnson', 'Dr', '', '', '3,1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:33:02'),
(39, 'Mary', 'Ballenger', 'Dr', '', '', '3,1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:36:56'),
(40, 'Enson', 'Lwesya', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-01-01 01:28:19'),
(42, 'Boyd', 'Powers', 'Dr', '', '', '3,1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-04-21 21:05:34'),
(43, 'Murriell', 'McCulley', 'Dr', '', '', '3,1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:43:58'),
(44, 'Etienne', 'ZONGO', 'Dr', '', '', '1,2,3', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-12 17:32:55'),
(45, 'Jimmie', 'Lemons', 'Dr', '', '', '3,1,2', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:43:19'),
(46, 'Chip', 'Block', 'Dr', '', '', '1,2,3', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-12 17:32:21'),
(47, 'John', 'Elliott', 'Dr', '', '', '1,2,3', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-12 17:33:22'),
(48, 'James M.', 'Thacker', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-01-01 01:29:20'),
(49, 'Chuck', 'Wilson', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 223, '', '0000-00-00', '', '', '2013-12-12 18:14:54'),
(50, 'Pre', 'Tracking Info', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-01-01 01:46:44'),
(51, 'Richard', 'Bogere', 'Mr', '', '000304', '', '2009-11-15', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-05-17 07:44:46'),
(52, 'Nkosenhle', 'Nxumalo', 'Mr', '', '000312', '', '2009-11-15', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-05-17 07:38:22'),
(53, 'Anthony', 'Ogbonna', 'Mr', '', '000313', '', '2009-11-15', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2014-05-17 02:11:34'),
(54, 'Vincent', 'Setsoafia', 'Mr', '', '000318', '', '2009-11-15', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-05-17 07:53:43'),
(55, 'Dene', 'Woods', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2013-12-12 18:13:14'),
(56, 'Marvin', 'Gilbert', 'Dr', '', '', '', '0000-00-00', 2147483647, '791 N Hwy 77', 'Suite 501C-147', 'Waxahachie', 'TX', 223, '75165', '0000-00-00', 'marvin.gilbert', '56_M_Gilbert-Compresses.jpg', '2015-04-24 22:12:48'),
(57, 'William', 'Kirsch', 'Dr', '', '', '1', '0000-00-00', 2147483647, '4020 N. Williams Ct.', '', 'Springfield', 'MO', 223, '65803', '0000-00-00', 'bill.kirsch', '57_Bill_and_Judy_Kirsch_01.jpg', '2015-01-23 03:23:18'),
(58, 'Painito Nixon', 'Ambuka', 'Mr', '', '000417', '', '2013-09-01', 0, '', '', '', '', 35, '', '0000-00-00', '', '', '2015-06-05 01:16:12'),
(59, 'Emmanuel', 'Amoafo', 'Mr', '', '000441', '', '2013-09-01', 0, '', '', '', '', 110, '', '0000-00-00', '', '', '2015-04-23 16:10:42'),
(60, 'Reuben', 'Banda', 'Mr', '', '000455', '', '2013-03-19', 0, '', '', '', '', 238, '', '0000-00-00', '', '', '2015-06-05 01:18:20'),
(61, 'Elton', 'Kananji', 'Mr', '', '000444', '', '2013-04-01', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2015-06-05 01:42:15'),
(62, 'Gideon', 'Phiri', 'Mr', '', '000449', '', '2013-04-01', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2015-04-23 16:27:21'),
(63, 'Jean Marie', 'Tiacoh', 'Mr', '', '000451', '', '2013-11-01', 0, '', '', '', '', 52, '', '0000-00-00', '', '', '2015-06-05 02:00:03'),
(65, 'Bob', 'Braswell', 'Dr', '', '', '', '0000-00-00', 2147483647, '3 Turfontein Lane', '', 'Milnerton', '', 193, '7441', '0000-00-00', 'babunabibi', '', '2015-04-24 22:35:57'),
(66, 'no', 'name', 'Mr', '', '00001', '', '2014-03-19', 0, '', '', '', '', 26, '', '0000-00-00', '', '', '2014-05-17 01:20:33'),
(67, 'No', 'Name2', 'Mr', '', '10001', '', '2014-03-20', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2014-03-20 21:11:41'),
(70, 'Joy', 'York', 'Mrs', '', '', '1', '0000-00-00', 0, '', '', '', '', 223, '', '0000-00-00', '', '', '2014-04-26 01:29:13'),
(71, 'Theodore', 'Agbemenu', 'Mr', '', '000439', '', '2013-11-01', 0, '', '', '', '', 82, '', '0000-00-00', '', '', '2015-06-05 01:15:49'),
(74, 'Tite Aime', 'Deugoue', 'Mr', '', '000440', '', '2013-11-01', 0, '', '', '', '', 37, '', '0000-00-00', '', '', '2015-06-05 01:25:16'),
(75, 'Mawulawoe', 'Djeha', 'Mr', '', '000457', '', '2013-11-01', 0, '', '', '', '', 37, '', '0000-00-00', '', '', '2015-06-05 01:25:56'),
(76, 'Beth', 'Lord', 'Rev', '', '', '', '0000-00-00', 0, '', '', '', '', 223, '', '0000-00-00', '', '76_Ppic2.jpg', '2015-01-23 08:36:19'),
(77, 'Edward', 'Chitsonga', 'Mr', '', '000402', '', '2011-09-01', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2015-04-23 22:37:27'),
(78, 'Lewis', 'Chomba', 'Mr', '', '000403', '', '2011-11-01', 0, '', '', '', '', 202, '', '0000-00-00', '', '', '2015-06-05 01:23:36'),
(79, 'James', 'Dema', 'Mr', '', '000404', '', '2011-11-01', 0, '', '', '', '', 199, '', '0000-00-00', '', '', '2015-04-23 16:15:58'),
(80, 'Stephen', 'Chaloner', 'Mr', '', '000401', '', '2011-09-01', 0, '', '', '', '', 110, '', '0000-00-00', '', '', '2015-06-05 01:23:12'),
(81, 'Andrew', 'Dube', 'Mr', '', '000405', '', '2011-09-01', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2015-06-05 01:27:33'),
(82, 'Harris', 'Gichuhi', 'Mr', '', '000435', '', '2011-09-01', 0, '', '', '', '', 110, '', '0000-00-00', '', '', '2015-06-05 01:33:18'),
(83, 'Jean Marie', 'Mulinda', 'Mr', '', '000409', '', '2011-09-01', 0, '', '', '', '', 177, '', '0000-00-00', '', '', '2015-04-23 16:19:23'),
(84, 'Babatunde', 'Idowu', 'Rev', '', '000307', '', '2009-11-02', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2015-01-23 01:14:21'),
(85, 'Joseph', 'Mwaba', 'Mr', '', '000410', '', '2011-09-01', 0, '', '', '', '', 237, '', '0000-00-00', '', '', '2015-04-23 16:24:12'),
(86, 'Cephas', 'Adehenu', 'Mr', '', '000438', '', '2013-11-01', 201405864, 'House of Prayer Assemblies of God, SSNIT Flats', '', 'Ho', 'Volta Region', 82, '', '0000-00-00', 'cephas.adehenu', '86_rev_adehenu.jpg', '2015-06-06 13:56:16'),
(87, 'Immaculate', 'Nhigula', 'Mrs', '', '000433', '', '2011-09-01', 2147483647, '', '', 'Dar Es Salaam', '', 208, '', '0000-00-00', 'emma.nhigula', '', '2015-06-10 16:53:42'),
(88, 'Phelista', 'Njuguna', 'Mrs', '', '000411', '', '2011-09-01', 0, '', '', '', '', 110, '', '0000-00-00', '', '', '2015-06-05 01:57:29'),
(89, 'Charles', 'Otieno', 'Mr', '', '000413', '', '2011-09-01', 722949155, 'P. O. Box 1933', '', 'Kisumu', '', 110, '40100', '0000-00-00', '', '', '2015-04-23 23:08:03'),
(90, 'Arthur', 'Mba', 'Mr', '', '000458', '', '2013-11-01', 0, 'P.O. Box 15427', '', 'Libreville', '', 78, '', '0000-00-00', 'arthur.mba1', '90_photo_possible.docx', '2015-09-08 03:11:22'),
(91, 'Abraham', 'Obeng-Amoako', 'Mr', '', '000447', '', '2013-11-01', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 01:59:33'),
(92, 'Esther', 'Yateesa', 'Mrs', '', '000415', '', '2011-09-01', 0, '', '', '', '', 219, '', '0000-00-00', '', '', '2015-06-05 02:09:37'),
(93, 'John', 'Tawo', 'Mr', '', '000450', '', '2013-11-01', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2014-07-12 13:24:12'),
(94, 'Paul', 'York', 'Mr', '', '000431', '', '2011-09-01', 2147483647, '1006 E Snider', '', 'Springfield', 'MO', 223, '65803', '0000-00-00', '', '94_Source_du_Nil_Road_Trip_328.JPG', '2015-04-23 22:55:43'),
(95, 'Mark', 'Turney', 'Mr', '', '000452', '', '2013-11-01', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 02:00:25'),
(96, 'Warren', 'Newberry', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 223, '', '0000-00-00', '', '', '2014-05-17 01:50:30'),
(97, 'Lydia', 'Wonget', 'Mrs', '', '000453', '', '2013-11-01', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 02:10:08'),
(98, 'Andrew', 'Mkwaila', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2014-05-17 02:07:19'),
(99, 'Kwasivi', 'Balo', 'Mr', '', '000443', '', '2013-11-01', 0, '', '', '', '', 210, '', '0000-00-00', '', '', '2015-06-05 01:29:20'),
(100, 'Sam', 'Bentil', 'Mr', '', '000456', '', '2013-11-01', 0, '', '', '', '', 82, '', '0000-00-00', '', '', '2015-06-05 01:19:16'),
(103, 'Celestin', 'Sebalinda', 'Rev', '', '091317', '', '2009-11-01', 0, '', '', '', '', 37, '', '0000-00-00', '', '', '2015-01-22 22:31:03'),
(104, 'Milton', 'Thindwa', 'Rev', '', '091319', '', '2009-11-01', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-01-22 22:37:07'),
(105, 'Adrian', 'Phiri', 'Rev', '', '091315', '', '2009-11-01', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2015-01-22 22:40:38'),
(106, 'Salomon', 'Ndegha', 'Rev', '', '091310', '', '2009-11-01', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-01-22 22:44:22'),
(107, 'David', 'Akonsi', 'Rev', '', '091301', '', '2009-11-01', 0, '', '', '', '', 82, '', '0000-00-00', '', '', '2015-01-22 22:52:47'),
(108, 'Henry', 'Moyo', 'Rev', '', '091309', '', '2009-11-01', 0, '', '', '', '', 128, '', '0000-00-00', '', '', '2015-01-22 22:46:37'),
(109, 'Isaac', 'Kasili', 'Rev', '', '091308', '', '2009-11-01', 0, '', '', '', '', 110, '', '0000-00-00', '', '', '2015-04-23 16:18:13'),
(110, 'John', 'Ede', 'Rev', '', '091306', '', '2009-11-01', 0, '', '', '', '', 156, '', '0000-00-00', '', '', '2015-01-22 22:50:47'),
(111, 'Samuel', 'Dlamini', 'Rev', '', '091320', '', '2009-11-01', 0, '', '', '', '', 202, '', '0000-00-00', '', '', '2015-01-22 22:51:54'),
(113, 'Howard', 'Young', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:13:44'),
(114, 'Duane', 'Collins', 'Dr', '', '', '1', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 00:56:34'),
(115, 'Rob', 'Shipley', 'Dr', '', '', '3', '0000-00-00', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 01:10:46'),
(117, 'klark', 'klark', 'Mrs', '', 'CpuWOucBqUEOkVfyVFp', '', '0000-00-00', 2147483647, 'wZFImvlqtkdalFz', 'ZiEmpOgKbyeURIM', 'New York', 'NY', 108, '94236', '0000-00-00', 'lQXOvNISQmibvP', '', '2015-04-08 09:37:26'),
(118, 'Boyd', 'Powers', 'Dr', '', '', '1', '0000-00-00', 0, '6570 Kurtz Rd.', '', 'Dallas', 'Oregon', 223, '9', '0000-00-00', '', '', '2015-04-21 20:36:34'),
(119, 'Byeong', 'Jun', 'Dr', '', '', '3', '0000-00-00', 0, '', '', '', '', 193, '', '0000-00-00', '', '', '2015-06-04 23:44:59'),
(120, 'Robert', 'Mapes', 'Dr', '', '', '3,1', '0000-00-00', 0, '', '', '', '', 223, '', '0000-00-00', '', '', '2015-06-05 02:29:29'),
(121, 'Eieti', 'Msangi', 'Rev', '', '09800984', '', '2015-06-05', 0, '', '', '', '', 0, '', '0000-00-00', '', '', '2015-06-05 21:02:06');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_dissertation_details`
--
CREATE TABLE IF NOT EXISTS `vw_dissertation_details` (
`std_id` int(255)
,`std_name` varchar(255)
,`email` varchar(255)
,`login_time` datetime
,`std_photo` varchar(255)
,`con_id` int(255)
,`con_name` varchar(255)
,`chrt_id` int(255)
,`chrt_name` varchar(255)
,`program_id` int(11)
,`program_name` varchar(255)
,`dist_id` int(255)
,`dist_name` varchar(255)
,`dist_desc` text
,`dist_doc` datetime
,`lang_id` tinyint(2)
,`lang_name` varchar(255)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_stage_role_rel`
--
CREATE TABLE IF NOT EXISTS `vw_stage_role_rel` (
`stg_id` int(255)
,`stg_title` varchar(255)
,`role_id` smallint(3)
,`role_title` varchar(255)
);
-- --------------------------------------------------------

--
-- Structure for view `vw_dissertation_details`
--
DROP TABLE IF EXISTS `vw_dissertation_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_dissertation_details` AS select `u`.`user_id` AS `std_id`,`u`.`user_fullname` AS `std_name`,`u`.`user_email` AS `email`,`u`.`user_login` AS `login_time`,`ui`.`user_photo` AS `std_photo`,`con`.`concentration_id` AS `con_id`,`con`.`concentration_name` AS `con_name`,`cht`.`cohort_id` AS `chrt_id`,`cht`.`cohort_name` AS `chrt_name`,`d`.`disseration_program` AS `program_id`,`p`.`program_name` AS `program_name`,`d`.`dissertation_id` AS `dist_id`,`d`.`disseration_name` AS `dist_name`,`d`.`disseration_desc` AS `dist_desc`,`d`.`disseration_doc` AS `dist_doc`,`l`.`lang_id` AS `lang_id`,`l`.`lang_name` AS `lang_name` from ((((((`tb_users` `u` join `tb_user_info` `ui`) join `tb_cohort` `cht`) join `tb_dissertation` `d`) join `tb_languages` `l`) left join `tb_programs` `p` on((`p`.`program_id` = `d`.`disseration_program`))) left join `tb_concentration` `con` on((`d`.`disseration_concentration` = `con`.`concentration_id`))) where ((`u`.`user_id` = `ui`.`user_id`) and (`u`.`user_type` = 'SD') and (`u`.`user_status` = 'A') and (`d`.`disseration_cohort` = `cht`.`cohort_id`) and (`d`.`std_id` = `u`.`user_id`) and (`l`.`lang_id` = `d`.`disseration_language`));

-- --------------------------------------------------------

--
-- Structure for view `vw_stage_role_rel`
--
DROP TABLE IF EXISTS `vw_stage_role_rel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_stage_role_rel` AS select `s`.`stg_id` AS `stg_id`,`s`.`stg_title` AS `stg_title`,`r`.`role_id` AS `role_id`,`r`.`role_title` AS `role_title` from ((`tb_role_stage_rel` `rel` join `tb_stages` `s`) join `tb_roles` `r`) where ((`rel`.`stg_id` = `s`.`stg_id`) and (`rel`.`role_id` = `r`.`role_id`)) order by `rel`.`rel_ord`;
